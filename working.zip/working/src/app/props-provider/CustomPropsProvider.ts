import {EntryFactory, IPropertiesProvider} from '../bpmn-js/bpmn-js';
import {Custom} from './custom';
import {CustomProps} from './props';
export class CustomPropsProvider implements IPropertiesProvider {

  static $inject = ['translate', 'bpmnPropertiesProvider'];

// Note that names of arguments must match injected modules, see InjectionNames.
  constructor(private translate, private bpmnPropertiesProvider) {
  }
   createCustomTabGroups(element: any, elementRegistry: any) {

    var theGroup = {
        id: Custom.id,
        label: Custom.name,
        entries: new Array
    };

    CustomProps(theGroup, element);

    return [
        theGroup
    ];
}
  getTabs(element) {
    console.log(this.constructor.name, 'Creating property tabs');
    return this.bpmnPropertiesProvider.getTabs(element)
      .concat({
        id: 'custom',
        label: this.translate('Custom'),
        groups: this.createCustomTabGroups(element, CustomElementRegistry)
      });
  }
}
