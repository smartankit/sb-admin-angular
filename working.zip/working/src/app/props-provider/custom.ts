export const Custom = {
    id: `CustomCompany`,
    name: `CustomCompany`,
    prefix: `ext`,
    "uri": "http://custom.example.com/bpmn/2016",
};