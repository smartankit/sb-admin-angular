import { EntryFactory } from '../bpmn-js/bpmn-js';
import { is } from 'bpmn-js/lib/util/ModelUtil'
export function CustomProps(group:any, element:any) {
    if (is(element, 'bpmn:SendTask')) {
        group.entries.push(EntryFactory.textField({
            id : 'template',
            description : 'template',
            label : 'template',
            modelProperty : 'template'
        }));
    }

    if (is(element, 'bpmn:UserTask')) {
        group.entries.push(EntryFactory.textField({
            id : 'worklist',
            description : 'worklist',
            label : 'worklist',
            modelProperty : 'worklist'
        }));
    }

    if (is(element, 'bpmn:ExclusiveGateway')) {
        group.entries.push(EntryFactory.textField({
            id: 'condition',
            description: 'The Instance property whose value should match one of the outgoing flows',
            label: 'Instance property to evaluate',
            modelProperty: 'condition'
        }));
    }

    if (is(element, 'bpmn:ScriptTask')) {
        group.entries.push(EntryFactory.textBox({
            id: 'script',
            description: 'script',
            label: 'script',
            modelProperty: 'script'
        }));
    }

    if (is(element, 'bpmn:SubProcess')) {
        group.entries.push(EntryFactory.textField({
            id: 'ReferencedProcessDefinition',
            description: 'ReferencedProcessDefinition',
            label: 'ReferencedProcessDefinition',
            modelProperty: 'ReferencedProcessDefinition'
        }));
    }


};