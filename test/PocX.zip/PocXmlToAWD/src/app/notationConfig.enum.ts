export enum bpmnNotation {
    start ='bpmn:startEvent' ,
    task = 'bpmn:task',
    gateway = 'bpmn:exclusiveGateway',
    intermediate = 'bpmn:intermediateThrowEvent',
    end = 'bpmn:endEvent',
    connector = 'bpmn:sequenceFlow'
}


export enum BpmnElement {
    start ='StartEvent' ,
    task = 'Task',
    gateway = 'ExclusiveGateway',
    intermediate = 'IntermediateThrowEvent',
    end = 'EndEvent',
    connector = 'SequenceFlow'
}

export enum awdNotation {
    start = "StartEvent",
    activity = "Activity",
    gateway="Gateway",
    simpleMergeGateway = "SimpleMergeGateway",
    xOrGateway = "XORGateway",
    intermediate = "IntermediateEvent",
    end = "EndEvent"
}