/**
 * 
 * @author  : Vijay Chebolu <VKChebolu@dstworldwideservices.com>
 * @Created on : 14th May 2019 
 */

import * as xml2js from 'xml2js';
import * as Builder from 'xmlbuilder';
import { isArray } from 'util';
import { AwdBase64 } from './AWDbase64';

export class AwdToBpmn {

    //Takes XML string and converts to Json Object
    private parseAWDXml(xml: string): any {
        let awdJson: string;
        const parser = new xml2js.Parser({
            preserveChildrenOrder: true,
            trim: true,
            explicitArray: false
        });

        parser.parseString(xml, function (err, result) {
            awdJson = result;
        });
        return awdJson;
    }

    //Converts Joints in the AWD Xml to Waypoints in BPMN Xml
    private transformJoints(node, joints) {
        joints = this.convertObjectToArray(joints)
        joints.forEach(joint => {
            if (joint) {
                if (joint.joint.length > 1) {
                    joint.joint.forEach(innerJoint => {
                        node.ele('di:waypoint')
                            .att('x', innerJoint.x)
                            .att('y', innerJoint.y).up();
                    });
                }
                else {
                    node.ele('di:waypoint')
                        .att('x', joint.joint.x)
                        .att('y', joint.joint.y).up();
                }
            }
        })
    }

    //Converts AWD Connectors to BPMN Connectors
    private transformConnectors(node, componentShape) {
        if (componentShape.connectors) {
            if (componentShape.connectors.component) {
                let components = componentShape.connectors.component;
                components = this.convertObjectToArray(components);
                components.forEach(component => {
                    let edgeElement = node.up().ele('bpmndi:BPMNEdge')
                        .att('id', Guid.newGuid())
                        .att('bpmnElement', component.model.identifier);
                    edgeElement.ele('di:waypoint')
                        .att('x', component.view.srcPoint.x)
                        .att('y', component.view.srcPoint.y).up();
                    if (component.view.joints) {
                        this.transformJoints(edgeElement, component.view.joints);
                    }
                    edgeElement.ele('di:waypoint')
                        .att('x', component.view.dstPoint.x)
                        .att('y', component.view.dstPoint.y)
                }
                );
            }
        }

    }

    //Converts AWD Flowobjects into BPMN Processes
    private transformFlowObject(node, flowObject) {
        if (flowObject.transitions) {
            if (flowObject.transitions.transition) {
                let transitions = flowObject.transitions.transition;
                transitions = this.convertObjectToArray(transitions);
                transitions.forEach(transition => {
                    node.ele('bpmn:outgoing', transition.$.id);
                    node.up().ele('bpmn:sequenceFlow')
                        .att('id', transition.$.id)
                        .att('sourceRef', flowObject.$.id)
                        .att('targetRef', transition.$.to);
                })
            }
        }
    }

    //If input value is an array, below function will return same array
    //If input value is an object {object}, below function will return an array with object as child. [{object}]
    private convertObjectToArray(object) {
        let _object = [];
        if (isArray(object)) {
            _object = object;
        } else {
            _object.push(object);
        }
        return _object;
    }

    //Takes AWD XML and converts to BPMN XML
    convertAWDToBMPN(xml: string): string {
        let awdJson, definition, definitionJson;
        awdJson = this.parseAWDXml(xml);
        definition = awdJson.ProcessViewRequest.saveModel.process.definition;
        definition = AwdBase64.decode(definition);
        definitionJson = this.parseAWDXml(definition);

        let flowObjects = definitionJson.processModel.xmlModel.process.model.pools.pool.lanes.lane.flowObjects.flowObject;
        let componentShapes = definitionJson.processModel.rawXML.process.rawXML.shapes.component;

        flowObjects = this.convertObjectToArray(flowObjects);
        componentShapes = this.convertObjectToArray(componentShapes);

        let root = Builder.create('bpmn:definitions')
            .att('xmlns:bpmn', 'http://www.omg.org/spec/BPMN/20100524/MODEL')
            .att('xmlns:bpmndi', 'http://www.omg.org/spec/BPMN/20100524/DI')
            .att('xmlns:dc', 'http://www.omg.org/spec/DD/20100524/DC')
            .att('xmlns:xsi', 'http://www.w3.org/2001/XMLSchema-instance')
            .att('id', 'Definitions_0awur7p')
            .att('targetNamespace', 'http://bpmn.io/schema/bpmn')
            .att('exporter', 'bpmn-js (https://demo.bpmn.io)')
            .att('exporterVersion', '3.4.0')
            .ele('bpmn:process', { 'id': 'Process_0el93ir', 'isExecutable': 'false' });

        flowObjects.forEach(flowObject => {
            switch (flowObject.$.type.toLowerCase()) {
                case awdNotations.start:
                    const startNode = root.ele(bpmnNotations.start, { 'id': flowObject.$.id, 'name': flowObject.names ? flowObject.names.name : '' });
                    this.transformFlowObject(startNode, flowObject);
                    break;
                case awdNotations.activity:
                    const taskNode = root.ele(bpmnNotations.task, { 'id': flowObject.$.id, 'name': flowObject.names ? flowObject.names.name : '' });
                    this.transformFlowObject(taskNode, flowObject);
                    break;
                case awdNotations.simpleMergeGateway:
                case awdNotations.xOrGateway:
                    const gatewayNode = root.ele(bpmnNotations.gateway, { 'id': flowObject.$.id, 'name': flowObject.names ? flowObject.names.name : '' });
                    this.transformFlowObject(gatewayNode, flowObject);
                    break;
                case awdNotations.intermediate:
                    const intermediateNode = root.ele(bpmnNotations.intermediate, { 'id': flowObject.$.id, 'name': flowObject.names ? flowObject.names.name : '' });
                    this.transformFlowObject(intermediateNode, flowObject);
                    break;
                case awdNotations.end:
                    root.ele(bpmnNotations.end, { 'id': flowObject.$.id, 'name': flowObject.names ? flowObject.names.name : '' });
                    break;
                default:
                    console.log(`Not implemented for bpmn flowobject:process: ${flowObject.$.type.toLowerCase()} `);
                    break;
            }
        });

        let bpmnDiagram = root.root()
            .ele('bpmndi:BPMNDiagram', { 'id': 'BPMNDiagram_1' })
            .ele('bpmndi:BPMNPlane', { 'id': 'BPMNPlane_1', 'bpmnElement': 'Process_0el93ir' });

        componentShapes.forEach(componentShape => {
            switch (componentShape.$.template.toLowerCase()) {
                case awdNotations.start:
                    const startNode = bpmnDiagram
                        .ele('bpmndi:BPMNShape').att('id', Guid.newGuid()).att('bpmnElement', componentShape.model.identifier)
                        .ele('dc:Bounds').att('x', componentShape.view.x).att('y', componentShape.view.y).att('width', componentShape.view.width).att('height', componentShape.view.height).up()
                    this.transformConnectors(startNode, componentShape);
                    break;
                case awdNotations.activity:
                    const activityNode = bpmnDiagram
                        .ele('bpmndi:BPMNShape').att('id', Guid.newGuid()).att('bpmnElement', componentShape.model.identifier)
                        .ele('dc:Bounds').att('x', componentShape.view.x).att('y', componentShape.view.y).att('width', componentShape.view.width).att('height', componentShape.view.height).up();
                    this.transformConnectors(activityNode, componentShape);
                    break;
                case awdNotations.gateway:
                    const gatewayNode = bpmnDiagram
                        .ele('bpmndi:BPMNShape').att('id', Guid.newGuid()).att('bpmnElement', componentShape.model.identifier)
                        .ele('dc:Bounds').att('x', componentShape.view.x).att('y', componentShape.view.y).att('width', componentShape.view.width).att('height', componentShape.view.height).up();
                    this.transformConnectors(gatewayNode, componentShape);
                    break;
                case awdNotations.intermediate:
                    const intermediateNode = bpmnDiagram
                        .ele('bpmndi:BPMNShape').att('id', Guid.newGuid()).att('bpmnElement', componentShape.model.identifier)
                        .ele('dc:Bounds').att('x', componentShape.view.x).att('y', componentShape.view.y).att('width', componentShape.view.width).att('height', componentShape.view.height).up();
                    this.transformConnectors(intermediateNode, componentShape);
                    break;
                case awdNotations.end:
                    bpmnDiagram
                        .ele('bpmndi:BPMNShape').att('id', Guid.newGuid()).att('bpmnElement', componentShape.model.identifier)
                        .ele('dc:Bounds').att('x', componentShape.view.x).att('y', componentShape.view.y).att('width', componentShape.view.width).att('height', componentShape.view.height)
                    break;
                default:
                    console.log(`Not implemented for bpmn shape:BPMNDiagram: ${componentShape.$.template} `);
                    break;
            }
        });
        let mainDefinition = root.root().end({ pretty: true })
        return mainDefinition;
    }

}
//To generate GUIDs
class Guid {
    static newGuid() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }
}

//enums for bpmn notations
enum bpmnNotations {
    start = "bpmn:startEvent",
    task = "bpmn:task",
    gateway = "bpmn:exclusiveGateway",
    intermediate = "bpmn:intermediateThrowEvent",
    end = "bpmn:endEvent"
}
//enums for awd notations
enum awdNotations {
    start = "startevent",
    activity = "activity",
    gateway = "gateway",
    simpleMergeGateway = "simplemergegateway",
    xOrGateway = "xorgateway",
    intermediate = "intermediateevent",
    end = "endevent"
}