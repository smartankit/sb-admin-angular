import {
  AfterContentInit,
  Component,
  ElementRef,
  OnDestroy,
  ViewChild,
} from '@angular/core';

import { HttpClient } from '@angular/common/http';

import * as BpmnJS from 'bpmn-js/dist/bpmn-modeler.production.min.js';
import { getBusinessObject } from 'bpmn-js/lib/util/ModelUtil';

@Component({
  selector: 'app-diagram',
  template: `
    <div #ref class="diagram-container"></div>
    <input type="button" value="save xml" (click)="saveXml()" />
    <div *ngIf="showProcessPanel">
      <app-process-panel-properties [processProps]="processProps" (updatedProcessProps)="onUpdatedProcessProps($event)"></app-process-panel-properties>
    </div>
    <div *ngIf="showStartPanel">
      <app-start-panel-properties [startProps]="startProps" (updatedStartProps)="onUpdatedStartProps($event)"></app-start-panel-properties>
    </div>
    <div *ngIf="showTaskPanel">
      <app-task-panel-properties [taskProps]="taskProps" (updatedTaskProps)="onUpdatedTaskProps($event)"></app-task-panel-properties>
    </div>
  `,
  styles: [
    `
    html, body {
      margin: 0; padding : 0;
    }
    .diagram-container {
      height: 400px;
      width: 100%;
      border: 1px solid lightgray;
    }
    `
  ]
})
export class DiagramComponent implements AfterContentInit, OnDestroy {
  bpmnJS: BpmnJS;
  eventBus: any;
  modeling: any;
  moddle: any;
  elementRegistry: any;
  elementFactory: any;

  selectedBpmnNotation: any;
  showProcessPanel: boolean = false;
  showStartPanel: boolean = false;
  showTaskPanel: boolean = false;

  processProps: any = {
    name: '',
    description: '',
    status: '',
    queue: ''
  }

  startProps: any = {
    name: '',
    description: ''
  }

  taskProps: any = {
    name: '',
    description: ''
  }

  @ViewChild('ref', {}) private el: ElementRef;

  constructor(private http: HttpClient) { }

  ngAfterContentInit(): void {
    this.bpmnJS = new BpmnJS({
      container: this.el.nativeElement,
    });

    this.bpmnJS.on('import.done', ({ error }) => {
      if (!error) {
        this.bpmnJS.get('canvas').zoom('fit-viewport');
      }
    });

    this.loadUrl();

    this.eventBus = this.bpmnJS.get('eventBus');
    this.modeling = this.bpmnJS.get('modeling');
    this.moddle = this.bpmnJS.get('moddle');
    this.elementRegistry = this.bpmnJS.get('elementRegistry');
    this.elementFactory = this.bpmnJS.get('elementFactory');

    this.eventBus.on('element.click', (e) => {
      // console.log(e.element.type);

      this.showProcessPanel = false;
      this.showStartPanel = false;
      this.showTaskPanel = false;

      if (e.element.type === 'bpmn:Process') {
        this.showProcessPanel = true;
        this.selectedBpmnNotation = e;
      }
      else if (e.element.type === 'bpmn:StartEvent') {
        this.showStartPanel = true;
        this.selectedBpmnNotation = e;
      }
      else if (e.element.type === 'bpmn:Task') {
        this.showTaskPanel = true;
        this.selectedBpmnNotation = e;
      }
    });

  }

  ngOnDestroy(): void {
    this.bpmnJS.destroy();
  }

  importDoneCb = (s: any, e: any) => {
    console.log(s, e);
  }

  loadUrl() {
    this.bpmnJS.createDiagram(this.importDoneCb);
  }

  saveDoneCb(e, w) {
    console.log(w);
  }

  saveXml(e) {
    this.bpmnJS.saveXML({}, this.saveDoneCb);
  }

  getExtensionElement(element, type) {
    if (!element.extensionElements) {
      return;
    }

    return element.extensionElements.values.filter((extensionElement) => {
      return extensionElement.$instanceOf(type);
    })[0];
  }



  onUpdatedProcessProps(event) {
    var camundaNs = 'http://camunda.org/schema/1.0/bpmn';
    
    var status = this.moddle.createAny('camunda:inputParameter', camundaNs, {
      name: 'status',
      $body: event.status
    });

    var queue = this.moddle.createAny('camunda:inputParameter', camundaNs, {
      name: 'queue',
      $body: event.queue
    });
    

    var statusAndQueue = this.moddle.createAny('camunda:statusAndQueue', camundaNs, {
      $children: [
        status,
        queue
      ]
    });

    var extensionElements = this.moddle.create('bpmn:ExtensionElements', {
      values: [ statusAndQueue ]
    });
    
    this.modeling.updateProperties(this.selectedBpmnNotation.element,
      {
        extensionElements: extensionElements,
        name: event.name,
        description: event.description,
      }
    );
    this.processProps = event;
  }


  onUpdatedStartProps(event) {
    this.modeling.updateProperties(this.selectedBpmnNotation.element,
      {
        name: event.name,
        description: event.description
      }
    );
    this.startProps = event;
  }
  onUpdatedTaskProps(event) {
    this.modeling.updateProperties(this.selectedBpmnNotation.element,
      {
        name: event.name,
        description: event.description
      }
    );
    this.taskProps = event;
  }
}

