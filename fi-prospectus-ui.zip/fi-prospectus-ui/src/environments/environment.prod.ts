export const environment = {
  production: true,
  baseUrl: 'http://re-cdn.staging.marketpipe.com/fi-prospectus-ui/1.0.0/'
};
