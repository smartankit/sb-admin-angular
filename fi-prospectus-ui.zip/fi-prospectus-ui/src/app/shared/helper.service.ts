import { Injectable } from '@angular/core';
import {
  CupcakePopoverBindToTargetResult,
  CupcakePopoverOptions,
  CupcakePopoverService
} from '@ipreo/cupcake-components';

@Injectable()
export class HelperService {

  constructor(private popoverService: CupcakePopoverService) { }

  showTooltip(element: any, message: string) {
    element.classList.add('invalidInput');
    element.popover = this.popoverService.bindToTarget(element, new CupcakePopoverOptions({
      position: 'right',
      rootCssClass: 'c-popover-danger',
      text: message,
      trigger: 'hover'
    }));
  }

  showAnyTooltip(element: any, position: any, rootCssClass: string, text: string, trigger: any) {
    element.popover = this.popoverService.bindToTarget(element, new CupcakePopoverOptions({
      position: position,
      rootCssClass: rootCssClass,
      text: text,
      trigger: trigger
    }));
  }

  hideTooltip(element: any): void {
    if (element.popover) {
      if (element.classList) {
        element.classList.remove('invalidInput');
      }
      element.popover.close();
      element.popover.response.complete();
      element.popover = null;
    }
  }

  convertTime12to24(time12h) {
    const [time, modifier] = time12h.split(' ');
    let [hours] = time.split(':');

    if (hours === '12') {
      hours = '00';
    }

    if (modifier === 'PM') {
      hours = parseInt(hours, 10) + 12;
    }

    return hours + ':00:00';
  }

  convertTime24ToAmPM(time) {

    let timeString = time;
    const H = +timeString.substr(0, 2);

    const h = H % 12 || 12;
    const ampm = (H < 12 || H === 24) ? 'AM' : 'PM';
    return timeString = h < 10 ? '0' + h + ':00:00 ' + ampm : h + ':00:00 ' + ampm;
  }

}
