import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';
import { RouterLinkRendererComponent } from './router-link-rendererer.component';
import { RouterTestingModule } from '@angular/router/testing';
import { ProspectusCommonModule } from '../../../common';
import { PackageService } from '../../packages/package.service';

describe('RouterLinkRendererComponent', () => {

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpClientModule,
        ProspectusCommonModule.forRoot()
      ],
      declarations: [
        RouterLinkRendererComponent
      ],
      providers: [
        PackageService
      ]
    }).compileComponents();
  }));

  it('should create', async(() => {
    const fixture = TestBed.createComponent(RouterLinkRendererComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  }));
});
