import { Component, ElementRef, OnInit, EventEmitter, Output, Inject, Input } from '@angular/core';
import { EmailTemplateService } from './email-template.service';
import { EmailTemplateDto } from '../../../../common';
// Any plugins you want to use has to be imported
declare var tinymce: any;

@Component({
  selector: 'app-text-editor',
  template: `<div id="tinyFormGroup" class="form-group">
    <div class="hidden" style="display:none">
        <textarea  id="editorial" style="width: 100%; height: 20em" id="baseTextArea">{{htmlContent}}</textarea>
    </div>
</div>`,
  styleUrls: ['./text-editor.component.scss'],
})

export class TextEditorComponent implements OnInit {
  @Input()
  public height: string;
  @Input()
  public width: string;
  @Input()
  public set mceContent(content) {
    const elem = document.getElementById(this.textEditorElementId);
    if (!elem) {
      return;
    }
    if (this.editor && content !== null) {
      this.editor.setContent(content);
    }
  }
  @Input()
  public set templateId(id) {
    if (!id) {
      return;
    }

    this.emailTemplateId = id;
    const ele = document.getElementsByClassName('mce-i-ddlEmailTemplate');
    if (ele && ele.length > 0) {
      const template = this.emailTemplates.find(item => item.id === this.emailTemplateId);
      ele[0].nextSibling.textContent = template.name;
    }
  }
  @Output()
  public contentChanged: EventEmitter<any>;

  private editor: any;
  private elementRef: ElementRef;
  private textEditorElementId: string;
  public htmlContent: string;
  public emailTemplates: EmailTemplateDto[] = [];
  public emailTemplateId;

  constructor(@Inject(ElementRef) elementRef: ElementRef, private emailTemplateService: EmailTemplateService) {
    this.elementRef = elementRef;

    const randLetter = String.fromCharCode(65 + Math.floor(Math.random() * 26));
    const uniqid = randLetter + Date.now();

    this.textEditorElementId = 'tinymce' + uniqid;
    this.contentChanged = new EventEmitter();

    // setting default values
    if (!this.height) {
      this.height = '300';
    }

    if (!this.width) {
      this.width = '100%';
    }

    this.emailTemplateService.getTemplates();
  }

  ngOnInit() {
    // Clone base textarea

    const baseTextArea = this.elementRef.nativeElement.querySelector('#baseTextArea');
    const clonedTextArea = baseTextArea.cloneNode(true);
    clonedTextArea.id = this.textEditorElementId;

    const formGroup = this.elementRef.nativeElement.querySelector('#tinyFormGroup');
    formGroup.appendChild(clonedTextArea);

    // Attach tinyMCE to cloned textarea
    this.emailTemplateService.templates$.subscribe(items => {
      if (!items) {
        return;
      }

      this.emailTemplates = items;
      tinymce.init(
        {
          mode: 'exact',
          width: this.width,
          // skin: false,
          height: this.height,
          theme: 'modern',
          statusbar: false,
          readonly: 0,
          menubar: false,
          toolbar: 'lblEmailTemplate ddlEmailTemplate fontselect fontsizeselect bold italic underline'
            + ' strikethrough alignleft aligncenter alignright alignjustify',
          elements: this.textEditorElementId,
          setup: this.tinyMCESetup.bind(this)
        }
      );
    });
  }

  tinyMCESetup(ed) {
    const that = this;
    this.editor = ed;
    const emailTemplateLists = this.emailTemplates.map(template => {
      return {
        id: template.id,
        text: template.name,
        value: template.templateBody
      };
    });

    ed.addButton('lblEmailTemplate', {
      type: 'label',
      text: 'Email Template ',
      classes: 'temlabel'
    });

    ed.addButton('ddlEmailTemplate', {
      type: 'listbox',
      classes: 'emailbody',

      onselect: function (e) {
        const templateName = document.getElementsByClassName('mce-i-ddlEmailTemplate')[0].nextSibling.textContent;
        const template = emailTemplateLists.find(item => item.text === templateName);
        ed.setContent(this.value());
        that.contentChanged.emit(template);
      },
      values: emailTemplateLists
    });

    ed.on('init', function (e) {
      this.editor = ed;
      if (that.emailTemplateId) {
        const template = that.emailTemplates.find(item => item.id === that.emailTemplateId);
        document.getElementsByClassName('mce-i-ddlEmailTemplate')[0].nextSibling.textContent = template.name;
      } else {
        if (!emailTemplateLists || emailTemplateLists.length === 0) {
          return;
        }

        ed.setContent(emailTemplateLists[0]['value']);

        const templateName = document.getElementsByClassName('mce-i-ddlEmailTemplate')[0].nextSibling.textContent;
        const selectedTemplate = that.emailTemplates.find(item => item.name === templateName);
        const emailTemplate = {
          id: selectedTemplate.id,
          value: selectedTemplate.templateBody
        };

        that.contentChanged.emit(emailTemplate);
      }
    });

    ed.on('keyup', this.tinyMCEOnKeyup.bind(this));
  }

  tinyMCEOnKeyup(e) {
    const templateName = document.getElementsByClassName('mce-i-ddlEmailTemplate')[0].nextSibling.textContent;
    const selectedTemplate = this.emailTemplates.find(item => item.name === templateName);
    const emailTemplate = {
      id: selectedTemplate.id,
      value: tinymce.get(this.textEditorElementId).getContent()
    };

    this.contentChanged.emit(emailTemplate);
  }
}
