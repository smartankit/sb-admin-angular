import { Injectable } from '@angular/core';
import { Observable, Subject, BehaviorSubject } from 'rxjs';
import { tap, map, catchError } from 'rxjs/operators';

import {
  ApiService, EmailTemplateDto
} from '../../../../common';



@Injectable()
export class EmailTemplateService {

  private emailtemplates = new BehaviorSubject<EmailTemplateDto[]>(null);

  constructor(private apiService: ApiService) { }

  public get templates$(): Observable<EmailTemplateDto[]> {
    return this.emailtemplates.asObservable();
  }
  public getTemplates() {
    this.apiService.getEmailTemplates().subscribe((emailtemplates: EmailTemplateDto[]) => {
      this.emailtemplates.next(emailtemplates);
    });
  }
}

