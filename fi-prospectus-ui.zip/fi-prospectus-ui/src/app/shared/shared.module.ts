import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TextEditorComponent } from './component/text-editor/text-editor.component';
import { EmailTemplateService } from './component/text-editor/email-template.service';
import { FormsModule } from '@angular/forms';
@NgModule({
  imports: [
    FormsModule,
    CommonModule
  ],
  exports: [TextEditorComponent],
  declarations: [TextEditorComponent],
  bootstrap: [],
  providers: [
    EmailTemplateService
  ]
})
export class SharedModule { }
