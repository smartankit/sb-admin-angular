import { AppContext, FiAuthService } from '../common';
import { Router } from '@angular/router';
import { ProspectusAuthConfig } from './auth.config';
import { Component, OnInit, ElementRef, isDevMode, ViewChild } from '@angular/core';
import { PackageService } from './packages/package.service';
import { TabType } from 'src/common/enum';

declare let require: any;
@Component({
  selector: 'app-prospectus',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

  public dealName: string;
  tabType: typeof TabType = TabType;
  @ViewChild('divNoDealMessage') divNoDealMessage: ElementRef;
  constructor(
    private elementRef: ElementRef,
    private packageService: PackageService,
    public appContext: AppContext,
    private authService: FiAuthService,
    private router: Router
  ) {
    this.appContext.init(this.elementRef);

    const authConfig = new ProspectusAuthConfig()
    authConfig.setIssuer(this.appContext.authServerUrl)
    this.logout();
    this.authService.authenticate(authConfig)
    this.authService.authenticated$.subscribe(user => {
      if (!user) {
        return;
      }

      this.packageService.refresh();

      let navigateRoute;
      switch (this.appContext.tabToSelect) {
        case 'package':
          navigateRoute = 'packages/view';
          break;
        case 'tracking':
          navigateRoute = 'packages/tracking';
          break;
        case 'documents':
        default:
          navigateRoute = 'documents/view';
          break;
      }

      this.router.navigate([navigateRoute]);
    })
  }

  logout() {
    localStorage.removeItem('fi-prospectus-access_token');
  }

  ngOnInit() {
    if (isDevMode()) {
      require('style-loader!./../default.css');
    }

    this.packageService.deal$.subscribe(deal => {
      if (!deal) {
        return;
      }

      this.dealName = deal.name;
    });
  }
}
