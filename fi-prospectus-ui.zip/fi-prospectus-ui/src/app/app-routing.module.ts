import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreatePackageComponent } from './packages/create/create.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { DocumentsComponent } from './documents/documents.component';
import { PackagesViewComponent } from './packages/view/view.component';
import { TrackingComponent } from './packages/tracking/tracking.component';
import { FiAuthGuard } from '../common';
import { LoginComponent } from './login/login.component';
import { FiNoAccessGuard } from 'src/common/auth';

const routes: Routes = [
  { path: '', component: LoginComponent, canActivate: [FiNoAccessGuard] },
  { path: 'packages/create', component: CreatePackageComponent, canActivate: [FiAuthGuard] },
  { path: 'documents/view', component: DocumentsComponent, canActivate: [FiAuthGuard] },
  { path: 'packages/view', component: PackagesViewComponent, canActivate: [FiAuthGuard] },
  { path: 'packages/create/:id', component: CreatePackageComponent, canActivate: [FiAuthGuard] },
  { path: 'packages/tracking/:id', component: TrackingComponent, canActivate: [FiAuthGuard] },
  { path: 'packages/tracking', component: TrackingComponent, canActivate: [FiAuthGuard] },
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {initialNavigation: false, enableTracing: false})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
