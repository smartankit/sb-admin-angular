import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { of, Observable, BehaviorSubject } from 'rxjs';
import { CupcakeModalOptions, CupcakeModalService } from '@ipreo/cupcake-components';
import { DocumentsComponent } from './documents.component';
import { NotificationService } from '../../common/notification/notification.service';
import { DocumentDto, AppContext } from '../../common';
import { DealType } from '../../common/enum';
import { DocumentService } from './document.service';
import { HelperService } from '../shared/helper.service';

describe('DocumentsComponent', () => {
  let fixture: ComponentFixture<DocumentsComponent>;
  let component: DocumentsComponent;
  let mockDocumentService: DocumentService;
  let mockNotificationService: NotificationService;
  let mockCupcakeModalService: CupcakeModalService;
  let mockHelperService: HelperService;
  const documents = new BehaviorSubject<DocumentDto[]>(null);
  const documentNameTypes = ['Internal Research', 'External Research', 'Prospectus', 'Issuer Web Page', 'News', 'Roadshow'];
  const fileTypes = ['File']; // ['URL', 'File'];
  const disclaimerTypes = ['Standard', 'Non Standard'];
  const editWarning = 'You have unsaved changes. Are you sure you want to edit a different document?';
  const editDeleteWarning = 'You have unsaved changes. Please confirm if you want to delete other document.';
  const deleteWarning = 'Please confirm if you want to delete this document.';
  const dealTypes = [DealType.DealWide, DealType.TrancheSpecific];
  const warningModalOptions: CupcakeModalOptions = {
    mode: 'component',
    title: 'Warning',
    type: 'danger',
    context: {
      buttons: [{
        title: 'Cancel', action: 'cancel'
      }, {
        title: 'OK', action: 'Ok'
      }]
    },
    rootCssClass: 'delete-warning'
  };
  const gridOptions: any = {
    api: {
      redrawRows: function (x: any) {
      },
      hideOverlay: function () {
      },
      sizeColumnsToFit: function () {
      },
      updateRowData: function () {
      },
      resetRowHeights: function (x: any) {
      },
      getDisplayedRowAtIndex: function (x: any) {
        return {
          data: {

          }
        };
      }
    }
  };
  const mockNewDocument = {
    'id': null,
    'name': documentNameTypes[0],
    'fileSize': null,
    'fileName': null,
    'documentType': fileTypes[0],
    'disclaimer': disclaimerTypes[0],
    'isDealWide': true,
    'firmId': null,
    'dealId': null,
    'trancheId': null,
    'editable': true,
  };
  const sampleDocuments = [
    {
      'name': 'Prospecus Document',
      'fileSize': '234kb',
      'documentType': 'File',
      'isDocumentTypeUrl': false,
      'fileName': '',
      'disclaimer': 'Standard',
      'isDealWide': true,
      'sourceId': 1,
      'firmId': 1,
      'dealId': 1,
      'trancheId': 1,
      'id': '1',
      'delete': true,
      'fileToUpload': null,
      'isUsed': false,
      'isPackageSent': false,
      'rowVersion': 1
    },
    {
      'name': 'Prospecus Document2',
      'isDocumentTypeUrl': false,
      'fileSize': '958kb',
      'documentType': 'File',
      'fileName': '',
      'disclaimer': 'Standard',
      'isDealWide': false,
      'sourceId': 3,
      'firmId': 1,
      'dealId': 1,
      'trancheId': 1,
      'id': '3',
      'fileToUpload': null,
      'isUsed': false,
      'isPackageSent': false,
      'rowVersion': 2
    }
  ];
  const params = {
    api: {
      sizeColumnsToFit: function () {
      },
      hideOverlay: function () {
      },
      getDisplayedRowAtIndex: function (rowIndex: number) {
        return { data: sampleDocuments[rowIndex] };
      },
      getDisplayedRowCount: function () {
        return sampleDocuments.length;
      }
    },
    colDef: {
      colId: null,
      type: null,
      field: null
    },
    data: {
      editable: true,
      fileName: null,
      documentType: null
    }
  };
  const documentServiceStub = {
    get documents$(): Observable<any[]> {
      return documents.asObservable();
    },
    getDocuments: function () {
    },
    downloadDocument: function () {
    },
    getDocumentNameTypes: function (): Observable<string[]> {
      return of(documentNameTypes);
    },
    deleteDocuments: function (id: string, isUsedPackage: boolean) {
      return of([]);
    },
    saveDocument: function () {
      return new Promise(
        (resolve, reject) => {
          resolve();
        }
      );
    },
    updateDocument: function () {
      return new Promise(
        (resolve, reject) => {
          resolve();
        }
      );
    }
  };
  const notificationServiceStub = {
    success: function () {
    },
    error: function () {
    }
  };
  const cupcakeModalServiceStub = {
    open: function (options: CupcakeModalOptions) {
      return of({ action: 'Ok' });
    }
  };
  const appContextStub = {
    firmId: 1,
    dealId: 1,
    trancheId: 1
  };
  const helperServiceStub = {
    showTooltip: function () {
    },
    hideTooltip: function () {
    }
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DocumentsComponent],
      schemas: [
        NO_ERRORS_SCHEMA,
        CUSTOM_ELEMENTS_SCHEMA
      ],
      providers: [
        {
          provide: DocumentService, useValue: documentServiceStub
        },
        {
          provide: NotificationService, useValue: notificationServiceStub
        },
        {
          provide: CupcakeModalService, useValue: cupcakeModalServiceStub
        },
        {
          provide: AppContext, useValue: appContextStub
        },
        {
          provide: HelperService, useValue: helperServiceStub
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentsComponent);
    component = fixture.componentInstance;
    mockDocumentService = TestBed.get(DocumentService);
    mockNotificationService = TestBed.get(NotificationService);
    mockCupcakeModalService = TestBed.get(CupcakeModalService);
    mockHelperService = TestBed.get(HelperService);
    component.gridApi = params.api;
    component.gridOptions = gridOptions;
    component.ngOnInit();
  });

  it('Should initialize the component by loading all values', () => {
    spyOn(mockDocumentService, 'getDocuments').and.callThrough();
    spyOn(mockDocumentService, 'getDocumentNameTypes').and.callThrough();
    component.ngOnInit();
    expect(mockDocumentService.getDocuments).toHaveBeenCalled();
    expect(mockDocumentService.getDocumentNameTypes).toHaveBeenCalled();
    expect(component.documentNameTypes).toEqual(documentNameTypes);
    expect(component.fileTypes).toEqual(fileTypes);
    expect(component.disclaimerTypes).toEqual(disclaimerTypes);
    expect(component.dealTypes).toEqual(dealTypes);
  });

  it('should load grid data', () => {
    component.loadData();
    documents.next(sampleDocuments);
    expect(component.rowData).toEqual(sampleDocuments);
  });

  it('should handle grid ready event', () => {
    component.disableAddDocumentsButton = true;
    spyOn(component, 'loadData');
    component.onGridReady(params);
    expect(component.disableAddDocumentsButton).toEqual(false);
    expect(component.loadData).toHaveBeenCalled();
  });

  it('should select correct column renderer', () => {
    params.colDef.type = 'actionColumn';
    expect(component.columnRendererSelector(params).component).toBe('actionsRendererComponent');
    params.colDef.type = null;
    params.colDef.colId = 'dealOrTranche';
    expect(component.columnRendererSelector(params).component).toBe('documentDealTypeRendererComponent');
    params.colDef.colId = null;
    params.colDef.field = 'name';
    expect(component.columnRendererSelector(params).component).toBe('documentNameRendererComponent');
    params.colDef.field = 'documentType';
    expect(component.columnRendererSelector(params).component).toBe('documentTypeRendererComponent');
    params.colDef.field = 'fileName';
    expect(component.columnRendererSelector(params).component).toBe('documentFileNameRendererComponent');
  });

  it('should validate document', () => {
    let errorMessageEmptyFile, errorMessageInvalidFile, spyShowTooltip;
    const sampleFileName = 'Prospectus.pdf';
    const invalidFileName = 'Prospectus.exe';
    const mockDocument = '<div></div>';
    errorMessageInvalidFile = 'This document is not valid and can not be uploaded. Allowed file formats are .doc, .docx,'
      + '.xls, .xlsx, .rtf, .pdf, .gif';
    errorMessageEmptyFile = 'Document is not a file';
    spyOn(document, 'querySelector').and.returnValue(mockDocument);
    spyShowTooltip = spyOn(mockHelperService, 'showTooltip');
    spyOn(mockHelperService, 'hideTooltip');
    params.data.documentType = 'URL';
    params.data.fileName = null;
    expect(component.validateDocument(params)).toEqual(false);
    expect(mockHelperService.showTooltip).toHaveBeenCalledWith(mockDocument, errorMessageEmptyFile);
    spyShowTooltip.calls.reset();
    params.data.fileName = sampleFileName;
    expect(component.validateDocument(params)).toEqual(true);
    expect(mockHelperService.showTooltip).not.toHaveBeenCalled();
    params.data.documentType = 'File';
    params.data.fileName = null;
    expect(component.validateDocument(params)).toEqual(false);
    expect(mockHelperService.showTooltip).toHaveBeenCalledWith(mockDocument, errorMessageEmptyFile);
    spyShowTooltip.calls.reset();
    params.data.fileName = sampleFileName;
    expect(component.validateDocument(params)).toEqual(true);
    expect(mockHelperService.showTooltip).not.toHaveBeenCalled();
    spyShowTooltip.calls.reset();
    params.data.fileName = invalidFileName;
    expect(component.validateDocument(params)).toEqual(false);
    expect(mockHelperService.showTooltip).toHaveBeenCalledWith(mockDocument, errorMessageInvalidFile);
  });

  it('should create new row in ag-grid', () => {
    let spyModalOpen, newDocument;
    newDocument = Object.assign({}, mockNewDocument);
    spyOn(component, 'createNewDocumentOK').and.callThrough();
    spyModalOpen = spyOn(mockCupcakeModalService, 'open').and.callThrough();
    spyOn(component.gridOptions.api, 'redrawRows').and.callThrough();
    component.editableRows.push({ data: newDocument });
    component.createNewDocument();
    warningModalOptions.context.text = editWarning;
    expect(mockCupcakeModalService.open).toHaveBeenCalledWith(warningModalOptions);
    expect(component.gridOptions.api.redrawRows).toHaveBeenCalled();
    expect(component.createNewDocumentOK).toHaveBeenCalled();
    component.editableRows = [];
    spyModalOpen.calls.reset();
    component.createNewDocument();
    expect(mockCupcakeModalService.open).not.toHaveBeenCalledWith(warningModalOptions);
    expect(component.createNewDocumentOK).toHaveBeenCalled();
  });

  it('should handle success of new row creation', () => {
    component.disableAddDocumentsButton = false;
    spyOn(component.gridApi, 'getDisplayedRowCount').and.callThrough();
    spyOn(component.gridOptions.api, 'updateRowData').and.callThrough();
    spyOn(component.gridOptions.api, 'resetRowHeights').and.callThrough();
    component.createNewDocumentOK();
    expect(component.disableAddDocumentsButton).toBe(true);
    expect(component.gridApi.getDisplayedRowCount).toHaveBeenCalled();
    expect(component.gridOptions.api.updateRowData).toHaveBeenCalledWith({ add: [mockNewDocument], addIndex: sampleDocuments.length });
    expect(component.gridOptions.api.resetRowHeights).toHaveBeenCalled();
  });

  it('should save new document', () => {
    let rowData, newDocument;
    const saveIndex = 0;
    rowData = component.gridApi.getDisplayedRowAtIndex(saveIndex).data;
    rowData.fileToUpload = 'Prospectus.pdf';
    newDocument = {
      disclaimer: rowData.disclaimer,
      documentType: rowData.documentType,
      isDealWide: rowData.isDealWide,
      name: rowData.name,
      fileName: rowData.fileName,
      firmId: appContextStub.firmId,
      dealId: appContextStub.dealId,
      trancheId: appContextStub.trancheId
    };
    spyOn(component.gridApi, 'getDisplayedRowAtIndex').and.callThrough();
    spyOn(mockDocumentService, 'saveDocument').and.callThrough();
    component.saveNewDocument(saveIndex);
    expect(component.gridApi.getDisplayedRowAtIndex).toHaveBeenCalledWith(saveIndex);
    expect(mockDocumentService.saveDocument).toHaveBeenCalledWith(newDocument, rowData.fileToUpload);
  });

  it('should edit existing row in ag-grid', () => {
    let spyModalOpen, newDocument;
    newDocument = Object.assign({}, mockNewDocument);
    spyOn(component, 'editExistingDocumentOK').and.callThrough();
    spyModalOpen = spyOn(mockCupcakeModalService, 'open').and.callThrough();
    spyOn(component.gridOptions.api, 'redrawRows').and.callThrough();
    component.editableRows.push({ data: newDocument });
    component.editExistingDocument(params);
    warningModalOptions.context.text = editWarning;
    expect(mockCupcakeModalService.open).toHaveBeenCalledWith(warningModalOptions);
    expect(component.gridOptions.api.redrawRows).toHaveBeenCalled();
    expect(component.editExistingDocumentOK).toHaveBeenCalledWith(params);
    component.editableRows = [];
    spyModalOpen.calls.reset();
    component.createNewDocument();
    expect(mockCupcakeModalService.open).not.toHaveBeenCalledWith(warningModalOptions);
    expect(component.editExistingDocumentOK).toHaveBeenCalled();
  });

  it('should handle success of editing of existing document in ag-grid', () => {
    const editRow = [], editIndex = 0;
    spyOn(component.gridOptions.api, 'getDisplayedRowAtIndex').and.callThrough();
    spyOn(component.gridOptions.api, 'redrawRows').and.callThrough();
    spyOn(component.gridOptions.api, 'resetRowHeights').and.callThrough();
    editRow.push(component.gridOptions.api.getDisplayedRowAtIndex(editIndex));
    component.editExistingDocumentOK(params);
    expect(component.gridOptions.api.getDisplayedRowAtIndex).toHaveBeenCalled();
    expect(component.gridOptions.api.redrawRows).toHaveBeenCalledWith({ rowNodes: editRow });
    expect(component.gridOptions.api.resetRowHeights).toHaveBeenCalled();
  });

  it('should update existing document', () => {
    let newDocument;
    const saveIndex = 0;
    newDocument = component.gridApi.getDisplayedRowAtIndex(saveIndex).data;
    newDocument.fileToUpload = 'Prospectus.pdf';
    spyOn(component.gridApi, 'getDisplayedRowAtIndex').and.callThrough();
    spyOn(mockDocumentService, 'updateDocument').and.callThrough();
    component.updateExistingDocument(saveIndex);
    expect(component.gridApi.getDisplayedRowAtIndex).toHaveBeenCalledWith(saveIndex);
    expect(mockDocumentService.updateDocument).toHaveBeenCalledWith(newDocument, newDocument.fileToUpload, undefined);
  });

  it('should cancel editing of new document', () => {
    const deleteIndex = 0;
    component.disableAddDocumentsButton = true;
    spyOn(component.gridApi, 'getDisplayedRowAtIndex').and.callThrough();
    spyOn(component.gridOptions.api, 'updateRowData').and.callThrough();
    component.cancelEditNewDocument(deleteIndex);
    expect(component.disableAddDocumentsButton).toBe(false);
    expect(component.gridApi.getDisplayedRowAtIndex).toHaveBeenCalledWith(deleteIndex);
    expect(component.gridOptions.api.updateRowData).toHaveBeenCalledWith({ remove: [sampleDocuments[deleteIndex]] });
  });

  it('should cancel editing of existing document', () => {
    const deleteIndex = 0;
    component.disableAddDocumentsButton = true;
    component.editableRows.push({ data: mockNewDocument });
    component.editableRowsOrigData = JSON.parse(JSON.stringify(component.editableRows[0].data));
    spyOn(component.gridOptions.api, 'redrawRows').and.callThrough();
    spyOn(component.gridOptions.api, 'resetRowHeights').and.callThrough();
    component.cancelEditExistingDocument(deleteIndex);
    expect(component.disableAddDocumentsButton).toBe(false);
    expect(component.gridOptions.api.redrawRows).toHaveBeenCalled();
    expect(component.gridOptions.api.resetRowHeights).toHaveBeenCalled();
  });

  it('should delete existing document with proper warning message', () => {
    let spyModalOpen, newDocument;
    const mockId = '123';
    const isUsedPackage = false;
    warningModalOptions.context.text = editDeleteWarning;
    newDocument = Object.assign({}, mockNewDocument);
    component.editableRows.push({ data: newDocument });
    spyModalOpen = spyOn(mockCupcakeModalService, 'open').and.callThrough();
    spyOn(mockDocumentService, 'deleteDocuments').and.callThrough();
    spyOn(mockNotificationService, 'success').and.callThrough();
    spyOn(mockDocumentService, 'getDocuments').and.callThrough();
    component.deleteExistingDocument(mockId, isUsedPackage);
    expect(mockCupcakeModalService.open).toHaveBeenCalledWith(warningModalOptions);
    expect(mockDocumentService.deleteDocuments).toHaveBeenCalledWith(mockId);
    expect(mockNotificationService.success).toHaveBeenCalledWith('Successfully deleted the document');
    expect(mockDocumentService.getDocuments).toHaveBeenCalled();
    warningModalOptions.context.text = deleteWarning;
    spyModalOpen.calls.reset();
    component.editableRows = [];
    component.deleteExistingDocument(mockId, isUsedPackage);
    expect(mockCupcakeModalService.open).toHaveBeenCalledWith(warningModalOptions);
  });

  it('Should download document on cell click', () => {
    let spyDownloadDocument, mockClickEvent;
    mockClickEvent = {
      colDef: {
        field: null
      },
      data: {
        editable: null
      }
    };
    spyDownloadDocument = spyOn(mockDocumentService, 'downloadDocument');
    mockClickEvent.colDef.field = 'fileName';
    mockClickEvent.data.editable = false;
    component.onCellClicked(mockClickEvent);
    expect(mockDocumentService.downloadDocument).toHaveBeenCalledWith(mockClickEvent.data);
    spyDownloadDocument.calls.reset();
    mockClickEvent.colDef.field = 'notFileName';
    mockClickEvent.data.editable = false;
    component.onCellClicked(mockClickEvent);
    expect(mockDocumentService.downloadDocument).not.toHaveBeenCalled();
    spyDownloadDocument.calls.reset();
    mockClickEvent.colDef.field = 'fileName';
    mockClickEvent.data.editable = true;
    component.onCellClicked(mockClickEvent);
    expect(mockDocumentService.downloadDocument).not.toHaveBeenCalled();
    spyDownloadDocument.calls.reset();
  });

});
