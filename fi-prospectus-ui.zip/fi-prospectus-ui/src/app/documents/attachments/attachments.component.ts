import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ColDef, GridOptions, GridApi, CellClickedEvent } from 'ag-grid';
import { Subject } from 'rxjs/internal/Subject';
import { DocumentDto } from '../../../common';
import { DocumentService } from '../document.service';
import { DealType } from '../../../common/enum';

@Component({
  selector: 'app-attachments',
  templateUrl: './attachments.component.html',
  styleUrls: ['./attachments.component.scss']
})
export class AttachmentsComponent implements OnInit {
  @Input() show;
  @Output() showChange: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Input() selectedDocuments;
  @Output() displayDocuments: EventEmitter<DocumentDto[]> = new EventEmitter<DocumentDto[]>();

  public columnDefs: ColDef[];
  public gridOptions: GridOptions;
  public gridApi: GridApi;
  public rowData: DocumentDto[] = [];
  public selectedRows: DocumentDto[] = [];
  public overlayNoRowsTemplate: string;

  constructor(private documentService: DocumentService) {
    this.columnDefs = [
      {
        field: 'select',
        headerName: '',
        width: 80,
        headerCheckboxSelection: true,
        checkboxSelection: true,
      },
      {
        headerName: 'Document Name',
        field: 'name',
        sort: 'asc',
        unSortIcon: true
      },
      {
        headerName: 'Type',
        field: 'documentType',
        unSortIcon: true
      },
      {
        headerName: 'Path',
        field: 'fileName',
        tooltipField: 'fileName',
        unSortIcon: true,
        cellClass: 'c-a'
      },
      // {
      //   headerName: 'Dislaimer',
      //   field: 'disclaimer',
      //   unSortIcon: true
      // },
      {
        headerName: 'Deal/Tranche',
        unSortIcon: true,
        valueGetter: (params) => {
          const dealOrTranche: DocumentDto[] = params.data.isDealWide;

          return dealOrTranche ? DealType.DealWide : DealType.TrancheSpecific;
        }
      },
    ];

    this.gridOptions = {
      columnDefs: this.columnDefs,
      context: {
        componentParent: this
      },
      icons: {
        checkboxChecked: '<i class="fa fa-check-square c-text-primary selectAll-icon"></i>',
      },
      rowSelection: 'multiple',
    };

    this.overlayNoRowsTemplate =
      '<span style=\"padding: 10px; border: 2px solid #444; background: lightgoldenrodyellow;\">No Documents are available</span>';
  }

  ngOnInit() {
    this.documentService.getDocuments(true);
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridOptions.api.sizeColumnsToFit();
    this.loadData();
  }

  private loadData(): void {

    this.documentService.documents$.subscribe(items => {
      if (!items) {
        return;
      }

      this.rowData = items;
    });
  }

  onCellClicked(event: CellClickedEvent): void {
    if (event.colDef.field === 'fileName') {
      this.documentService.downloadDocument(event.data);
    }
  }

  onModelUpdated(params) {
    params.api.forEachNode(node => {
      const item = this.selectedDocuments.find(x => x.id === node.data.id);
      if (item && item.id === node.data.id) {
        node.setSelected(true);
      }
    });
  }

  onSelectionChanged(event) {
    this.selectedRows = this.gridApi.getSelectedRows();
    this.displayDocuments.emit(this.selectedRows);
  }

  closeGrid() {
    this.show = false;
    this.showChange.emit(this.show);
  }

}
