import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AttachmentsComponent } from './attachments.component';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { DocumentService } from '../document.service';

describe('AttachmentPopupComponent', () => {
  let component: AttachmentsComponent;
  let fixture: ComponentFixture<AttachmentsComponent>;
  let mockDocumentService: DocumentService;
  const documentServiceStub = {
      getDocuments: function () {
      },
      downloadDocument: function () {
      }
  };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AttachmentsComponent ],
      schemas: [
        NO_ERRORS_SCHEMA,
        CUSTOM_ELEMENTS_SCHEMA
      ],
      providers: [
        {
          provide: DocumentService, useValue: documentServiceStub
        }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AttachmentsComponent);
    component = fixture.componentInstance;
    mockDocumentService = TestBed.get(DocumentService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Should load all columns in the grid', () => {
    expect(component['columnDefs'].length).toBeGreaterThan(0);
  });

  it('Should load the documents', () => {
    spyOn(mockDocumentService, 'getDocuments');
    component.ngOnInit();
    expect(mockDocumentService.getDocuments).toHaveBeenCalled();
  });

  it('Should download document on cell click', () => {
    let spyDownloadDocument, mockClickEvent;
    mockClickEvent = {
      colDef: {
        field: null
      },
      data: {
        editable: null
      }
    };
    spyDownloadDocument = spyOn(mockDocumentService, 'downloadDocument');
    mockClickEvent.colDef.field = 'fileName';
    component.onCellClicked(mockClickEvent);
    expect(mockDocumentService.downloadDocument).toHaveBeenCalledWith(mockClickEvent.data);
    spyDownloadDocument.calls.reset();
    mockClickEvent.colDef.field = 'notFileName';
    component.onCellClicked(mockClickEvent);
    expect(mockDocumentService.downloadDocument).not.toHaveBeenCalled();
    spyDownloadDocument.calls.reset();
  });

});
