import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject, of } from 'rxjs';
import { DocumentDto, ApiService } from '../../common';
import { NotificationService } from '../../common/notification/notification.service';
const downloadDocumentError = 'An error occurred while downloading a document, please contact your administrator.';
@Injectable()
export class DocumentService {
  private documents = new BehaviorSubject<DocumentDto[]>(null);

  constructor(private apiService: ApiService, private notificationService: NotificationService ) { }

  public get documents$(): Observable<DocumentDto[]> {
    return this.documents.asObservable();
  }

  public getDocuments(ignoreTranche: boolean = false) {
    this.apiService.getDocuments(ignoreTranche).subscribe((documents: DocumentDto[]) => {
      this.documents.next(documents);
    });
  }

  public saveDocument(document: DocumentDto, file: any): any {
    let promise;
    promise = new Promise(
      (resolve, reject) => {
        this.apiService.saveDocumentMetadata(document).subscribe(
          (newDocument) => {
            if (!newDocument.sourceId) {
              resolve();
            } else {
              this.postFile(resolve, reject, newDocument, file);
            }
          }, (error) => {
            reject(error);
          }
        );
      }
    );
    return promise;
  }

  public updateDocument(document: DocumentDto, file: any, isPathDirty: boolean): any {
    let promise;
    promise = new Promise(
      (resolve, reject) => {
        this.apiService.updateDocumentMetadata(document).subscribe(
          (newDocument) => {
            if (!isPathDirty) {
              resolve();
            } else {
              this.postFile(resolve, reject, newDocument, file);
            }
          }, (error) => {
            reject(error);
          }
        );
      }
    );
    return promise;
  }

  postFile(resolve: any, reject: any, document: any, file: any) {
    let formData;
    formData = new FormData();
    formData.append('file', file);
    this.apiService.postFile(formData, document.sourceId).subscribe(
      (response) => {
        resolve();
      }, (error) => {
        reject(error);
      }
    );
  }

  public getDocumentNameTypes(): Observable<string[]> {
    return this.apiService.getDocumentNameTypes();
  }

  public deleteDocuments(id: string) {
    return this.apiService.deleteDocuments(id);
  }

  public downloadDocument(documentForIB: DocumentDto): void {
    let blob, fileName;
    if (!documentForIB.isDocumentTypeUrl) {
      let downloadLink;
      downloadLink = document.createElement('a');
      this.apiService.downloadDocument(documentForIB.sourceId).subscribe((response) => {
        blob = new Blob([response]);
        fileName = documentForIB.name + '.' + documentForIB.fileName.split('.').pop();
        if (window.navigator.msSaveOrOpenBlob) {
          window.navigator.msSaveBlob(blob, fileName);
        } else {
          downloadLink.href = window.URL.createObjectURL(blob);
          downloadLink.download = fileName;
          downloadLink.click();
          window.URL.revokeObjectURL(downloadLink.href);
        }
      }, (err) => {
        this.notificationService.error(downloadDocumentError);
      });
    }
  }

}
