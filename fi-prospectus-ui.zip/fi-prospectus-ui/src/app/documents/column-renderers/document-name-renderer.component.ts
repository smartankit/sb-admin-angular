import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';

@Component({
  selector: 'app-renderer-document-name',
  template: `
              <select class="c-input" [(ngModel)]="documentNameType" (ngModelChange)="documentNameTypeChange();">
                <option *ngFor="let documentNameType of componentParent.documentNameTypes" value="{{documentNameType}}">
                  {{documentNameType}}
                </option>
              </select>
              <div [ngClass]="{'isDirty': params.data.isNameDirty}"></div>
              <input type="text" class="c-input" maxlength="250" [(ngModel)]="params.data.name" (ngModelChange)="documentNameChange();"/>
            `,
  styleUrls: ['./column-renderer.scss']
})
export class DocumentNameRendererComponent implements ICellRendererAngularComp {

  params: any; componentParent: any; documentNameType: string;

  constructor() {
  }

  agInit(params: any): void {
    this.params = params;
    this.componentParent = params.context.componentParent;
    this.getDocumentType();
    this.formDocumentName();
  }

  refresh(): boolean {
    return false;
  }

  getDocumentType(): void {
    let i;
    if (this.params.data.id === null) {
      this.documentNameType = this.componentParent.documentNameTypes[0];
    } else {
      for (i = 0; i < this.componentParent.documentNameTypes.length; i++) {
        if (this.params.data.name.includes(this.componentParent.documentNameTypes[i])) {
          this.documentNameType = this.componentParent.documentNameTypes[i];
          break;
        }
      }
    }
  }

  formDocumentName(): void {
    if (this.params.data.id === null) {
      this.params.data.name = this.documentNameType;
    }
  }

  documentNameTypeChange(): void {
    this.params.data.name = this.documentNameType;
    this.documentNameChange();
  }

  documentNameChange(): void {
    if (this.params.data.id !== null) {
      this.params.data.isNameDirty = true;
    }
  }

}
