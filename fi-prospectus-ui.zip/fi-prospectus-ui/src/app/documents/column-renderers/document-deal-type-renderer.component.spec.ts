import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { DocumentDealTypeRendererComponent } from './document-deal-type-renderer.component';
import { DealType } from '../../../common/enum';

describe('DocumentDealTypeRendererComponent', () => {
  let fixture: ComponentFixture<DocumentDealTypeRendererComponent>;
  let component: DocumentDealTypeRendererComponent;
  const params = {
    data: {
      id: null,
      isDealWide: true
    }
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DocumentDealTypeRendererComponent],
      schemas: [
        NO_ERRORS_SCHEMA,
        CUSTOM_ELEMENTS_SCHEMA
      ],
      providers: []
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentDealTypeRendererComponent);
    component = fixture.componentInstance;
    component.agInit(params);
  });

  it('Should initialize the component', () => {
    expect(component.params).toEqual(params);
    expect(component.dealType).toEqual(DealType.DealWide);
  });

  it('should not refresh cell renderer on its own', () => {
    expect(component.refresh()).toEqual(false);
  });

  it('should handle deal type change', () => {
    component.dealType = DealType.DealWide;
    component.dealTypeChange();
    expect(component.params.data.isDealWide).toEqual(true);
    component.dealType = DealType.TrancheSpecific;
    component.dealTypeChange();
    expect(component.params.data.isDealWide).toEqual(false);
  });

});
