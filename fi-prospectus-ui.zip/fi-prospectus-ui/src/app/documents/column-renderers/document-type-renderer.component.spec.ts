import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { DocumentTypeRendererComponent } from './document-type-renderer.component';
import { HelperService } from '../../shared/helper.service';

describe('DocumentTypeRendererComponent', () => {
  let fixture: ComponentFixture<DocumentTypeRendererComponent>;
  let component: DocumentTypeRendererComponent;
  let mockHelperService: HelperService;
  const fileTypes = ['URL', 'FILE'];
  const documentNameTypes = ['Internal Research', 'External Research', 'Prospectus', 'Issuer Web Page', 'News', 'Roadshow'];
  const mockDocument = '<div></div>';
  const params = {
    rowIndex: 3,
    data: {
      id: null,
      name: null,
      documentType: null
    },
    context: {
      componentParent: {
        fileTypes: fileTypes,
        documentNameTypes: documentNameTypes
      }
    }
  };
  const helperServiceStub = {
    showTooltip: function () {
    },
    hideTooltip: function () {
    }
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DocumentTypeRendererComponent],
      schemas: [
        NO_ERRORS_SCHEMA,
        CUSTOM_ELEMENTS_SCHEMA
      ],
      providers: [
        {
          provide: HelperService, useValue: helperServiceStub
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentTypeRendererComponent);
    component = fixture.componentInstance;
    mockHelperService = TestBed.get(HelperService);
    component.agInit(params);
  });

  it('Should initialize the component', () => {
    expect(component.params).toEqual(params);
    expect(component.componentParent).toEqual(params.context.componentParent);
  });

  it('should not refresh cell renderer on its own', () => {
    expect(component.refresh()).toEqual(false);
  });

  it('should handle document type change', () => {
    let querySelector;
    querySelector = '[row-id="' + params.rowIndex + '"]' + ' [col-id="fileName"]';
    component.params.data.name = documentNameTypes[1] + '...';
    spyOn(document, 'querySelector').and.returnValue(mockDocument);
    spyOn(mockHelperService, 'hideTooltip');
    component.documentTypeChange();
    expect(component.params.data.fileName).toBe(null);
    expect(document.querySelector).toHaveBeenCalledWith(querySelector);
    expect(mockHelperService.hideTooltip).toHaveBeenCalledWith(mockDocument);
    expect(component.params.data.name).toEqual(documentNameTypes[1]);
  });

});
