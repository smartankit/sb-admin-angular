import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { DocumentFileNameRendererComponent } from './document-file-name-renderer.component';

describe('DocumentFileNameRendererComponent', () => {
  let fixture: ComponentFixture<DocumentFileNameRendererComponent>;
  let component: DocumentFileNameRendererComponent;
  const mockDocument = '<div></div>';
  const shortFileName = 'a'.repeat(10) + '.pdf';
  const longFileName = 'a'.repeat(100) + '.pdf';
  const filesUploaded = [{
    name: 'Prospectus Document.pdf'
  }];
  const params = {
    data: {
      id: null,
      name: 'Sample Name',
      documentType: null,
      fileName: null
    },
    context: {
      componentParent: {
        validateDocument: function() {
        }
      }
    }
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DocumentFileNameRendererComponent],
      schemas: [
        NO_ERRORS_SCHEMA,
        CUSTOM_ELEMENTS_SCHEMA
      ],
      providers: []
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentFileNameRendererComponent);
    component = fixture.componentInstance;
    component.agInit(params);
  });

  it('Should initialize the component', () => {
    expect(component.params).toEqual(params);
    expect(component.rowData).toEqual(params.data);
    expect(component.componentParent).toEqual(params.context.componentParent);
  });

  it('should not refresh cell renderer on its own', () => {
    expect(component.refresh()).toEqual(false);
  });

  it('Should trigger file upload', () => {
    component.params.data.documentType = 'File';
    fixture.detectChanges();
    spyOn(component.fileInput.nativeElement, 'click');
    component.fileUploadStart();
    expect(component.fileInput.nativeElement.click).toHaveBeenCalled();
  });

  it('should handle file upload', () => {
    let documentName;
    documentName = component.rowData.name;
    spyOn(component.componentParent, 'validateDocument');
    spyOn(component, 'getFileNameForDisplay');
    component.params.data.documentType = 'File';
    fixture.detectChanges();
    component.fileInput.nativeElement = {
      files: filesUploaded
    };
    component.fileUploadEnd();
    expect(component.rowData.fileToUpload).toEqual(filesUploaded[0]);
    expect(component.rowData.fileName).toEqual(filesUploaded[0].name);
    expect(component.rowData.name).toEqual(documentName + ' (' + component.rowData.fileName + ')');
    expect(component.componentParent.validateDocument).toHaveBeenCalled();
    expect(component.getFileNameForDisplay).toHaveBeenCalled();
  });

  it('should get file name for display', () => {
    spyOn(document, 'getElementById').and.returnValue({setAttribute: function() {}});
    component.rowData.fileName = shortFileName;
    expect(component.getFileNameForDisplay()).toEqual(shortFileName);
    component.rowData.fileName = longFileName;
    expect(component.getFileNameForDisplay()).toEqual(longFileName.substring(0, 20) + '...');
  });

});
