import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { DocumentNameRendererComponent } from './document-name-renderer.component';

describe('DocumentNameRendererComponent', () => {
  let fixture: ComponentFixture<DocumentNameRendererComponent>;
  let component: DocumentNameRendererComponent;
  const documentNameTypes = ['Internal Research', 'External Research', 'Prospectus', 'Issuer Web Page', 'News', 'Roadshow'];
  const params = {
    data: {
      id: null,
      name: null
    },
    context: {
      componentParent: {
        documentNameTypes: documentNameTypes
      }
    }
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DocumentNameRendererComponent],
      schemas: [
        NO_ERRORS_SCHEMA,
        CUSTOM_ELEMENTS_SCHEMA
      ],
      providers: []
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentNameRendererComponent);
    component = fixture.componentInstance;
    component.agInit(params);
  });

  it('Should initialize the component', () => {
    expect(component.params).toEqual(params);
    expect(component.componentParent).toEqual(params.context.componentParent);
  });

  it('Should call component functions to set document type and document name', () => {
    spyOn(component, 'getDocumentType');
    spyOn(component, 'formDocumentName');
    component.agInit(params);
    expect(component.getDocumentType).toHaveBeenCalled();
    expect(component.formDocumentName).toHaveBeenCalled();
  });

  it('should not refresh cell renderer on its own', () => {
    expect(component.refresh()).toEqual(false);
  });

  it('should set document type', () => {
    component.params.data.id = null;
    component.getDocumentType();
    expect(component.documentNameType).toEqual(component.componentParent.documentNameTypes[0]);
    component.params.data.id = '1';
    component.params.data.name = documentNameTypes[1] + '...';
    component.getDocumentType();
    expect(component.documentNameType).toEqual(component.componentParent.documentNameTypes[1]);
  });

  it('should form document name', () => {
    component.params.data.id = null;
    component.documentNameType = 'Sample Document';
    component.formDocumentName();
    expect(component.params.data.name).toEqual(component.documentNameType);
  });

  it('should set grid data on document type change', () => {
    component.documentNameType = 'Sample Document';
    component.documentNameTypeChange();
    expect(component.params.data.name).toEqual(component.documentNameType);
  });

});
