import { Component, ViewChild } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';

@Component({
  selector: 'app-renderer-document-file-name',
  template: `
              <!-- <div *ngIf="params.data.documentType === 'URL'">
                <input type="text" class="c-input pathInput" [(ngModel)]="params.data.fileName"
                  (ngModelChange)="componentParent.validateDocument(params)" />
                <button disabled class="floatRight c-btn c-btn-secondary c-bold-text">Browse</button>
              </div>
              <div *ngIf="params.data.documentType === 'File'">
                <input disabled type="text" class="c-input pathInput" />
                <span id="fileNameForDisplay">{{params.data.fileNameForDisplay}}</span>
                <input #fileInput class="fileInput" type="file" (change)="fileUploadEnd()" />
                <button class="floatRight c-btn c-btn-secondary c-bold-text" (click)="fileUploadStart()">Browse</button>
              </div> -->
              <div style= "margin-top: 15px;">
                <span id="fileNameForDisplay">{{params.data.fileNameForDisplay}}</span>
                <input #fileInput class="fileInput" type="file" (change)="fileUploadEnd()" />
                <button class="floatRight c-btn c-btn-secondary c-bold-text" (click)="fileUploadStart()">Browse</button>
              </div>
            `,
  styleUrls: ['./column-renderer.scss']
})
export class DocumentFileNameRendererComponent implements ICellRendererAngularComp {

  params: any; rowData: any; componentParent: any
  @ViewChild('fileInput') fileInput;

  constructor() {
  }

  agInit(params: any): void {
    this.params = params;
    this.rowData = this.params.data;
    params.data.fileNameForDisplay = this.rowData.fileName;
    this.componentParent = this.params.context.componentParent;
  }

  refresh(): boolean {
    return false;
  }

  fileUploadStart(): void {
    this.fileInput.nativeElement.click();
  }

  fileUploadEnd(): void {
    let documentName;
    if (this.params.data.id !== null) {
      this.params.data.isNameDirty = true;
      this.params.data.isPathDirty = true;
    }
    this.rowData.fileToUpload = this.fileInput.nativeElement.files[0];
    this.rowData.fileName = this.rowData.fileToUpload.name;
    this.params.data.fileNameForDisplay = this.getFileNameForDisplay();
    if (this.rowData.name.indexOf('(') !== -1) {
      documentName = this.rowData.name.substring(0, this.rowData.name.indexOf('(') - 1);
      this.rowData.name = documentName + ' (' + this.rowData.fileName + ')';
    } else {
      this.rowData.name = this.rowData.name + ' (' + this.rowData.fileName + ')';
    }
    this.componentParent.validateDocument(this.params);
  }

  getFileNameForDisplay(): string {
    let fileNameForDisplay;
    if (this.rowData.fileName === null) {
      fileNameForDisplay = null;
    } else {
      if (this.rowData.fileName.length > 20) {
        fileNameForDisplay = this.rowData.fileName.substring(0, 20) + '...';
        document.getElementById('fileNameForDisplay').setAttribute('title', this.rowData.fileName);
      } else {
        fileNameForDisplay = this.rowData.fileName;
      }
    }
    return fileNameForDisplay;
  }

}
