import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { ActionsRendererComponent } from './actions-renderer.component';
import { HelperService } from '../../shared/helper.service';
import { CupcakeModalModule, CupcakePopoverService } from '@ipreo/cupcake-components';

describe('ActionsRendererComponent', () => {
  let fixture: ComponentFixture<ActionsRendererComponent>;
  let component: ActionsRendererComponent;
  let mockHelperService: HelperService;
  const sampleId = '1234';
  const params = {
    rowIndex: 3,
    data: {
      id: null,
      isUsed: false
    },
    context: {
      componentParent: {
        validateDocument: function () {
        },
        saveNewDocument: function () {
        },
        updateExistingDocument: function () {
        },
        cancelEditNewDocument: function () {
        },
        cancelEditExistingDocument: function () {
        },
        editExistingDocument: function () {
        },
        deleteExistingDocument: function () {
        }
      }
    }
  };

  const helperServiceStub = {
    showAnyTooltip: function () {
    }
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        CupcakeModalModule,
      ],
      declarations: [ActionsRendererComponent],
      schemas: [
        NO_ERRORS_SCHEMA,
        CUSTOM_ELEMENTS_SCHEMA
      ],
      providers: [HelperService, CupcakePopoverService, {
        provide: HelperService, useValue: helperServiceStub
      }]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActionsRendererComponent);
    component = fixture.componentInstance;
    component.agInit(params);
    mockHelperService = TestBed.get(HelperService);
  });

  it('Should initialize the component', () => {
    expect(component.params).toEqual(params);
    expect(component.componentParent).toEqual(params.context.componentParent);
  });

  it('should not refresh cell renderer on its own', () => {
    expect(component.refresh()).toEqual(false);
  });

  it('should save document', () => {
    spyOn(component.componentParent, 'validateDocument').and.returnValue(true);
    spyOn(component.componentParent, 'saveNewDocument');
    spyOn(component.componentParent, 'updateExistingDocument');
    component.params.data.id = null;
    component.saveDocument();
    expect(component.componentParent.saveNewDocument).toHaveBeenCalledWith(component.params.rowIndex);
    component.params.data.id = sampleId;
    component.saveDocument();
    expect(component.componentParent.updateExistingDocument).toHaveBeenCalledWith(component.params.rowIndex);
  });

  it('should cancel editing of new document', () => {
    component.params.data.id = null;
    spyOn(component.componentParent, 'cancelEditNewDocument');
    component.cancelEdit();
    expect(component.componentParent.cancelEditNewDocument).toHaveBeenCalledWith(component.params.rowIndex);
  });

  it('should cancel editing of exisitng document', () => {
    component.params.data.id = sampleId;
    spyOn(component.componentParent, 'cancelEditExistingDocument');
    component.cancelEdit();
    expect(component.componentParent.cancelEditExistingDocument).toHaveBeenCalledWith(component.params);
  });

  it('should edit existing document', () => {
    spyOn(component.componentParent, 'editExistingDocument');
    component.editExistingDocument();
    expect(component.componentParent.editExistingDocument).toHaveBeenCalledWith(component.params);
  });

  it('should delete existing document', () => {
    spyOn(component.componentParent, 'deleteExistingDocument');
    component.deleteExistingDocument();
    expect(component.componentParent.deleteExistingDocument).toHaveBeenCalledWith(component.params.data.id, component.params.data.isUsed);
  });

  it('should be call show tooltip', () => {
    spyOn(mockHelperService, 'showAnyTooltip');
    component.divEdit = fixture.debugElement.nativeElement
    component.params.data.isPackageSent = true;
    component.showToolTip();
    const documentisPackageSent = 'Document is being used by a package which has been sent and cannot be updated';
    expect(mockHelperService.showAnyTooltip).
    toHaveBeenCalledWith(component.divEdit.nativeElement, 'top', 'defaultPopover', documentisPackageSent, 'hover');
  });

});
