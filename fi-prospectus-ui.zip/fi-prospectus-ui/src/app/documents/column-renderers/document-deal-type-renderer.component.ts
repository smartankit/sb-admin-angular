import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { DealType } from '../../../common/enum';

@Component({
  selector: 'app-renderer-document-deal-type',
  template: `
              <select class="centerY c-input" [(ngModel)]="dealType" (ngModelChange)="dealTypeChange()">
                <option *ngFor="let dealType of params.context.componentParent.dealTypes" value="{{dealType}}">
                  {{dealType}}
                </option>
              </select>
            `,
  styleUrls: ['./column-renderer.scss']
})
export class DocumentDealTypeRendererComponent implements ICellRendererAngularComp {

  params: any; dealType: string;

  constructor() {
  }

  agInit(params: any): void {
    this.params = params;
    this.dealType = params.data.isDealWide ? DealType.DealWide : DealType.TrancheSpecific;
  }

  refresh(): boolean {
    return false;
  }

  dealTypeChange(): void {
    this.params.data.isDealWide = (this.dealType === DealType.DealWide);
  }

}
