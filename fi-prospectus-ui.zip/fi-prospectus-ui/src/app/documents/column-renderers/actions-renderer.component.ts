import { Component, ViewChild, AfterViewInit, ElementRef } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { HelperService } from '../../shared/helper.service';
const documentisPackageSent = 'Document is being used by a package which has been sent and cannot be updated';
@Component({
  selector: 'app-renderer-actions',
  template: `
              <div *ngIf="params.data.editable">
                <div *ngIf="params.colDef.colId === 'edit'" class="actionLink" (click)="saveDocument()">
                  Save
                </div>
                <div *ngIf="params.colDef.colId === 'delete'" class="actionLink" (click)="cancelEdit()">
                  Cancel
                </div>
              </div>
              <div *ngIf="!params.data.editable">
                <div *ngIf="params.colDef.colId === 'edit'" #divEdit class="actionLink" (click)="editExistingDocument()">
                 Edit
                 </div>
                <div *ngIf="params.colDef.colId === 'version'" class="actionLink">
                  Versions
                </div>
                <div *ngIf="params.colDef.colId === 'delete'" class="deleteIcon fa fa-trash" (click)="deleteExistingDocument()">
                </div>
              </div>
            `,
  styleUrls: ['./column-renderer.scss']
})
export class ActionsRendererComponent implements ICellRendererAngularComp, AfterViewInit {

  params: any; componentParent: any;
  @ViewChild('divEdit') divEdit: ElementRef
  constructor(private helperService: HelperService) {
  }

  ngAfterViewInit() {
    this.showToolTip()
  }

  showToolTip() {
    if (this.divEdit !== undefined) {
      if (this.params.data.isPackageSent) {
        return this.helperService.showAnyTooltip(this.divEdit.nativeElement, 'top', 'defaultPopover', documentisPackageSent, 'hover');
      }
    }
  }

  agInit(params: any): void {
    this.params = params;
    this.componentParent = this.params.context.componentParent;
  }

  refresh(): boolean {
    return false;
  }

  saveDocument(): void {
    if (this.componentParent.validateDocument(this.params)) {
      if (this.params.data.id === null) {
        this.componentParent.saveNewDocument(this.params.rowIndex);
      } else {
        this.componentParent.updateExistingDocument(this.params.rowIndex);
      }
    }
  }

  cancelEdit(): void {
    if (this.params.data.id === null) {
      this.componentParent.cancelEditNewDocument(this.params.rowIndex);
    } else {
      this.componentParent.cancelEditExistingDocument(this.params);
    }
  }

  editExistingDocument(): void {
    if (this.params.data.isPackageSent !== true) {
      this.componentParent.editExistingDocument(this.params);
    }

  }

  deleteExistingDocument(): void {
    this.componentParent.deleteExistingDocument(this.params.data.id, this.params.data.isUsed);
  }

}
