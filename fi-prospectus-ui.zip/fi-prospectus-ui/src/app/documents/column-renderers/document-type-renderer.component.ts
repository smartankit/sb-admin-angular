import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { HelperService } from '../../shared/helper.service';

@Component({
  selector: 'app-renderer-document-type',
  template: `
              <!-- <div class="documentTypeDiv" *ngFor="let fileType of params.context.componentParent.fileTypes">
                <label class="c-radio">
                  <input type="radio" name="{{params.rowIndex}}" value="{{fileType}}"
                    [(ngModel)]="params.data.documentType" (ngModelChange)="documentTypeChange();">
                  <i class="c-bg-primary"></i>
                  {{fileType}}
                </label>
                <br>
              </div> -->
              <div class="documentTypeDiv">
                <label> File </label>
              </div>
            `,
  styleUrls: ['./column-renderer.scss']
})
export class DocumentTypeRendererComponent implements ICellRendererAngularComp {

  params: any; documentName: string; documentType: string; componentParent: any;

  constructor(private helperService: HelperService) {
  }

  agInit(params: any): void {
    this.params = params;
    this.componentParent = params.context.componentParent;
  }

  refresh(): boolean {
    return false;
  }

  documentTypeChange(): void {
    let i, querySelector, gridPathCell;
    querySelector = '[row-id="' + this.params.rowIndex + '"]' + ' [col-id="fileName"]';
    gridPathCell = document.querySelector(querySelector);
    this.helperService.hideTooltip(gridPathCell);
    this.params.data.fileName = null;
    this.params.data.fileNameForDisplay = null;
    for (i = 0; i < this.componentParent.documentNameTypes.length; i++) {
      if (this.params.data.name.includes(this.componentParent.documentNameTypes[i])) {
        this.params.data.name = this.componentParent.documentNameTypes[i];
      }
    }
  }

}
