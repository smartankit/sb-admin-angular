import { Component, OnInit, OnDestroy } from '@angular/core';
import { ColDef, GridOptions, RowNode, CellClickedEvent } from 'ag-grid';
import { DocumentDto, AppContext } from '../../common';
import { DocumentNameRendererComponent } from './column-renderers/document-name-renderer.component';
import { DocumentTypeRendererComponent } from './column-renderers/document-type-renderer.component';
import { DocumentDealTypeRendererComponent } from './column-renderers/document-deal-type-renderer.component';
import { DocumentFileNameRendererComponent } from './column-renderers/document-file-name-renderer.component';
import { ActionsRendererComponent } from './column-renderers/actions-renderer.component';
import { CupcakeModalOptions, CupcakeModalService } from '@ipreo/cupcake-components';
import { NotificationService } from '../../common/notification/notification.service';
import { DealType } from '../../common/enum';
import { DocumentService } from './document.service';
import { HelperService } from '../shared/helper.service';
import { ISubscription } from 'rxjs/Subscription';

export const warningModalOptions: CupcakeModalOptions = {
  mode: 'component',
  title: 'Warning',
  type: 'danger',
  context: {
    buttons: [{
      title: 'Cancel', action: 'cancel'
    }, {
      title: 'OK', action: 'Ok'
    }]
  },
  rootCssClass: 'delete-warning'
};

export const warningPackageDocumentModalOptions: CupcakeModalOptions = {
  mode: 'component',
  title: 'Warning',
  type: 'danger',
  context: {
    buttons: [{
      title: 'OK', action: 'Ok'
    }]
  },
  rootCssClass: 'delete-warning'
};
const editWarning = 'You have unsaved changes. Are you sure you want to edit a different document?';
const editDeleteWarning = 'You have unsaved changes. Please confirm if you want to delete other document.';
const deleteWarning = 'Please confirm if you want to delete this document.';
const documentIsUsed = 'Document is being used by a package and cannot be deleted';

@Component({
  selector: 'app-documents',
  templateUrl: './documents.component.html',
  styleUrls: ['./documents.component.scss']
})
export class DocumentsComponent implements OnInit, OnDestroy {

  columnDefs: ColDef[]; gridOptions: GridOptions; overlayNoRowsTemplate: any; gridApi: any; columnTypes: any;
  rowData: DocumentDto[] = []; selectedRows: DocumentDto[] = []; selectedDocuments: DocumentDto[] = [];
  disableAddDocumentsButton: boolean; defaultColDef: any; frameworkComponents: any; editableRows: any = []; editableRowsOrigData: any;
  documentNameTypes: string[]; fileTypes: string[]; disclaimerTypes: string[]; dealTypes: string[]; subscriptionDocuments: ISubscription;

  constructor(private notificationService: NotificationService, private helperService: HelperService,
    private ccModalService: CupcakeModalService, private appContext: AppContext, private documentService: DocumentService) {
    this.columnDefs = [
      {
        headerName: 'Document Name',
        field: 'name',
        autoHeight: true
      },
      {
        headerName: 'Type',
        field: 'documentType',
        width: 70
      },
      {
        headerName: 'Path',
        field: 'fileName',
        tooltipField: 'fileName',
        cellClass: 'c-a'
      },
      // {
      //   headerName: 'Dislaimer',
      //   field: 'disclaimer',
      // },
      {
        headerName: 'Deal/tranche',
        colId: 'dealOrTranche',
        valueGetter: function (params) {
          return (params.data.isDealWide ? DealType.DealWide : DealType.TrancheSpecific);
        }
      },
      {
        colId: 'edit',
        width: 70,
        type: 'actionColumn'
      },
      // {
      //   colId: 'version',
      //   suppressSizeToFit: false,
      //   width: 70,
      //   type: 'actionColumn'
      // },
      {
        colId: 'delete',
        width: 40,
        type: 'actionColumn'
      },
      {
        colId: 'sourceId',
        field: 'sourceId',
        hide: true
      }
    ];

    this.defaultColDef = {
      cellRendererSelector: (params => {
        return this.columnRendererSelector(params);
      }),
      editable: false,
      unSortIcon: true,
      context: {
        componentParent: this
      },
      cellClassRules: {
        'editableCell': function (params) { return (params.data.editable === true) }
      }
    };

    this.columnTypes = {
      'actionColumn': {
        suppressSorting: true,
        suppressFilter: true
      }
    };

    this.frameworkComponents = {
      documentNameRendererComponent: DocumentNameRendererComponent,
      documentTypeRendererComponent: DocumentTypeRendererComponent,
      documentDealTypeRendererComponent: DocumentDealTypeRendererComponent,
      documentFileNameRendererComponent: DocumentFileNameRendererComponent,
      actionsRendererComponent: ActionsRendererComponent
    };

    this.gridOptions = {
      defaultColDef: this.defaultColDef,
      columnDefs: this.columnDefs,
      columnTypes: this.columnTypes,
      context: {
        componentParent: this
      },
      enableSorting: true
    };

    this.overlayNoRowsTemplate =
      `<div class="c-text-center c-p-horizontal-lg c-p-vertical-xl">
      <i class="fa fa-exclamation-circle c-text-gray-3 fa-5x"></i>
      <div class="c-header-xs c-text-black c-m-top-lg">No Documents are available.</div>
    </div>`;
  }

  ngOnInit() {
    this.documentService.getDocuments();
    this.getDocumentNameTypes();
    this.setOtherEditableColumnTypes();
  }

  ngOnDestroy() {
    if (this.subscriptionDocuments) {
      this.subscriptionDocuments.unsubscribe();
    }
  }

  getDocumentNameTypes(): void {
    this.documentService.getDocumentNameTypes().subscribe(documentNameTypes => {
      this.documentNameTypes = documentNameTypes;
    });
  }

  setOtherEditableColumnTypes(): void {
    this.fileTypes = ['File']; // ['URL', 'File']
    this.disclaimerTypes = ['Standard', 'Non Standard'];
    this.dealTypes = [DealType.DealWide, DealType.TrancheSpecific];
  }

  loadData(): void {
    this.subscriptionDocuments = this.documentService.documents$.subscribe(items => {
      if (!items) {
        return;
      }
      this.rowData = items;
      if (items.length === 0) {
        this.gridOptions.api.showNoRowsOverlay();
      }
    });
  }

  onGridReady(params: any): void {
    this.gridApi = params.api;
    this.gridOptions.api.sizeColumnsToFit();
    this.gridOptions.api.hideOverlay();
    this.loadData();
    this.disableAddDocumentsButton = false;
  }

  columnRendererSelector(params: any) {
    let fieldType: string, componentSelected = null;
    if (params.colDef.type === 'actionColumn') {
      return {
        component: 'actionsRendererComponent'
      };
    }
    if (params.data.editable) {
      if (params.colDef.colId === 'dealOrTranche') {
        fieldType = params.colDef.colId;
      } else {
        fieldType = params.colDef.field;
      }
      switch (fieldType) {
        case 'name': componentSelected = {
          component: 'documentNameRendererComponent'
        };
          break;
        case 'documentType': componentSelected = {
          component: 'documentTypeRendererComponent'
        };
          break;
        case 'fileName': componentSelected = {
          component: 'documentFileNameRendererComponent'
        };
          break;
        case 'dealOrTranche': componentSelected = {
          component: 'documentDealTypeRendererComponent'
        };
          break;
        default: break;
      }
    }
    return componentSelected;
  }

  validateDocument(params: any): boolean {
    let isDocumentValid, isDocumentPathValid, fileName, fileExtension, validFileExtensions, gridPathCell, querySelector, errorMessage;
    validFileExtensions = ['.doc', '.docx', '.xls', '.xlsx', '.rtf', '.pdf', '.gif'];
    querySelector = '[row-index="' + params.rowIndex + '"]' + ' [col-id="fileName"]';
    gridPathCell = document.querySelector(querySelector);
    fileName = params.data.fileName;
    this.helperService.hideTooltip(gridPathCell);
    if (params.data.documentType === 'URL') {
      if (fileName) {
        isDocumentPathValid = true;
      } else {
        errorMessage = 'Document is not a file';
        this.helperService.showTooltip(gridPathCell, errorMessage);
        isDocumentPathValid = false;
      }
    } else {
      if (fileName) {
        fileExtension = '.' + fileName.split('.').pop();
        fileExtension = fileExtension.toLowerCase();
        if (validFileExtensions.indexOf(fileExtension) !== -1) {
          isDocumentPathValid = true;
        } else {
          errorMessage = 'This document is not valid and can not be uploaded. Allowed file formats are .doc, .docx,'
            + '.xls, .xlsx, .rtf, .pdf, .gif';
          this.helperService.showTooltip(gridPathCell, errorMessage);
          isDocumentPathValid = false;
        }
      } else {
        errorMessage = 'Document is not a file';
        this.helperService.showTooltip(gridPathCell, errorMessage);
        isDocumentPathValid = false;
      }
    }

    if (!isDocumentPathValid) {
      isDocumentValid = false;
    } else {
      isDocumentValid = true;
    }
    return isDocumentValid;
  }

  onCellClicked(event: CellClickedEvent): void {
    if (event.colDef.field === 'fileName' && !event.data.editable) {
      this.documentService.downloadDocument(event.data);
    }
  }

  createNewDocument(): void {
    if (this.editableRows.length > 0) {
      warningModalOptions.context.text = editWarning;
      this.ccModalService.open(warningModalOptions).subscribe(response => {
        if (response.action === 'Ok') {
          delete this.editableRows[0].data.editable;
          this.gridOptions.api.redrawRows({ rowNodes: this.editableRows });
          this.editableRows.pop();
          this.createNewDocumentOK();
        }
      });
    } else {
      this.createNewDocumentOK();
    }
  }

  createNewDocumentOK(): void {
    let addIndex: number, newDocument;
    addIndex = this.gridApi.getDisplayedRowCount();
    newDocument = {
      'id': null,
      'name': this.documentNameTypes[0],
      'fileSize': null,
      'fileName': null,
      'documentType': this.fileTypes[0],
      'disclaimer': this.disclaimerTypes[0],
      'isDealWide': true,
      'firmId': null,
      'dealId': null,
      'trancheId': null,
      'editable': true
    };
    this.disableAddDocumentsButton = true;
    this.gridOptions.api.updateRowData({ add: [newDocument], addIndex: addIndex });
    this.gridOptions.api.resetRowHeights();
  }

  saveNewDocument(rowIndex: number): void {
    let row, newDocument;
    row = this.gridApi.getDisplayedRowAtIndex(rowIndex).data;
    newDocument = {
      disclaimer: row.disclaimer,
      documentType: row.documentType,
      isDealWide: row.isDealWide,
      name: row.name,
      fileName: row.fileName,
      firmId: +this.appContext.firmId,
      dealId: this.appContext.dealId,
      trancheId: this.appContext.trancheId
    };
    this.documentService.saveDocument(newDocument, row.fileToUpload).then(
      (response) => {
        this.saveDocumentSuccess();
      }, (err) => {
        this.notificationService.error(err.error.message);
      }
    );
  }

  saveDocumentSuccess(): void {
    this.disableAddDocumentsButton = false;
    this.notificationService.success('Document Saved Successfully');
    this.documentService.getDocuments();
    this.editableRows.pop();
  }

  editExistingDocument(params: any): void {
    if (this.editableRows.length > 0) {
      warningModalOptions.context.text = editWarning;
      this.ccModalService.open(warningModalOptions).subscribe(responseModal => {
        if (responseModal.action === 'Ok') {
          delete this.editableRows[0].data.editable;
          this.gridOptions.api.redrawRows({ rowNodes: this.editableRows });
          this.editableRows.pop();
          this.editExistingDocumentOK(params);
        }
      });
    } else {
      this.editExistingDocumentOK(params);
    }
  }

  editExistingDocumentOK(params: any) {
    params.data.editable = true;
    params.data.isNameDirty = null;
    params.data.isPathDirty = null;
    this.editableRows.push(this.gridOptions.api.getDisplayedRowAtIndex(params.rowIndex));
    this.editableRowsOrigData = JSON.parse(JSON.stringify(this.gridOptions.api.getDisplayedRowAtIndex(params.rowIndex).data));
    this.gridOptions.api.redrawRows({ rowNodes: this.editableRows });
    this.gridOptions.api.resetRowHeights();
  }

  updateExistingDocument(rowIndex: number): void {
    let row: RowNode, newDocument;
    this.disableAddDocumentsButton = false;
    row = this.gridApi.getDisplayedRowAtIndex(rowIndex);
    newDocument = Object.assign({}, row.data);
    delete newDocument.editable;
    delete newDocument.isNameDirty;
    delete newDocument.isPathDirty;
    this.documentService.updateDocument(newDocument, row.data.fileToUpload, row.data.isPathDirty).then(
      (response) => {
        this.updateDocumentSuccess();
      }, (err) => {
        this.notificationService.error(err.error.message);
      }
    );
  }

  updateDocumentSuccess(): void {
    this.disableAddDocumentsButton = false;
    this.notificationService.success('Document Updated Successfully');
    this.documentService.getDocuments();
    this.editableRows.pop();
  }

  cancelEditNewDocument(rowIndex: number): void {
    let row: RowNode;
    this.disableAddDocumentsButton = false;
    row = this.gridApi.getDisplayedRowAtIndex(rowIndex);
    this.gridOptions.api.updateRowData({ remove: [row.data] });
  }

  cancelEditExistingDocument(params: any): void {
    this.disableAddDocumentsButton = false;
    this.editableRows[0].data = JSON.parse(JSON.stringify(this.editableRowsOrigData));
    delete this.editableRows[0].data.editable;
    this.gridOptions.api.redrawRows({ rowNodes: this.editableRows });
    this.editableRows.pop();
    this.gridOptions.api.resetRowHeights();
  }


  deleteExistingDocument(id: string, isUsedInPackage: boolean): void {
    if (isUsedInPackage) {
      return this.showPackageUsedWarningDialog(isUsedInPackage)
    }

    if (this.editableRows.length > 0) {
      warningModalOptions.context.text = editDeleteWarning;
    } else {
      warningModalOptions.context.text = deleteWarning;
    }

    this.ccModalService.open(warningModalOptions).subscribe(responseModal => {
      if (responseModal.action === 'Ok') {
        this.documentService.deleteDocuments(id).subscribe(response => {
          this.notificationService.success('Successfully deleted the document');
          this.documentService.getDocuments();
        }, error => {
          this.notificationService.error('Document cannot be deleted');
        });
      }
    });

  }

  showPackageUsedWarningDialog(isUsedInPackage: boolean) {
    warningPackageDocumentModalOptions.context.text = documentIsUsed;
    this.ccModalService.open(warningPackageDocumentModalOptions);
  }
}
