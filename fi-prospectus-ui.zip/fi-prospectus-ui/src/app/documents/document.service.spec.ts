import { TestBed } from '@angular/core/testing';
import { of, Observable, BehaviorSubject } from 'rxjs';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';
import { DocumentService } from './document.service';
import { DocumentDto, ApiService } from '../../common';
import { NotificationService } from '../../common/notification/notification.service';
import { CupcakeModalModule, CupcakeNotifyService } from '@ipreo/cupcake-components';

describe('Service: Document Service', () => {

  let documentService: DocumentService;
  let mockApiService: ApiService;
  const documentNameTypes = ['Internal Research', 'External Research', 'Prospectus', 'Issuer Web Page', 'News', 'Roadshow'];
  const fileTypes = ['URL', 'File'];
  const disclaimerTypes = ['Standard', 'Non Standard'];
  const mockFile = <File>(new Blob(['The content of your file']));
  const mockNewDocument: any = {
    'id': 1,
    'name': documentNameTypes[0],
    'fileSize': null,
    'sourceId': 1,
    'fileName': 'Prospectus.pdf',
    'documentType': fileTypes[1],
    'disclaimer': disclaimerTypes[0],
    'isDealWide': true,
    'firmId': null,
    'dealId': null,
    'trancheId': null,
    'editable': true,
  };
  const apiServiceStub = {
    getDocuments: function () {
      return of(mockNewDocument);
    },
    postFile: function () {
      return of([]);
    },
    downloadDocument: function () {
      return of([]);
    },
    getDocumentNameTypes: function (): Observable<string[]> {
      return of(documentNameTypes);
    },
    deleteDocuments: function (id: string) {
    },
    saveDocumentMetadata: function () {
      return of([]);
    },
    updateDocumentMetadata: function () {
      return of([]);
    }
  };
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        CupcakeModalModule,
      ],
      providers: [
        DocumentService,
        {
          provide: ApiService, useValue: apiServiceStub
        },
        NotificationService,
        CupcakeNotifyService
      ]
    });
    documentService = TestBed.get(DocumentService);
    mockApiService = TestBed.get(ApiService);
  });

  it('should subscribe to documents', () => {
    documentService.documents$.subscribe((newDocument) => {
      if (newDocument) {
        expect(newDocument).toBe(mockNewDocument);
      }
    });
    documentService['documents'].next(mockNewDocument);
  });

  it('should get all documents', () => {
    documentService.documents$.subscribe((newDocument) => {
      if (newDocument) {
        expect(newDocument).toBe(mockNewDocument);
      }
    });
    spyOn(mockApiService, 'getDocuments').and.callThrough();
    documentService.getDocuments();
    expect(mockApiService.getDocuments).toHaveBeenCalled();
  });

  it('Should save document', () => {
    let saveDocumentPromise, promiseResolved, callSuccessScenario, spyPostFile, successCB, errorCB;
    spyOn(mockApiService, 'saveDocumentMetadata').and.callFake(function () {
      promiseResolved = null;
      if (callSuccessScenario) {
        return of(mockNewDocument);
      } else {
        return ErrorObservable.create({ message: 'some-error' });
      }
    });
    successCB = function (response) {
      promiseResolved = true;
      expect(promiseResolved).toBe(true);
    };
    errorCB = function (err) {
      promiseResolved = false;
      expect(promiseResolved).toBe(false);
    };
    callSuccessScenario = true;
    mockNewDocument.sourceId = null;
    saveDocumentPromise = documentService.saveDocument(mockNewDocument, mockFile);
    expect(mockApiService.saveDocumentMetadata).toHaveBeenCalled();
    saveDocumentPromise.then(successCB, errorCB);
    callSuccessScenario = false;
    saveDocumentPromise = documentService.saveDocument(mockNewDocument, mockFile);
    expect(mockApiService.saveDocumentMetadata).toHaveBeenCalled();
    saveDocumentPromise.then(successCB, errorCB);
    callSuccessScenario = true;
    spyPostFile = spyOn(documentService, 'postFile');
    mockNewDocument.sourceId = null;
    documentService.saveDocument(mockNewDocument, mockFile);
    expect(documentService.postFile).not.toHaveBeenCalled();
    spyPostFile.calls.reset();
    mockNewDocument.sourceId = '111';
    documentService.saveDocument(mockNewDocument, mockFile);
    expect(documentService.postFile).toHaveBeenCalledWith(jasmine.any(Function), jasmine.any(Function), mockNewDocument, mockFile);
  });

  it('Should update document', () => {
    let updateDocumentPromise, promiseResolved, callSuccessScenario, spyPostFile, successCB, errorCB;
    spyOn(mockApiService, 'updateDocumentMetadata').and.callFake(function () {
      promiseResolved = null;
      if (callSuccessScenario) {
        return of(mockNewDocument);
      } else {
        return ErrorObservable.create({ message: 'some-error' });
      }
    });
    successCB = function (response) {
      promiseResolved = true;
      expect(promiseResolved).toBe(true);
    };
    errorCB = function (err) {
      promiseResolved = false;
      expect(promiseResolved).toBe(false);
    };
    callSuccessScenario = true;
    mockNewDocument.sourceId = null;
    updateDocumentPromise = documentService.updateDocument(mockNewDocument, mockFile, true);
    expect(mockApiService.updateDocumentMetadata).toHaveBeenCalled();
    updateDocumentPromise.then(successCB, errorCB);
    callSuccessScenario = false;
    updateDocumentPromise = documentService.updateDocument(mockNewDocument, mockFile, true);
    expect(mockApiService.updateDocumentMetadata).toHaveBeenCalled();
    updateDocumentPromise.then(successCB, errorCB);
    callSuccessScenario = true;
    spyPostFile = spyOn(documentService, 'postFile');
    mockNewDocument.sourceId = null;
    documentService.updateDocument(mockNewDocument, mockFile, null);
    expect(documentService.postFile).not.toHaveBeenCalled();
    spyPostFile.calls.reset();
    mockNewDocument.sourceId = '111';
    documentService.updateDocument(mockNewDocument, mockFile, true);
    expect(documentService.postFile).toHaveBeenCalledWith(jasmine.any(Function), jasmine.any(Function), mockNewDocument, mockFile);
  });

  it('should post file', () => {
    let formData, successCB, errorCB, promiseResolved, callSuccessScenario;
    mockNewDocument.sourceId = '222';
    formData = new FormData();
    formData.append('file', mockFile);
    spyOn(mockApiService, 'postFile').and.callFake(function () {
      promiseResolved = null;
      if (callSuccessScenario) {
        return of({});
      } else {
        return ErrorObservable.create({ message: 'some-error' });
      }
    });
    successCB = function () {
      promiseResolved = true;
    };
    errorCB = function (err) {
      promiseResolved = false;
    };
    callSuccessScenario = true;
    documentService.postFile(successCB, errorCB, mockNewDocument, mockFile);
    expect(mockApiService.postFile).toHaveBeenCalledWith(formData, mockNewDocument.sourceId);
    expect(promiseResolved).toBe(true);
    callSuccessScenario = false;
    documentService.postFile(successCB, errorCB, mockNewDocument, mockFile);
    expect(mockApiService.postFile).toHaveBeenCalledWith(formData, mockNewDocument.sourceId);
    expect(promiseResolved).toBe(false);
  });

  it('should get document name types', () => {
    spyOn(mockApiService, 'getDocumentNameTypes').and.callThrough();
    documentService.getDocumentNameTypes();
    expect(mockApiService.getDocumentNameTypes).toHaveBeenCalled();
  });

  it('should delete document', () => {
    spyOn(mockApiService, 'deleteDocuments').and.callThrough();
    documentService.deleteDocuments(mockNewDocument.id);
    expect(mockApiService.deleteDocuments).toHaveBeenCalledWith(mockNewDocument.id);
  });

  it('Should download document', () => {
    let mockAnchor: any, mockObjectURL, mockDownloadName, spyDownloadDocument;
    mockAnchor = {
      href: null,
      download: null,
      click: function () {
      }
    };
    mockObjectURL = '123-456';
    mockDownloadName = mockNewDocument.name + '.' + mockNewDocument.fileName.split('.').pop();
    spyDownloadDocument = spyOn(mockApiService, 'downloadDocument').and.callThrough();
    spyOn(document, 'createElement').and.returnValue(mockAnchor);
    spyOn(mockAnchor, 'click');
    mockNewDocument.documentType = fileTypes[0];
    mockNewDocument.isDocumentTypeUrl = true;
    documentService.downloadDocument(mockNewDocument);
    expect(mockApiService.downloadDocument).not.toHaveBeenCalled();
    spyDownloadDocument.calls.reset();
    mockNewDocument.documentType = fileTypes[1];
    mockNewDocument.isDocumentTypeUrl = false;
    documentService.downloadDocument(mockNewDocument);
    expect(mockApiService.downloadDocument).toHaveBeenCalledWith(mockNewDocument.sourceId);
    spyDownloadDocument.calls.reset();
    spyOn(window.URL, 'createObjectURL').and.returnValue(mockObjectURL);
    spyOn(window.URL, 'revokeObjectURL');
    mockNewDocument.documentType = fileTypes[1];
    documentService.downloadDocument(mockNewDocument);
    expect(mockApiService.downloadDocument).toHaveBeenCalledWith(mockNewDocument.sourceId);
    expect(mockAnchor.href).toBe(mockObjectURL);
    expect(mockAnchor.download).toBe(mockDownloadName);
    expect(mockAnchor.click).toHaveBeenCalled();
    // expect(window.URL.createObjectURL).toHaveBeenCalledWith(new Blob([[]]));
    expect(window.URL.revokeObjectURL).toHaveBeenCalledWith(mockObjectURL);
  });

});
