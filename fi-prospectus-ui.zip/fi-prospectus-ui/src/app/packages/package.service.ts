import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';

import {
  ApiService, PackageDto, DealDto, PackageRecipientDto, TrancheDto, RecipientStatusSummaryDto,
  PackageRecipientPagedDto, AddDeleteRecipientInfoDto, RecipientAutoSendSummaryDto, AppContext
} from '../../common';
import { PatchPackageDto } from 'src/common/models/dto/patchPackageDto';
import { NotificationService } from 'src/common/notification/notification.service';


@Injectable()
export class PackageService {
  private deal = new BehaviorSubject<DealDto>(null);
  private package = new BehaviorSubject<PackageDto>(null);

  constructor(private apiService: ApiService,
    private appContext: AppContext,
    private notificationService: NotificationService) { }

  public get deal$(): Observable<DealDto> {
    return this.deal.asObservable();
  }

  public get package$(): Observable<PackageDto> {
    return this.package.asObservable();
  }

  public refresh() {
    this.apiService.getDeal().subscribe(deal => {
      if (!deal) {
        this.notificationService.error('Deal not found!');
        return;
      }

      this.appContext.dealId = deal.id;
      if (this.appContext.trancheSourceId) {
        const matchingTranches = deal.tranches.filter((t) => {
          return t.sourceId === this.appContext.trancheSourceId;
        });

        this.appContext.trancheId = matchingTranches.length > 0 ? matchingTranches[0].id : null;
      }

      this.deal.next(deal);
    });
  }

  public getPackagesByDeal() {
    return this.apiService.getPackagesByDeal();
  }

  public getPackageDetail(packageId: string) {
    this.apiService.getPackageById(packageId).subscribe((packageDetail: PackageDto) => {
      this.package.next(packageDetail);
    });
  }

  public save(packageData: PackageDto) {
    return this.apiService.savePackage(packageData);
  }

  public update(packageData: PackageDto) {
    return this.apiService.updatePackage(packageData);
  }

  public addRecipientsToPackage(packageId: string, addDeleteRecipientInfo: AddDeleteRecipientInfoDto) {
    return this.apiService.addRecipientsToPackage(packageId, addDeleteRecipientInfo);
  }

  public getEmployerRoles(): Observable<string[]> {
    return this.apiService.getEmployerRoles();
  }

  public getConsentLanguages() {
    return this.apiService.getConsentLanguages();
  }

  public patchPackage(packageId: string, fieldname: string, value: any): Observable<PatchPackageDto> {
    const patchPackage: PatchPackageDto = new PatchPackageDto();
    patchPackage.path = fieldname;
    patchPackage.value = value;
    return this.apiService.patchPackage(new Array(patchPackage), packageId);
  }

  public send(packageForIB: PackageDto, recipients: PackageRecipientDto[] = [], byPassSpinner?: boolean) {
    let packageId = '';
    if (packageForIB) {
      packageId = packageForIB.id;
    }
    return this.apiService.sendPackage(packageId, recipients, byPassSpinner);
  }

  public getPackageRecipients(packageId: string, status: string[], pageNumber: number, pageSize: number, byPassSpinner?: boolean)
    : Observable<PackageRecipientPagedDto> {
    const selectedStatus = status.toString();
    return this.apiService.getPackageRecipients(packageId, selectedStatus, pageNumber, pageSize, byPassSpinner);
  }

  public getPackageRecipientsSummary(packageId: string, byPassSpinner?: boolean): Observable<RecipientStatusSummaryDto> {
    return this.apiService.getPackageRecipientsSummary(packageId, byPassSpinner);
  }

  public autoSend(packageId: string, autoSend: any) {
    return this.apiService.austoSendPackage(packageId, autoSend);
  }

  public getPackageAutoSendRecipientSummary(packageId: string, autoSend: any,
    byPassSpinner?: boolean): Observable<RecipientAutoSendSummaryDto> {
    autoSend.syndicates = (autoSend.indexOf('syndicates') > -1) ? true : false;
    autoSend.indications = (autoSend.indexOf('indications') > -1) ? true : false;
    autoSend.allocations = (autoSend.indexOf('allocations') > -1) ? true : false;

    return this.apiService.getPackageAutoSendRecipientSummary(packageId, autoSend, byPassSpinner);
  }
}
