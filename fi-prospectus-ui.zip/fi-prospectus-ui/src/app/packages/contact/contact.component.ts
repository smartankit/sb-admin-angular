import { Component, OnInit } from '@angular/core';
import { Subject, Observable } from 'rxjs';
import { HelperService } from '../../shared/helper.service';
import { PackageService } from '../package.service';
import { RecipientDto, PackageRecipientDto } from '../../../common';
import { RecipientService } from '../recipients/recipient.service';
import { ContactType } from '../../../common/enum';
import { NotificationService } from '../../../common/notification/notification.service';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.scss']
})
export class ContactComponent implements OnInit {
  employerRoles: string[]; response: Subject<any>; contactContainer: any; contact: RecipientDto; id: number;
  context: Observable<any>; recipientGridInfo: PackageRecipientDto;
  contactType: typeof ContactType = ContactType;

  constructor(private packageService: PackageService, private helperService: HelperService,
    private recipientService: RecipientService, private notificationService: NotificationService) { }

  ngOnInit() {
    this.context.subscribe((recipientGridInfo) => {
      this.recipientGridInfo = recipientGridInfo;
      this.getContactInfo(this.recipientGridInfo.contactId, recipientGridInfo.role);
    });
    this.initModal();
  }

  initModal(): void {
    this.contact = new RecipientDto();
    this.contactContainer = document.getElementById('contact-container');
  }

  checkForNull(value: string): string {
    if (value === null) {
      value = 'N/A';
    }
    return value;
  }

  getContactInfo(contactId: string, type: string): void {
    this.recipientService.getContactInfo(contactId, type).subscribe((contact) => {
      this.contact = contact;
    });
  }

  putContactInfo(contact: RecipientDto): void {

    this.recipientService.putContactInfo(contact).subscribe((contactForIB) => {
      this.response.next({ action: 'save' });
    },
      (err) => {
        this.notificationService.error(err.message);
      });
  }

  checkForEmail(value: any): boolean {
    return (/\S+@\S+\.\S+/.test(value) ? true : false);
  }

  validateForm(): boolean {
    let invalidElements, fields;
    fields = document.querySelectorAll('[validateField]');
    for (let i = 0; i < fields.length; i++) {
      this.validateField(fields[i]);
    }
    invalidElements = this.contactContainer.getElementsByClassName('invalidInput');
    return ((invalidElements.length > 0) ? false : true);
  }

  validateField(element: any): void {
    let value, field;
    value = element.value;
    field = element.getAttribute('validateField');
    switch (field) {
      case 'firstName': if (!value) {
        this.helperService.showTooltip(element, 'First name is required');
      } else {
        this.helperService.hideTooltip(element);
      }
        break;
      case 'lastName': if (!value) {
        this.helperService.showTooltip(element, 'Last name is required');
      } else {
        this.helperService.hideTooltip(element);
      }
        break;
      case 'emailAddress1': if (!this.checkForEmail(value)) {
        this.helperService.showTooltip(element, 'Email format Is invalid');
      } else {
        this.helperService.hideTooltip(element);
      }
        break;
      default: break;
    }
  }

  addAddress(): void {
  }

  save(): void {
    if (this.validateForm()) {
      this.putContactInfo(this.contact);
    }
  }

  cancel(): void {
    this.response.next({ action: 'cancel' });
  }

}
