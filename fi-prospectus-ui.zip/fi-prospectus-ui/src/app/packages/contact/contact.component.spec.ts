import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { of, Subject, Observable } from 'rxjs';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ContactComponent } from './contact.component';
import { PackageService } from '../package.service';
import { RecipientService } from '../recipients/recipient.service';
import { HelperService } from '../../shared/helper.service';
import { RecipientDto, PackageRecipientDto } from '../../../common';
import { ContactType } from '../../../common/enum';
import { NotificationService } from '../../../common/notification/notification.service';
import { CupcakeModalModule, CupcakeNotifyService } from '@ipreo/cupcake-components';


describe('ContactsComponent', () => {
  let component: ContactComponent;
  let fixture: ComponentFixture<ContactComponent>;
  let mockPackageService: PackageService;
  let mockRecipientService: RecipientService;
  let mockHelperService: HelperService;
  const mockRecipients: any[] = [
    {
      'isDealWide': false,
      'location': null,
      'prospectusTrackingId': 1850824175,
      'contactId': 'e1dc0bca-baf4-4812-9c0c-185bd1a034a1',
      'company': 'investor3',
      'role': 'Investor',
      'firstName': 'Murali',
      'lastName': 'Manchikatla',
      'email': 'murali.manchikatla@ipreo.com',
      'sentDate': '2018-09-20T13:33:01.163Z',
      'statusCode': 'sent',
      'status': null,
      'isProspectusContact': false
    },
    {
      'isDealWide': false,
      'location': null,
      'prospectusTrackingId': 1850824175,
      'contactId': 'e1dc0bca-baf4-4812-9c0c-185bd1a034a1',
      'company': 'investor3',
      'role': 'Investor',
      'firstName': 'Ravi',
      'lastName': 'T',
      'email': 'ravi.t@ipreo.com',
      'sentDate': '2018-09-20T13:33:01.163Z',
      'statusCode': 'sent',
      'status': null,
      'isProspectusContact': false
    }
  ];
  const recipientsRoles = ['All Recipients With Indications', 'External Syndicates', 'Internal Syndicates', 'Critical Contacts'];
  const packageServiceStub = {
    getEmployerRoles: function () {
      return of(recipientsRoles);
    }
  };
  const helperServiceStub = {
    showTooltip: function () {
    },
    hideTooltip: function () {
    }
  };
  const recipientServiceStub = {
    getContactInfo: function (contactId: string, type: string) {
      return of(mockRecipients[0]);
    },
    putContactInfo: function (contact: RecipientDto): Observable<string[]> {
      return of(recipientsRoles);
    }
  };

  beforeAll(function () {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 999999;
  });

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ContactComponent],
      imports: [
        CupcakeModalModule,
      ],
      schemas: [
        NO_ERRORS_SCHEMA,
        CUSTOM_ELEMENTS_SCHEMA
      ],
      providers: [
        {
          provide: PackageService, useValue: packageServiceStub
        },
        {
          provide: RecipientService, useValue: recipientServiceStub
        },
        {
          provide: HelperService, useValue: helperServiceStub
        },
        NotificationService,
        CupcakeNotifyService
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContactComponent);
    component = fixture.componentInstance;
    mockPackageService = TestBed.get(PackageService);
    mockRecipientService = TestBed.get(RecipientService);
    mockHelperService = TestBed.get(HelperService);
    component.context = of(mockRecipients[0]);
    component['response'] = new Subject<any>();
  });

  it('Should initialize the component properly', () => {
    spyOn(component, 'getContactInfo');
    spyOn(component, 'initModal');
    component.ngOnInit();
    expect(component.getContactInfo).toHaveBeenCalled();
    expect(component.initModal).toHaveBeenCalled();
  });

  it('Should initialize the modal', () => {
    let contactContainer;
    contactContainer = document.createElement('div');
    contactContainer.setAttribute('id', 'contact-container');
    spyOn(document, 'getElementById').and.returnValue(contactContainer);
    expect(component.contact).not.toBeDefined();
    component.initModal();
    expect(component.contact).toEqual(new RecipientDto());
    expect(component.contactContainer).toEqual(contactContainer);
  });

  it('Should check for null value', () => {
    let result;
    result = component.checkForNull('Sample Value');
    expect(result).toBe('Sample Value');
    result = component.checkForNull(null);
    expect(result).toBe('N/A');
  });

  it('Should get contact info', () => {
    spyOn(mockRecipientService, 'getContactInfo').and.callThrough();
    component.recipientGridInfo = mockRecipients[0];
    component.getContactInfo(mockRecipients[0].contactId, ContactType.Investor);
    expect(mockRecipientService.getContactInfo).toHaveBeenCalledWith(mockRecipients[0].contactId, ContactType.Investor);
  });

  it('Should put contact info', () => {
    spyOn(mockRecipientService, 'putContactInfo').and.callThrough();
    spyOn(component['response'], 'next');
    component.contact = mockRecipients[0];
    component.putContactInfo(mockRecipients[0]);
    expect(mockRecipientService.putContactInfo).toHaveBeenCalledWith(mockRecipients[0]);
    expect(component['response'].next).toHaveBeenCalledWith({ action: 'save' });
  });

  it('Should check for email', () => {
    let result;
    result = component.checkForEmail('user');
    expect(result).toBe(false);
    result = component.checkForEmail('user@gmail');
    expect(result).toBe(false);
    result = component.checkForEmail('user@gmail.com');
    expect(result).toBe(true);
  });

  it('Should validate form', () => {
    let fieldsDiv, fields, spyValidateField;
    component.contactContainer = document.createElement('div');
    component.contactContainer.setAttribute('class', 'invalidInput');
    fieldsDiv = document.createElement('div');
    fieldsDiv.innerHTML = '<input type="text" validateField="firstName"><input type="text" validateField="lastName">';
    fields = fieldsDiv.querySelectorAll('[validateField]');
    spyOn(document, 'querySelectorAll').and.returnValue(fields);
    spyValidateField = spyOn(component, 'validateField').and.callFake(function () { });
    component.validateForm();
    expect(spyValidateField.calls.argsFor(0)).toEqual([fields[0]]);
    expect(spyValidateField.calls.argsFor(1)).toEqual([fields[1]]);
  });

  it('Should save contact info', () => {
    spyOn(component, 'validateForm').and.returnValue(true);
    spyOn(component, 'putContactInfo');
    component.save();
    expect(component.putContactInfo).toHaveBeenCalledWith(component.contact);
  });

  it('Should cancel popup', () => {
    spyOn(component['response'], 'next');
    component.cancel();
    expect(component['response'].next).toHaveBeenCalledWith({ action: 'cancel' });
  });

});
