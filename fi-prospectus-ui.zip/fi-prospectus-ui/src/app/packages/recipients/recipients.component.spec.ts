import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { of, Subject, Observable, empty } from 'rxjs';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { DatePipe, TitleCasePipe } from '@angular/common';
import { RecipientsComponent } from './recipients.component';
import { PackageService } from '../package.service';
import { RecipientService } from './recipient.service';
import { ContactComponent } from '../contact/contact.component';
import { RecipientPagedDto, RecipientDto, PackageRecipientDto, PackageRecipientPagedDto } from '../../../common';
import { ComponentFactoryBoundToModule } from '@angular/core/src/linker/component_factory_resolver';
import { CheckboxEventType, GridUpdateType, RecipientStatus } from '../../../common/enum';

describe('RecipientsComponent', () => {
  let isChrome: boolean;
  let component: RecipientsComponent;
  let fixture: ComponentFixture<RecipientsComponent>;
  const mockPackageID = '1';
  let mockPackageService: PackageService;
  let mockRecipientService: RecipientService;
  const selectedStatus: string[] = [RecipientStatus.Sent, RecipientStatus.Failed, RecipientStatus.NotYetSent]
  const mockRecipients: RecipientDto[] = [
    {
      'id': 1,
      'contactId': 'e1dc0bca-baf4-4812-9c0c-185bd1a034a1',
      'role': 'External Syndicates',
      'company': 'Loomis, Sayles & Company, L. P.',
      'employerType': 'ICMA Investor',
      'firstName': 'Jack',
      'lastName': ' Lutz',
      'email': 'j.l@gmail.com',
      'isProspectusContact': true
    },
    {
      'id': 2,
      'contactId': 'e1dc0bca-baf4-4812-9c0c-185bd1a034a2',
      'role': 'Internal Syndicates',
      'company': 'Loomis, Sayles & Company, L. P (2).',
      'employerType': 'ICMA Investor',
      'firstName': 'Robin',
      'lastName': ' Lutz',
      'email': 'r.l@gmail.com',
      'isProspectusContact': true
    }
  ];
  const mockPackageRecipients: any[] = [
    {
      'isDealWide': false,
      'isProspectusContact': false,
      'location': null,
      'prospectusTrackingId': 1850824175,
      'contactId': 'e1dc0bca-baf4-4812-9c0c-185bd1a034a1',
      'company': 'investor3',
      'role': 'Investor',
      'firstName': 'Murali',
      'lastName': 'Manchikatla',
      'email': 'murali.manchikatla@ipreo.com',
      'sentDate': '2018-09-20T13:33:01.163Z',
      'statusCode': 'delivered',
      'status': null,
      'rowVersion': 1
    },
    {
      'isDealWide': false,
      'isProspectusContact': false,
      'location': null,
      'prospectusTrackingId': 1850824175,
      'contactId': 'e1dc0bca-baf4-4812-9c0c-185bd1a034a2',
      'company': 'investor3',
      'role': 'Investor',
      'firstName': 'Ravi',
      'lastName': 'T',
      'email': 'ravi.t@ipreo.com',
      'sentDate': '2018-09-20T13:33:01.163Z',
      'statusCode': 'delivered',
      'status': null,
      'rowVersion': 2
    }
  ];
  const emptyFunction = function () { };
  const getMockDocument = function (classValue: string) {
    const mockDocument = document.createElement('div');
    mockDocument.classList.add(classValue);
    return mockDocument;
  };
  const mockContext: any = {
    'id': 1,
    'dealName': 'Mock Deal Name',
    'packageName': 'Mock Package Name',
  };
  const leftPanePagedInfo: RecipientPagedDto = {
    items: mockRecipients,
    page: 1,
    pageSize: 100,
    total: 500
  };
  const rightPanePagedInfo: PackageRecipientPagedDto = {
    items: mockPackageRecipients,
    page: 1,
    pageSize: 100,
    total: 500
  };
  const recipientsRoles: any = ['All Recipients With Indications', 'External Syndicates', 'Internal Syndicates', 'Critical Contacts'];
  const packageServiceStub = {
    addRecipientsToPackage: function () {
      return of(mockPackageRecipients);
    },
    getPackageRecipients: function () {
      return new Observable<PackageRecipientPagedDto>(obs => {
        setTimeout(() => obs.next(rightPanePagedInfo), 1000);
      });
    }
  };
  const recipientServiceStub = {
    getRecipientsRoles: function () {
      return of(recipientsRoles);
    },
    getFilteredRecipients: function () {
      return new Observable<RecipientPagedDto>(obs => {
        setTimeout(() => obs.next(leftPanePagedInfo), 1000);
      });
    }
  };
  const datePipeStub = {};
  const params = {
    api: {
      getSelectedRows: function () {
        return [1, 2, 3];
      }
    },
  };
  const gridOptions: any = {
    api: {
      sizeColumnsToFit: function () {
      },
      hideOverlay: function () {
      },
      forEachNode: function (x: any) {
        return params;
      },
      refreshHeader: function () {
      },
      updateRowData: function () {
      },
      getDisplayedRowAtIndex: function (index: any) {
        return { data: mockPackageRecipients[0] };
      },
      getLastDisplayedRow: function () {
        return 100
      },
      getDisplayedRowCount: function () {
        return 10000;
      },
      getSelectedRows: function () {
        return 100
      }
    }
  };

  const deepCopy = function (array) {
    return JSON.parse(JSON.stringify(array));
  };
  let spyHandleLeftPaneScroll, spyGetRightPaneRecipients;

  beforeAll(function () {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 999999;
    isChrome = /Chrome/.test(navigator.userAgent) && /Google Inc/.test(navigator.vendor);
  });

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [RecipientsComponent],
      schemas: [
        NO_ERRORS_SCHEMA,
        CUSTOM_ELEMENTS_SCHEMA
      ],
      providers: [
        {
          provide: PackageService, useValue: packageServiceStub
        },
        {
          provide: RecipientService, useValue: recipientServiceStub
        },
        {
          provide: DatePipe, useValue: datePipeStub
        },
        TitleCasePipe
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecipientsComponent);
    component = fixture.componentInstance;
    component.gridOptions = gridOptions;
    mockPackageService = TestBed.get(PackageService);
    mockRecipientService = TestBed.get(RecipientService);
    component.context = of(mockContext);
    component['response'] = new Subject<any>();
    spyHandleLeftPaneScroll = spyOn(component, 'handleLeftPaneScroll').and.callFake(emptyFunction);
    spyGetRightPaneRecipients = spyOn(component, 'getRightPaneRecipients').and.callFake(emptyFunction);
    component.ngOnInit();
  });

  it('Should initialize the component properly', () => {
    spyOn(component, 'initModal').and.callFake(emptyFunction);
    spyOn(component, 'adjustWidth').and.callFake(emptyFunction);
    component.ngOnInit();
    window.dispatchEvent(new Event('resize'));
    expect(component.initModal).toHaveBeenCalled();
    expect(component.handleLeftPaneScroll).toHaveBeenCalled();
    if (isChrome) {
      expect(component.adjustWidth).toHaveBeenCalled();
    }
    expect(component.getRightPaneRecipients).toHaveBeenCalled();
    expect(component.contextObj).toBe(mockContext);
    expect(component.packageId).toBe(mockContext.id);
  });

  it('Should initialize the modal', () => {
    spyOn(mockRecipientService, 'getRecipientsRoles').and.callThrough();
    component.initModal();
    expect(mockRecipientService.getRecipientsRoles).toHaveBeenCalled();
    expect(component.recipientSearchObj.role).toBe('Select Role');
    expect(component.recipientsRoles).toBe(recipientsRoles);
  });

  it('Should handle window resize', () => {
    spyOn(component.gridOptions.api, 'sizeColumnsToFit');
    component.adjustWidth();
    expect(component.gridOptions.api.sizeColumnsToFit).toHaveBeenCalled();
  });

  it('Should handle ag-grid modelUpdated event', () => {
    let spy;
    spy = spyOn(component, 'selectAddedRecipients');
    component.gridUpdateType = GridUpdateType.ExistingRecipients;
    component.modelUpdated();
    expect(component.selectAddedRecipients).toHaveBeenCalled();
    component.gridUpdateType = GridUpdateType.NewRecipients;
    spy.calls.reset();
    component.modelUpdated();
    expect(component.selectAddedRecipients).not.toHaveBeenCalled();
  });

  it('Should handle ag-grid onGridReady event', () => {
    spyOn(component.gridOptions.api, 'hideOverlay');
    spyOn(component.gridOptions.api, 'sizeColumnsToFit');
    spyOn(component, 'setGridEvents').and.callFake(emptyFunction);
    component.onGridReady(params);
    expect(component.gridOptions.api.hideOverlay).toHaveBeenCalled();
    expect(component.gridOptions.api.sizeColumnsToFit).toHaveBeenCalled();
    expect(component.setGridEvents).toHaveBeenCalled();
  });

  it('Should select colum renderer', () => {
    let componentSelected, rendererComponent, mockParams;
    mockParams = {
      data: {
        isSpinnerRow: false
      },
      colDef: {
        colId: 'select'
      }
    };
    rendererComponent = {
      component: 'gridCheckMarkRendererComponent'
    };
    componentSelected = component.columnRendererSelector(mockParams);
    expect(componentSelected).toEqual(rendererComponent);
    mockParams.colDef.colId = 'not select';
    componentSelected = component.columnRendererSelector(mockParams);
    expect(componentSelected).toEqual(null);
    mockParams.data.isSpinnerRow = true;
    rendererComponent = {
      component: 'spinnerRendererComponent'
    };
    componentSelected = component.columnRendererSelector(mockParams);
    expect(componentSelected).toEqual(rendererComponent);
  });

  it('Should set grid events', () => {
    let headerCheckboxUnChecked, headerCheckboxChecked, headerCheckboxIndeterminate, spyUnCheckedClick, spyCheckedClick;
    spyUnCheckedClick = spyOn(component, 'headerCheckboxUnCheckedClick');
    spyCheckedClick = spyOn(component, 'headerCheckboxCheckedClick');
    headerCheckboxUnChecked = getMockDocument('ag-checkbox-unchecked');
    headerCheckboxChecked = getMockDocument('ag-checkbox-checked');
    headerCheckboxIndeterminate = getMockDocument('ag-checkbox-indeterminate');
    spyOn(document, 'getElementsByClassName').and.returnValues([headerCheckboxUnChecked], [headerCheckboxChecked],
      [headerCheckboxIndeterminate]);
    component.setGridEvents();
    headerCheckboxUnChecked.click();
    expect(component.headerCheckboxUnCheckedClick).toHaveBeenCalled();
    headerCheckboxChecked.click();
    expect(component.headerCheckboxCheckedClick).toHaveBeenCalled();
    spyUnCheckedClick.calls.reset();
    headerCheckboxIndeterminate.click();
    expect(component.headerCheckboxCheckedClick).toHaveBeenCalled();
  });

  it('Should handle checked header check box click', () => {
    component.currentEvent = null;
    component.deSelectAll = false;
    component.addedRecipients = component.addedRecipients.concat(mockPackageRecipients);
    component.deletedRecipients = component.deletedRecipients.concat(mockPackageRecipients);
    component.headerCheckboxCheckedClick();
    expect(component.currentEvent).toBe(CheckboxEventType.DeselectAll);
    expect(component.deSelectAll).toBe(true);
    expect(component.addedRecipients).toEqual([]);
    expect(component.deletedRecipients).toEqual([]);
  });

  it('Should handle unchecked header check box click', () => {
    component.currentEvent = null;
    component.deSelectAll = true;
    component.addedRecipients = component.addedRecipients.concat(mockPackageRecipients);
    component.deletedRecipients = component.deletedRecipients.concat(mockPackageRecipients);
    component.headerCheckboxUnCheckedClick();
    expect(component.currentEvent).toBe(CheckboxEventType.SelectAll);
    expect(component.deSelectAll).toBe(false);
    expect(component.addedRecipients).toEqual([]);
    expect(component.deletedRecipients).toEqual([]);
  });

  it('Should handle row selection event', () => {
    let recipient, mockParams, spyIsSelected;
    recipient = new RecipientDto();
    mockParams = {
      data: {
        contactId: mockPackageRecipients[0].contactId,
        sentDate: '2011-1-12',
        id: 1
      },
      node: {
        setSelected: function (select) {
        },
        isSelected: function (select) {
        },
        data: {
          'name': 'Investor 1'
        }
      }
    };
    spyIsSelected = spyOn(mockParams.node, 'isSelected');
    component.rightPaneRecipientCount = 10;
    component.currentEvent = CheckboxEventType.DeselectAll;
    component.onRowSelected(mockParams);
    expect(component.rightPaneRecipientCount).toBe(0);
    component.currentEvent = CheckboxEventType.SelectAll;
    component.totalExistingRecipientCount = 100;
    component.recipientsAddedFromLeftPane = 5;
    component.addedRecipients = [];
    mockParams.data.id = null;
    component.onRowSelected(mockParams);
    expect(component.addedRecipients).toEqual([mockParams.data]);
    expect(component.rightPaneRecipientCount).toBe(105);
    mockParams.data.id = 1;
    component.addedRecipients = [];
    component.onRowSelected(mockParams);
    expect(component.addedRecipients).toEqual([]);
    expect(component.rightPaneRecipientCount).toBe(105);
    component.currentEvent = CheckboxEventType.Individual;
    mockParams.data.id = 1;
    spyIsSelected.and.returnValue(true);
    component.bulkSelectionInProgress = false;
    component.rightPaneRecipientCount = 0;
    component.deSelectAll = true;
    component.addedRecipients = [];
    component.onRowSelected(mockParams);
    expect(component.addedRecipients).toEqual([mockParams.data]);
    expect(component.rightPaneRecipientCount).toEqual(1);
    component.deSelectAll = false;
    component.deletedRecipients = [];
    component.deletedRecipients = component.deletedRecipients.concat(mockPackageRecipients);
    component.onRowSelected(mockParams);
    expect(component.deletedRecipients).toEqual([mockPackageRecipients[1]]);
    spyIsSelected.and.returnValue(false);
    component.rightPaneRecipientCount = 1;
    component.deSelectAll = false;
    component.deletedRecipients = [];
    component.onRowSelected(mockParams);
    expect(component.deletedRecipients).toEqual([mockParams.data]);
    expect(component.rightPaneRecipientCount).toEqual(0);
    component.rightPaneRecipientCount = 1;
    component.deSelectAll = true;
    component.addedRecipients = [];
    component.addedRecipients = component.addedRecipients.concat(mockPackageRecipients);
    component.onRowSelected(mockParams);
    expect(component.addedRecipients).toEqual([mockPackageRecipients[1]]);
    expect(component.rightPaneRecipientCount).toEqual(0);
    mockParams.data.id = null;
    spyIsSelected.and.returnValue(true);
    component.rightPaneRecipientCount = 0;
    component.addedRecipients = [];
    component.onRowSelected(mockParams);
    expect(component.addedRecipients).toEqual([mockParams.data]);
    expect(component.rightPaneRecipientCount).toEqual(1);
    spyIsSelected.and.returnValue(false);
    component.onRowSelected(mockParams);
    expect(component.addedRecipients).toEqual([]);
    expect(component.rightPaneRecipientCount).toEqual(0);
  });

  it('Should get left pane recipients', fakeAsync(() => {
    let initComponentVaribles, origValue;
    initComponentVaribles = function (leftPanePageNumber, leftPaneRecipients,
      leftPaneLoading, selectedAllRecipients) {
      component.leftPanePageNumber = leftPanePageNumber;
      component.leftPaneRecipients = leftPaneRecipients;
      component.selectedAllRecipients = true;
      component.leftPaneLoading = false;
    };
    initComponentVaribles(0, null, false, true);
    component.packageId = '1';
    component.getLeftPaneRecipients(true);
    expect(component.leftPanePageNumber).toBe(1);
    expect(component.leftPaneRecipients).toEqual([]);
    expect(component.selectedAllRecipients).toBe(false);
    expect(component.leftPaneLoading).toBe(true);
    expect(component.packageId).toBe('1');
    tick(1000);
    expect(component.leftPaneLoading).toBe(false);
    expect(component.leftPaneRecipients.length).toBe(2);
    initComponentVaribles(2, component.leftPaneRecipients, false, true);
    origValue = [];
    origValue = origValue.concat(deepCopy(component.leftPaneRecipients));
    spyOn(component, 'toggleAllLeftPaneRecipients');
    spyHandleLeftPaneScroll.calls.reset();
    component.getLeftPaneRecipients(false);
    expect(component.leftPanePageNumber).toBe(2);
    expect(component.leftPaneRecipients.length).toBe(2);
    expect(component.leftPaneLoading).toBe(true);
    expect(component.selectedAllRecipients).toBe(true);
    tick(1000);
    expect(component.leftPaneLoading).toBe(false);
    origValue = origValue.concat(deepCopy(origValue));
    expect(component.leftPaneRecipients).toEqual(origValue);
    expect(component.leftPaneRecipients.length).toBe(4);
    expect(component.leftPaneRecipientCount).toBe(500);
    expect(component.toggleAllLeftPaneRecipients).toHaveBeenCalled();
    component.leftPanePageNumber = 4;
    spyHandleLeftPaneScroll.calls.reset();
    component.getLeftPaneRecipients(false);
    tick(1000);
    expect(component.handleLeftPaneScroll).toHaveBeenCalled();
    component.leftPanePageNumber = 6;
    spyHandleLeftPaneScroll.calls.reset();
    component.getLeftPaneRecipients(false);
    tick(1000);
    expect(component.handleLeftPaneScroll).not.toHaveBeenCalled();
  }));

  it('Should get all filtered recipients', fakeAsync(() => {
    component.getAllFilteredRecipients(1);
    expect(component.rightPaneLoading).toBe(true);
    expect(component.leftPaneRecipients).toEqual([]);
    expect(component.leftPaneRecipientCount).toBe(0);
    expect(component.allLeftPaneRecipientsSelected).toBe(false);
    tick(5000);
    expect(component.rightPaneLoading).toBe(false);
  }));

  it('Should get right pane recipients', fakeAsync(() => {
    let initComponentVaribles, addInfo, spy1, spy2, spy3, spy4, spy5;
    initComponentVaribles = function (packageId, rightPanePageNumber, rightPaneRecipientPageSize
    ) {
      component.packageId = packageId;
      component.rightPanePageNumber = rightPanePageNumber;
      component.rightPaneRecipientPageSize = rightPaneRecipientPageSize;
    };
    addInfo = { add: rightPanePagedInfo.items };
    spyGetRightPaneRecipients.and.callThrough();
    spy1 = spyOn(component, 'removeSpinnerRow').and.callFake(emptyFunction);
    spy2 = spyOn(component, 'addSpinnerRow').and.callFake(emptyFunction);
    spy3 = spyOn(component, 'handleRightPaneScroll').and.callFake(emptyFunction);
    spy4 = spyOn(mockPackageService, 'getPackageRecipients').and.callThrough();
    spy5 = spyOn(component.gridOptions.api, 'updateRowData').and.callThrough();
    initComponentVaribles('1', 1, 100);
    component.getRightPaneRecipients();
    expect(component.rightPaneLoading).toBe(true);
    expect(mockPackageService.getPackageRecipients).toHaveBeenCalledWith('1', selectedStatus, component.rightPanePageNumber,
      component.rightPaneRecipientPageSize, false);
    tick(1000);
    expect(component.rightPaneLoading).toBe(false);
    expect(component.currentEvent).toBe(CheckboxEventType.Individual);
    expect(component.removeSpinnerRow).toHaveBeenCalled();
    expect(component.rightPaneRecipientCount).toBe(500);
    expect(component.rightPanePageNumber).toBe(2);
    expect(component.handleRightPaneScroll).toHaveBeenCalled();
    expect(component.gridOptions.api.updateRowData).toHaveBeenCalledWith(addInfo);
    spyGetRightPaneRecipients.calls.reset();
    spy1.calls.reset(); spy2.calls.reset(); spy3.calls.reset(); spy4.calls.reset(); spy5.calls.reset();
    initComponentVaribles('1', 12, 100);
    component.getRightPaneRecipients();
    expect(component.rightPaneLoading).toBe(true);
    expect(mockPackageService.getPackageRecipients).toHaveBeenCalledWith('1', selectedStatus, component.rightPanePageNumber,
      component.rightPaneRecipientPageSize, true);
    tick(1000);
    expect(component.rightPaneLoading).toBe(false);
    expect(component.currentEvent).toBe(CheckboxEventType.Individual);
    expect(component.removeSpinnerRow).toHaveBeenCalled();
    expect(component.rightPaneRecipientCount).toBe(500);
    expect(component.rightPanePageNumber).toBe(12);
    expect(component.handleRightPaneScroll).not.toHaveBeenCalled();
    expect(component.gridOptions.api.updateRowData).toHaveBeenCalledWith(addInfo);
  }));

  it('Should remove spinner row', () => {
    let spyUpdateRowData, spyElementsByClassName, gridViewport, spinnerRowRemove;
    gridViewport = [
      {
        scrollHeight: 400,
        clientHeight: 200
      }
    ];
    spinnerRowRemove = {
      remove: [mockPackageRecipients[0]]
    };
    spyElementsByClassName = spyOn(document, 'getElementsByClassName').and.returnValue(gridViewport);
    spyOn(component.gridOptions.api, 'getLastDisplayedRow').and.callThrough();
    spyOn(component.gridOptions.api, 'getDisplayedRowAtIndex').and.callThrough();
    spyUpdateRowData = spyOn(component.gridOptions.api, 'updateRowData');
    component.removeSpinnerRow();
    expect(component.gridOptions.api.updateRowData).toHaveBeenCalledWith(spinnerRowRemove);
    expect(component.gridOptions.api.getLastDisplayedRow).toHaveBeenCalled();
    expect(component.gridOptions.api.getDisplayedRowAtIndex).toHaveBeenCalled();
    spyUpdateRowData.calls.reset();
    gridViewport[0].scrollHeight = 100;
    spyElementsByClassName.and.returnValue(gridViewport);
    component.removeSpinnerRow();
    expect(component.gridOptions.api.updateRowData).not.toHaveBeenCalled();
  });

  it('Should add spinner row', () => {
    let spyUpdateRowData, spyElementsByClassName, gridViewport, spinnerRow, spinnerRowAdd;
    gridViewport = [
      {
        scrollHeight: 400,
        clientHeight: 200
      }
    ];
    spinnerRow = new PackageRecipientDto();
    spinnerRow.isSpinnerRow = true;
    spinnerRowAdd = { add: [spinnerRow], addIndex: 10000 };
    spyElementsByClassName = spyOn(document, 'getElementsByClassName').and.returnValue(gridViewport);
    spyOn(component.gridOptions.api, 'getDisplayedRowCount').and.callThrough();
    spyUpdateRowData = spyOn(component.gridOptions.api, 'updateRowData');
    component.addSpinnerRow();
    expect(component.gridOptions.api.updateRowData).toHaveBeenCalledWith(spinnerRowAdd);
    expect(component.gridOptions.api.getDisplayedRowCount).toHaveBeenCalled();
    spyUpdateRowData.calls.reset();
    gridViewport[0].scrollHeight = 100;
    spyElementsByClassName.and.returnValue(gridViewport);
    component.addSpinnerRow();
    expect(component.gridOptions.api.updateRowData).not.toHaveBeenCalled();
  });

  it('Should select added recipients', fakeAsync(() => {
    component.bulkSelectionInProgress = false;
    spyOn(component.gridOptions.api, 'forEachNode');
    component.selectAddedRecipients();
    expect(component.bulkSelectionInProgress).toBe(true);
    expect(component.gridOptions.api.forEachNode).toHaveBeenCalled();
    tick(0);
    expect(component.bulkSelectionInProgress).toBe(false);
  }));

  it('Should toggle all left pane recipients', fakeAsync(() => {
    let i;
    component.getLeftPaneRecipients(true);
    tick(1000);
    component.allLeftPaneRecipientsSelected = true;
    component.toggleAllLeftPaneRecipients();
    for (i = 0; i < component.leftPaneRecipients.length; i++) {
      expect(component.leftPaneRecipients[i].selected).toBe(true);
    }
    component.allLeftPaneRecipientsSelected = false;
    component.toggleAllLeftPaneRecipients();
    for (i = 0; i < component.leftPaneRecipients.length; i++) {
      expect(component.leftPaneRecipients[i].selected).toBe(false);
    }
  }));

  it('Should handle all left pane recipients selection/deselection', () => {
    let spyselectAll;
    component.allLeftPaneRecipientsSelected = true;
    component.leftPaneCheckedRecipients = component.leftPaneCheckedRecipients.concat(mockRecipients);
    component.leftPaneUnCheckedRecipients = component.leftPaneUnCheckedRecipients.concat(mockRecipients);
    spyselectAll = spyOn(component, 'toggleAllLeftPaneRecipients');
    component.allRecipientSelectionChanged();
    expect(component.leftPaneCheckedRecipients).toEqual([]);
    expect(component.leftPaneUnCheckedRecipients).toEqual([]);
    expect(component.allLeftPaneRecipientsSelected).toBe(false);
    expect(component.toggleAllLeftPaneRecipients).toHaveBeenCalled();
    spyselectAll.calls.reset();
    component.allLeftPaneRecipientsSelected = false;
    component.allRecipientSelectionChanged();
    expect(component.leftPaneCheckedRecipients).toEqual([]);
    expect(component.leftPaneUnCheckedRecipients).toEqual([]);
    expect(component.allLeftPaneRecipientsSelected).toBe(true);
    expect(component.toggleAllLeftPaneRecipients).toHaveBeenCalled();
  });

  it('Should toggle selected recipients', () => {
    let recipient;
    recipient = deepCopy(mockRecipients[0]);
    recipient.selected = false;
    component.allLeftPaneRecipientsSelected = false;
    component.leftPaneCheckedRecipients = [];
    component.toggleSelectRecipient(recipient);
    expect(recipient.selected).toBe(true);
    expect(component.leftPaneCheckedRecipients).toEqual([recipient]);
    expect(component.disableAddRecipients).toBe(false);
    component.toggleSelectRecipient(recipient);
    expect(recipient.selected).toBe(false);
    expect(component.leftPaneCheckedRecipients).toEqual([]);
    expect(component.disableAddRecipients).toBe(true);
    recipient.selected = true;
    component.allLeftPaneRecipientsSelected = true;
    component.leftPaneUnCheckedRecipients = [];
    component.toggleSelectRecipient(recipient);
    expect(recipient.selected).toBe(false);
    expect(component.leftPaneUnCheckedRecipients).toEqual([recipient]);
    recipient.selected = false;
    component.allLeftPaneRecipientsSelected = true;
    component.toggleSelectRecipient(recipient);
    expect(recipient.selected).toBe(true);
    expect(component.leftPaneUnCheckedRecipients).toEqual([]);
  });

  it('Should add left pane recipients to grid', () => {
    let spy1, addInfo;
    component.leftPaneCheckedRecipients = [];
    component.leftPaneCheckedRecipients = component.leftPaneCheckedRecipients.concat(mockRecipients);
    component.gridContactIds = [];
    component.gridContactIds.push(mockRecipients[0].contactId);
    spy1 = spyOn(component.gridOptions.api, 'updateRowData').and.callThrough();
    spyOn(component.gridOptions.api, 'forEachNode');
    addInfo = { add: [mockRecipients[1]], addIndex: 0 }
    component.addLeftPaneRecipientsToGrid();
    expect(component.gridOptions.api.updateRowData).toHaveBeenCalledWith(addInfo);
    expect(component.gridOptions.api.forEachNode).toHaveBeenCalled();
    expect(component.recipientsAddedFromLeftPane).toBe(1);
    expect(component.gridUpdateType).toBe(GridUpdateType.NewRecipients);
    expect(component.currentEvent).toBe(CheckboxEventType.Individual);
    expect(component.leftPaneCheckedRecipients).toEqual([]);
    expect(component.gridContactIds).toEqual([mockRecipients[0].contactId, mockRecipients[1].contactId]);
  });

  it('Should handle add recipients click', () => {
    let spy1, spy2;
    component.leftPaneRecipients = [];
    component.leftPaneCheckedRecipients = [];
    component.leftPaneRecipients = component.leftPaneRecipients.concat(mockRecipients);
    component.leftPaneCheckedRecipients = component.leftPaneCheckedRecipients.concat(mockRecipients);
    component.leftPaneRecipientCount = mockRecipients.length;
    spy1 = spyOn(component, 'getAllFilteredRecipients');
    spy2 = spyOn(component, 'addLeftPaneRecipientsToGrid');
    component.allLeftPaneRecipientsSelected = true;
    component.addRecipientsClick();
    expect(component.leftPaneRecipients).toEqual([]);
    expect(component.leftPaneRecipientCount).toEqual(0);
    expect(component.getAllFilteredRecipients).toHaveBeenCalledWith(1);
    expect(component.addLeftPaneRecipientsToGrid).not.toHaveBeenCalled();
    spy1.calls.reset();
    spy2.calls.reset();
    component.allLeftPaneRecipientsSelected = false;
    component.addRecipientsClick();
    expect(component.getAllFilteredRecipients).not.toHaveBeenCalled();
    expect(component.addLeftPaneRecipientsToGrid).toHaveBeenCalled();
  });

  it('Should handle clear filter click', fakeAsync(() => {
    component.getLeftPaneRecipients(true);
    tick(1000);
    spyOn(component.recipientSearchObj, 'resetThis');
    component.clearClick();
    expect(component.recipientSearchObj.resetThis).toHaveBeenCalled();
    expect(component.leftPaneRecipientCount).toBe(0);
    expect(component.leftPaneRecipients).toEqual([]);
    expect(component.leftPaneCheckedRecipients).toEqual([]);
    expect(component.disableAddRecipients).toBe(false);
    expect(component.filtersApplied).toBe(false);
    expect(component.allLeftPaneRecipientsSelected).toBe(false);
  }));

  it('Should handle save recipients', () => {
    const mockId = '1';
    let succesMessage, addDeleteRecipientInfo;
    succesMessage = '1 recipient added';
    spyOn(component, 'getSuccessMessage').and.returnValue(succesMessage);
    component.packageId = mockId;
    component.deSelectAll = true;
    component.addedRecipients = [deepCopy(mockPackageRecipients[0])];
    component.deletedRecipients = [deepCopy(mockPackageRecipients[1])];
    addDeleteRecipientInfo = {
      'deSelectAll': true,
      'added': component.addedRecipients,
      'deleted': component.deletedRecipients
    };
    spyOn(component['response'], 'next');
    spyOn(mockPackageService, 'addRecipientsToPackage').and.callThrough();
    component.saveClick();
    expect(mockPackageService.addRecipientsToPackage).toHaveBeenCalledWith(mockId, addDeleteRecipientInfo);
    expect(component['response'].next).toHaveBeenCalledWith({ action: 'add', 'succesMessage': succesMessage });
  });

  it('Should get success message', () => {
    let mockItems;
    mockItems = [
      {
        sentDate: '2010-01-01'
      },
      {
        sentDate: null
      }
    ];
    spyOn(component.gridOptions.api, 'getSelectedRows').and.returnValue(mockItems);
    expect(component.getSuccessMessage()).toBe('1 Contacts added');
  });

  it('Should pluck an array', () => {
    let contactIds, contactIdsResult;
    contactIds = component.pluck(mockRecipients, 'contactId');
    contactIdsResult = mockRecipients.map(o => o['contactId']);
    expect(contactIds).toEqual(contactIdsResult);
  });

});
