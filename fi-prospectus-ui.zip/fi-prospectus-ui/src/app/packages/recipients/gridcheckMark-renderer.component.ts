import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { CheckboxEventType } from '../../../common/enum';

@Component({
  selector: 'app-gridcheckmark-renderer',
  template: `
                <div *ngIf="!params.data.sentDate" class="checkBox inlineBlock ag-selection-checkbox">
                    <i *ngIf="params.node.isSelected()" class="verticalAlign fa fa-check-square c-text-primary selectAll-icon"
                        (click)="toggleSelectRecipient();"></i>
                    <span *ngIf="!params.node.isSelected()" class="verticalAlign ag-icon ag-icon-checkbox-unchecked"
                        (click)="toggleSelectRecipient();"></span>
                </div>
                <i *ngIf="params.data.sentDate" class="fa fa-check gridCheckMark"></i>
            `,
            styleUrls: ['./gridcheckMark-renderer.component.scss']
})
export class GridCheckMarkRendererComponent implements ICellRendererAngularComp {

  params: any; componentParent: any;

  constructor() {}

  agInit(params: any): void {
    this.params = params;
    this.componentParent = params.context.componentParent;
  }

  toggleSelectRecipient() {
    this.componentParent.currentEvent = CheckboxEventType.Individual;
    this.params.node.setSelected(!this.params.node.isSelected());
  }

  refresh(): boolean {
    return false;
  }

}
