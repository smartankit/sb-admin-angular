import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';

@Component({
  selector: 'app-gridspinner-renderer',
  template: `
              <div class="recipientSpinner c-full-page-loader"></div>
            `,
            styleUrls: ['./spinner-renderer.component.scss']
})
export class SpinnerRendererComponent implements ICellRendererAngularComp {

  constructor() {}

  agInit(params: any): void {
  }

  refresh(): boolean {
    return false;
  }

}
