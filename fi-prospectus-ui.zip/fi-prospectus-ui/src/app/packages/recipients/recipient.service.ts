import { Injectable } from '@angular/core';
import { ApiService, RecipientDto, RecipientPagedDto } from '../../../common';
import { Observable, BehaviorSubject } from 'rxjs';
import { RecipientSearchParameterDto, ContactRolesDto } from '../../../common';

@Injectable()
export class RecipientService {

  constructor(private apiService: ApiService) { }

  public getFilteredRecipients(recipientSearchObj: RecipientSearchParameterDto,
    pageNumber: any, pageSize: number, byPassSpinner: boolean): Observable<RecipientPagedDto> {
    return this.apiService.getFilteredRecipients(recipientSearchObj, pageNumber, pageSize, byPassSpinner);
  }

  public getRecipientsRoles(): Observable<ContactRolesDto[]> {
    return this.apiService.getRecipientsRoles();
  }

  public getContactInfo(contactId: string, type: string) {
    return this.apiService.getContactInfo(contactId, type);
  }

  public putContactInfo(contact: RecipientDto) {
    return this.apiService.putContactInfo(contact);
  }

}
