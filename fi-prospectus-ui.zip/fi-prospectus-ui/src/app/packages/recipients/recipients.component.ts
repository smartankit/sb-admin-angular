import { Component, OnInit } from '@angular/core';
import { DatePipe, TitleCasePipe } from '@angular/common';
import { ColDef, GridOptions, GridApi, RowNode } from 'ag-grid';
import { Subject, Observable } from 'rxjs';
import { SpinnerRendererComponent } from './spinner-renderer.component';
import { GridCheckMarkRendererComponent } from './gridcheckMark-renderer.component';
import { PackageService } from '../package.service';
import { RecipientService } from './recipient.service';
import {
  RecipientDto, RecipientPagedDto, PackageRecipientDto, PackageRecipientPagedDto, RecipientSearchParameterDto, ContactRolesDto,
  AddDeleteRecipientInfoDto
} from '../../../common';
import { ContactComponent } from '../contact/contact.component';
import { DealType, CheckboxEventType, GridUpdateType, RecipientStatus } from '../../../common/enum';

@Component({
  selector: 'app-recipients',
  templateUrl: './recipients.component.html',
  styleUrls: ['./recipients.component.scss']
})
export class RecipientsComponent implements OnInit {

  columnDefs: ColDef[]; gridOptions: any; overlayNoRowsTemplate: string; response: Subject<any>; context: Observable<string>;
  addedRecipients: PackageRecipientDto[] = []; deletedRecipients: PackageRecipientDto[] = []; deSelectAll = false;
  disableAddRecipients = false; contextObj: any; leftPaneRecipientPageSize = 100; recipientsRoles: ContactRolesDto[];
  packageId: string; recipientSearchObj: RecipientSearchParameterDto; gridContactIds: string[] = []; filtersApplied = false;
  leftPaneRecipients: RecipientDto[] = []; rightPaneRecipientPageSize = 100; recipientsFetchedInLastCall = 0; frameworkComponents: any;
  leftPaneCheckedRecipients: any = []; leftPaneLoading = false; leftPaneRecipientCount = 0; leftPanePageNumber = 0;
  rightPaneLoading = false; rightPaneRecipientCount = 0; rightPanePageNumber = 1; allLeftPaneRecipientsSelected = false;
  filteredRecipientLoading = false; addDeleteRecipientInfo: AddDeleteRecipientInfoDto; selectedAllRecipients = false;
  gridUpdateType: string; currentEvent = CheckboxEventType.None; bulkSelectionInProgress = false; totalExistingRecipientCount = 0;
  leftPaneUnCheckedRecipients: any = []; leftPaneUnCheckedRecipientsIds: any = []; recipientsAddedFromLeftPane = 0;
  RecipientStatusType: typeof RecipientStatus = RecipientStatus;
  selectedStatus: string[] = [this.RecipientStatusType.Sent, this.RecipientStatusType.Failed, this.RecipientStatusType.NotYetSent]
  constructor(private packageService: PackageService, private recipientService: RecipientService, public datePipe: DatePipe,
    private titleCasePipe: TitleCasePipe) {
    this.columnDefs = [
      {
        colId: 'select',
        field: 'select',
        headerName: '',
        width: 50,
        headerCheckboxSelection: true,
        checkboxSelection: false,
        colSpan: function (params) {
          return params.data.isSpinnerRow === true ? 7 : 1;
        }
      },
      {
        field: 'contactId',
        hide: true
      },
      {
        field: 'packageRecipientId',
        hide: true
      },
      {
        headerName: 'Company',
        type: ['mediumCell'],
        field: 'company'
      },
      {
        headerName: 'Role',
        field: 'role',
        type: ['mediumCell'],
        valueFormatter: (params) => {
          return this.titleCasePipe.transform(params.data.role);
        }
      },
      {
        headerName: 'Contact Name',
        valueGetter: (params) => {
          return params.data.firstName + ' ' + params.data.lastName;
        }
      },
      {
        headerName: 'Contact Email',
        field: 'email'
      },
      {
        headerName: 'Mandatory Document Contact',
        type: ['mediumCell'],
        valueGetter: (params) => {
          return (params.data.isProspectusContact ? 'Yes' : 'No');
        }
      },
      {
        headerName: 'Sent On',
        valueGetter: ((params) => {
          if (params.data.sentDate) {
            return this.datePipe.transform(params.data.sentDate, 'dd.MMM.yyyy,  h:mm a');
          } else {
            return params.data.sentDate;
          }
        }
        )
      }
      // {
      //   headerName: 'Tranche(s)',
      //   valueGetter: ( (params) => { return (params.data.isDealWide ? DealType.DealWide : DealType.TrancheSpecific); } )
      // }
    ];
    this.frameworkComponents = {
      spinnerRendererComponent: SpinnerRendererComponent,
      gridCheckMarkRendererComponent: GridCheckMarkRendererComponent
    };
    this.gridOptions = {
      suppressRowClickSelection: true,
      defaultColDef: {
        cellRendererSelector: (params => {
          return this.columnRendererSelector(params);
        }),
        filterParams: { newRowsAction: 'keep' }
      },
      enableSorting: false,
      enableFilter: false,
      suppressScrollOnNewData: true,
      unSortIcon: true,
      columnDefs: this.columnDefs,
      enableColResize: true,
      context: {
        componentParent: this
      },
      icons: {
        checkboxChecked: '<i class="fa fa-check-square c-text-primary selectAll-icon"></i>',
      },
      rowSelection: 'multiple',
      columnTypes: {
        mediumCell: {
          width: 150
        }
      },
      rowClassRules: {
        'ag-row-selected': function (params) {
          return params.node.selected === true;
        },
      },
    };
    this.overlayNoRowsTemplate =
      '<span style=\"padding: 10px; border: 2px solid #444; background: lightgoldenrodyellow;\">No Recipients are available</span>';
  }

  ngOnInit(): void {
    const that = this;
    this.initModal();
    this.handleLeftPaneScroll();
    window.onresize = function (event) {
      that.adjustWidth();
    };
    this.context.subscribe((context: any) => {
      this.contextObj = context;
      this.packageId = context.id;
      this.getRightPaneRecipients();
    });
  }

  initModal(): void {
    this.recipientSearchObj = new RecipientSearchParameterDto();
    this.recipientSearchObj.role = 'Select Role';
    this.recipientService.getRecipientsRoles().subscribe((recipientsRoles: ContactRolesDto[]) => {
      this.recipientsRoles = recipientsRoles;
      this.recipientsRoles.splice(0, 0, { 'name': 'Select Role', 'value': 'Select Role' });
    });
  }

  adjustWidth(): void {
    if (this.gridOptions.api && this.gridOptions.api.hasOwnProperty('sizeColumnsToFit')) {
      this.gridOptions.api.sizeColumnsToFit();
    }
  }

  modelUpdated(): void {
    if (this.gridUpdateType === GridUpdateType.ExistingRecipients) {
      this.selectAddedRecipients();
    }
  }

  onGridReady(params: any): void {
    this.gridOptions.api.hideOverlay()
    this.gridOptions.api.sizeColumnsToFit();
    this.setGridEvents();
  }

  columnRendererSelector(params: any) {
    let componentSelected = null;
    if (params.colDef.colId === 'select') {
      componentSelected = {
        component: 'gridCheckMarkRendererComponent'
      };
    }
    if (params.data.isSpinnerRow) {
      componentSelected = {
        component: 'spinnerRendererComponent'
      };
    }
    return componentSelected;
  }

  /*
    setGridEvents() sets up event listerners for the select all/ deselect all event of the ag-grid.
    During both select all and deselect all events we clear the 'addedRecipients' and 'deletedRecipients' arrays and
    capture this event in the 'deSelectAll' flag. Also the event type is captured in the 'currentEvent' flag.
    We invoke these events in the following three cases.
    1.) Deselect All Event: This is when all the rows of the grid are checked.
        During this event we click on the 'headerCheckboxChecked' span which has a class 'ag-checkbox-checked'.
        We deselect all rows of ag grid and call headerCheckboxCheckedClick event and set (currentEvent = CheckboxEventType.DeselectAll).
    2.) Select All Event: This is when all the rows of the grid are unchecked
        During this event we click on the 'headerCheckboxUnChecked' span which has a class 'ag-checkbox-unchecked'.
        We select all rows of ag grid and call headerCheckboxUnCheckedClick event and set (currentEvent = CheckboxEventType.SelectAll).
    3.) Select All Event (Inderminate): This is when some rows of the grid are checked and some other are unchecked.
        The grid attaches a class 'ag-checkbox-indeterminate' to the header check box.
        During this event we click on the 'headerCheckboxChecked' span which has a class 'ag-checkbox-indeterminate'.
        We select all rows of ag grid and call headerCheckboxUnCheckedClick event and set (currentEvent = CheckboxEventType.SelectAll).
  */
  setGridEvents() {
    let headerCheckboxUnChecked, headerCheckboxChecked, headerCheckboxIndeterminate;
    headerCheckboxUnChecked = document.getElementsByClassName('ag-checkbox-unchecked')[0];
    headerCheckboxUnChecked.addEventListener('click', this.headerCheckboxUnCheckedClick);
    headerCheckboxChecked = document.getElementsByClassName('ag-checkbox-checked')[0];
    headerCheckboxChecked.addEventListener('click', this.headerCheckboxCheckedClick);
    headerCheckboxIndeterminate = document.getElementsByClassName('ag-checkbox-indeterminate')[0];
    headerCheckboxIndeterminate.addEventListener('click', this.headerCheckboxUnCheckedClick);
  }

  headerCheckboxCheckedClick = (): void => {
    this.currentEvent = CheckboxEventType.DeselectAll;
    this.deSelectAll = true;
    this.addedRecipients = [];
    this.deletedRecipients = [];
  }

  headerCheckboxUnCheckedClick = (): void => {
    this.currentEvent = CheckboxEventType.SelectAll;
    this.deSelectAll = false;
    this.addedRecipients = [];
    this.deletedRecipients = [];
  }

  /*
    onRowSelected is an ag-grid event which is invoked in the following 5 scenarios:
    1.) Deselect All Event (currentEvent = CheckboxEventType.DeselectAll): When the grid deselect all event is triggered,
        this onRowSelected grid event is triggered once for each of the rows in the grid.
    2.) Select All Event (currentEvent = CheckboxEventType.SelectAll): When the grid select all event is triggered,
        this onRowSelected grid event is triggered once for each of the rows in the grid.
        Here we push the new recipients into the 'addedRecipients' array.
    3.) Select All Event (Indeterminate) (currentEvent = CheckboxEventType.SelectAll): When the grid select all (indeterminate) event
        is triggered, this onRowSelected grid event is triggered once for each of the unselected rows in the grid.
        Here we push the new recipients into the 'addedRecipients' array.
    4.) Select/Deselect individual recipient (currentEvent = CheckboxEventType.Individual): When an individual grid recipient is
        selected/deselected, the onRowSelected grid event is triggered once for that recipient. Here we add or remove the recipient
        from the 'addedRecipients'/ 'deletedRecipients' array accordingly.
    5.) Add filtered recipient from left pane (currentEvent = CheckboxEventType.Individual): When an individual filtered recipient is
        added from left pane, this onRowSelected grid event is triggered once once for for that recipient.
        Here we push the new recipients into the 'addedRecipients' array.
  */
  onRowSelected(params: any): void {
    if (this.currentEvent === CheckboxEventType.DeselectAll) {
      this.rightPaneRecipientCount = 0;
    } else if (this.currentEvent === CheckboxEventType.SelectAll) {
      if (!params.data.id) {
        this.addedRecipients.push(params.data);
      }
      this.rightPaneRecipientCount = this.totalExistingRecipientCount + this.recipientsAddedFromLeftPane;
    } else {
      if (params.data.id) {
        if (params.node.isSelected()) {
          if (this.deSelectAll) {
            this.addedRecipients.push(params.data);
          } else {
            this.deletedRecipients = this.deletedRecipients.filter((recipient) => recipient.contactId !== params.data.contactId);
          }
          if (!this.bulkSelectionInProgress) {
            this.rightPaneRecipientCount++;
          }
        } else {
          if (this.deSelectAll) {
            this.addedRecipients = this.addedRecipients.filter((recipient) => recipient.contactId !== params.data.contactId);
            this.rightPaneRecipientCount--;
          } else {
            this.deletedRecipients.push(params.data);
            this.rightPaneRecipientCount--;
          }
        }
      } else {
        if (params.node.isSelected()) {
          this.addedRecipients.push(params.data);
          this.rightPaneRecipientCount++;
        } else {
          this.addedRecipients = this.addedRecipients.filter((recipient) => recipient.contactId !== params.data.contactId);
          this.rightPaneRecipientCount--;
        }
      }
    }
  }

  getLeftPaneRecipients(initialFetch: boolean): void {
    this.filtersApplied = true;
    if (initialFetch) {
      this.leftPanePageNumber = 1;
      this.leftPaneRecipients = [];
      this.selectedAllRecipients = false;
    }
    this.leftPaneLoading = true;
    this.recipientSearchObj.packageId = this.packageId;
    this.recipientService.getFilteredRecipients(this.recipientSearchObj,
      this.leftPanePageNumber, this.leftPaneRecipientPageSize, true).subscribe((recipientPagedInfo: RecipientPagedDto) => {
        this.leftPaneRecipientCount = recipientPagedInfo.total;
        this.leftPaneRecipients = this.leftPaneRecipients.concat(recipientPagedInfo.items);
        this.toggleAllLeftPaneRecipients();
        this.leftPaneLoading = false;
        if (this.leftPaneRecipientPageSize * this.leftPanePageNumber < this.leftPaneRecipientCount) {
          this.leftPanePageNumber++;
          this.handleLeftPaneScroll();
        }
      });
  }

  handleLeftPaneScroll(): void {
    let leftPaneScrollListener, leftPane, leftPaneTarget;
    leftPaneScrollListener = (event) => {
      if (leftPane.scrollTop > 0) {
        leftPaneTarget = event.target;
        if ((leftPaneTarget.scrollHeight - leftPaneTarget.scrollTop - 100) < (leftPaneTarget.clientHeight)) {
          leftPaneTarget.removeEventListener('scroll', leftPaneScrollListener);
          if (!this.leftPaneLoading) {
            this.getLeftPaneRecipients(false);
          }
        }
      }
    };
    leftPane = document.getElementsByClassName('leftPaneRecipientsFull')[0];
    if (leftPane) {
      leftPane.addEventListener('scroll', leftPaneScrollListener);
    }
  }

  getRightPaneRecipients(): void {
    let byPassSpinner;
    if (this.rightPanePageNumber === 1) {
      byPassSpinner = false;
    } else {
      byPassSpinner = true;
    }
    this.rightPaneLoading = true;
    this.packageService.getPackageRecipients(this.packageId, this.selectedStatus,
      this.rightPanePageNumber, this.rightPaneRecipientPageSize, byPassSpinner)
      .subscribe((packageRecipientPagedInfo: PackageRecipientPagedDto) => {
        this.removeSpinnerRow();
        if (this.rightPanePageNumber === 1) {
          this.totalExistingRecipientCount = packageRecipientPagedInfo.total;
          this.rightPaneRecipientCount = packageRecipientPagedInfo.total;
        }
        this.currentEvent = CheckboxEventType.Individual;
        this.gridUpdateType = GridUpdateType.ExistingRecipients;
        this.recipientsFetchedInLastCall = packageRecipientPagedInfo.items.length;
        this.gridOptions.api.updateRowData({ add: packageRecipientPagedInfo.items });
        this.gridContactIds = this.gridContactIds.concat(this.pluck(packageRecipientPagedInfo.items, 'contactId'));
        this.rightPaneLoading = false;
        if ((this.rightPaneRecipientPageSize * this.rightPanePageNumber) < this.rightPaneRecipientCount) {
          this.rightPanePageNumber++;
          this.handleRightPaneScroll();
        }
      });
  }

  handleRightPaneScroll(): void {
    let rightPaneScrollListener, rightPane, rightPaneTarget;
    rightPaneScrollListener = (event) => {
      rightPaneTarget = event.target;
      if ((rightPaneTarget.scrollHeight - rightPaneTarget.scrollTop - 100) < (rightPaneTarget.clientHeight)) {
        this.addSpinnerRow();
        rightPaneTarget.removeEventListener('scroll', rightPaneScrollListener);
        this.getRightPaneRecipients();
      }
    };
    rightPane = document.getElementsByClassName('ag-body-viewport')[0];
    rightPane.addEventListener('scroll', rightPaneScrollListener);
  }

  removeSpinnerRow(): void {
    let gridViewport, lastRowData;
    gridViewport = document.getElementsByClassName('ag-body-viewport')[0];
    if (gridViewport && (gridViewport.scrollHeight > gridViewport.clientHeight)) {
      lastRowData = this.gridOptions.api.getDisplayedRowAtIndex(this.gridOptions.api.getLastDisplayedRow()).data;
      this.gridOptions.api.updateRowData({ remove: [lastRowData] });
    }
  }

  addSpinnerRow(): void {
    let spinnerRow, gridViewport;
    gridViewport = document.getElementsByClassName('ag-body-viewport')[0];
    if (gridViewport && (gridViewport.scrollHeight > gridViewport.clientHeight)) {
      spinnerRow = new PackageRecipientDto();
      spinnerRow.isSpinnerRow = true;
      this.gridOptions.api.updateRowData({ add: [spinnerRow], addIndex: this.gridOptions.api.getDisplayedRowCount() });
    }
  }

  selectAddedRecipients(): void {
    const selectionIndex = (this.gridOptions.api.getDisplayedRowCount() - 1) - this.recipientsFetchedInLastCall;
    this.bulkSelectionInProgress = true;
    this.gridOptions.api.forEachNode((node, index) => {
      if (node.data.id && (index >= selectionIndex)) {
        node.setSelected(true);
      }
    });
    setTimeout(() => {
      this.bulkSelectionInProgress = false;
    }, 0);
  }

  toggleAllLeftPaneRecipients() {
    let i;
    for (i = 0; i < this.leftPaneRecipients.length; i++) {
      this.leftPaneRecipients[i].selected = this.allLeftPaneRecipientsSelected;
    }
  }

  allRecipientSelectionChanged() {
    this.leftPaneCheckedRecipients = [];
    this.leftPaneUnCheckedRecipients = [];
    this.allLeftPaneRecipientsSelected = !this.allLeftPaneRecipientsSelected;
    this.toggleAllLeftPaneRecipients();
  }

  toggleSelectRecipient(filteredRecipient: any) {
    filteredRecipient.selected = !filteredRecipient.selected;
    if (!this.allLeftPaneRecipientsSelected) {
      if (filteredRecipient.selected) {
        this.leftPaneCheckedRecipients.push(filteredRecipient);
      } else {
        this.leftPaneCheckedRecipients = this.leftPaneCheckedRecipients.filter(item => item !== filteredRecipient);
      }
      this.disableAddRecipients = (this.leftPaneCheckedRecipients.length === 0) ? true : false;
      this.selectedAllRecipients = this.leftPaneRecipients.every(function (item: any) {
        return item.selected === true;
      });
    } else {
      if (!filteredRecipient.selected) {
        this.leftPaneUnCheckedRecipients.push(filteredRecipient);
      } else {
        this.leftPaneUnCheckedRecipients = this.leftPaneUnCheckedRecipients.
          filter((recipient) => recipient.contactId !== filteredRecipient.contactId);
      }
    }
  }

  addLeftPaneRecipientsToGrid(): void {
    this.leftPaneCheckedRecipients = this.leftPaneCheckedRecipients
      .filter((contact) => (this.gridContactIds.indexOf(contact.contactId) === -1));
    this.leftPaneCheckedRecipients.forEach((recipient) => (this.gridContactIds.push(recipient.contactId)));
    this.recipientsAddedFromLeftPane += this.leftPaneCheckedRecipients.length;
    this.gridUpdateType = GridUpdateType.NewRecipients;
    this.gridOptions.api.updateRowData({ add: this.leftPaneCheckedRecipients, addIndex: 0 });
    this.currentEvent = CheckboxEventType.Individual;
    this.gridOptions.api.forEachNode((node, index) => {
      if (index < this.leftPaneCheckedRecipients.length) {
        node.setSelected(true);
      }
    });
    this.leftPaneCheckedRecipients = [];
  }

  getAllFilteredRecipients(pageNumber: number): void {
    let pageSize;
    pageSize = 200;
    if (pageNumber === 1) {
      this.rightPaneLoading = true;
      this.leftPaneRecipients = [];
      this.leftPaneRecipientCount = 0;
      this.allLeftPaneRecipientsSelected = false;
      this.leftPaneUnCheckedRecipientsIds = this.pluck(this.leftPaneUnCheckedRecipients, 'contactId');
    }
    this.recipientService.getFilteredRecipients(this.recipientSearchObj,
      pageNumber, pageSize, false).subscribe((recipientPagedInfo: RecipientPagedDto) => {
        recipientPagedInfo.items = recipientPagedInfo.items
          .filter((recipient) => (this.leftPaneUnCheckedRecipientsIds.indexOf(recipient.contactId) < 0));
        this.leftPaneCheckedRecipients = this.leftPaneCheckedRecipients.concat(recipientPagedInfo.items);
        if ((pageSize * pageNumber) < recipientPagedInfo.total) {
          pageNumber++;
          this.getAllFilteredRecipients(pageNumber);
        } else {
          this.addLeftPaneRecipientsToGrid();
          this.rightPaneLoading = false;
        }
      });
  }

  addRecipientsClick(): void {
    this.leftPaneRecipientCount = this.leftPaneRecipientCount - this.leftPaneCheckedRecipients.length;
    this.leftPaneRecipients = this.leftPaneRecipients.filter(recipient => (this.leftPaneCheckedRecipients.indexOf(recipient) < 0));
    if (this.allLeftPaneRecipientsSelected) {
      this.getAllFilteredRecipients(1);
    } else {
      this.addLeftPaneRecipientsToGrid();
    }
  }

  clearClick(): void {
    this.allLeftPaneRecipientsSelected = false;
    this.recipientSearchObj.resetThis();
    this.leftPaneRecipientCount = 0;
    this.leftPaneRecipients = [];
    this.leftPaneCheckedRecipients = [];
    this.selectedAllRecipients = false;
    this.disableAddRecipients = false;
    this.filtersApplied = false;
  }

  saveClick(): void {
    const succesMessage = this.getSuccessMessage();
    this.addDeleteRecipientInfo = {
      'deSelectAll': this.deSelectAll,
      'added': this.addedRecipients,
      'deleted': this.deletedRecipients
    };
    this.packageService.addRecipientsToPackage(this.packageId, this.addDeleteRecipientInfo).subscribe(res => {
      this.response.next({ action: 'add', 'succesMessage': succesMessage });
    });
  }

  getSuccessMessage(): string {
    let numberOfContactsAdded: number
    numberOfContactsAdded = this.gridOptions.api.getSelectedRows().filter((item => !item.sentDate)).length
    return numberOfContactsAdded + ' Contacts added';
  }

  pluck(array, key) {
    return array.map(o => o[key]);
  }

}
