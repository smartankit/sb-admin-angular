import { TestBed } from '@angular/core/testing';
import { RecipientService } from './recipient.service';
import { ApiService } from '../../../common';

describe('RecipientService', () => {
  let mockRecipientService: RecipientService;
  let mockApiService: ApiService;
  const mockPackageId = '1';
  const mockRecipient = {
    'id': 1,
    'employer': 'Company 1',
    'employerType': 'Private Company',
    'isDealWide': false,
    'location': null,
    'prospectusTrackingId': 1850824175,
    'contactId': 'e1dc0bca-baf4-4812-9c0c-185bd1a034a1',
    'company': 'investor3',
    'role': 'Investor',
    'firstName': 'Murali',
    'lastName': 'Manchikatla',
    'email': 'murali.manchikatla@ipreo.com',
    'sentDate': '2018-09-20T13:33:01.163Z',
    'statusCode': 'sent',
    'status': null,
    'isProspectusContact': false,
    'rowVersion': 1
  };
  const apiServiceStub = {
    getRecipientsRoles: function () {
    },
    getContactInfo: function (contactId: string, type: string) {
    },
    putContactInfo: function (contacd: any) {
    }
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        RecipientService,
        {
          provide: ApiService, useValue: apiServiceStub
        }
      ],
    });
    mockRecipientService = TestBed.get(RecipientService);
    mockApiService = TestBed.get(ApiService);
  });

  it('Should get recipient roles', () => {
    spyOn(mockApiService, 'getRecipientsRoles');
    mockRecipientService.getRecipientsRoles();
    expect(mockApiService.getRecipientsRoles).toHaveBeenCalled();
  });

  it('Should get contact info', () => {
    spyOn(mockApiService, 'getContactInfo').and.callThrough();
    mockRecipientService.getContactInfo(mockRecipient.contactId, 'Investor');
    expect(mockApiService.getContactInfo).toHaveBeenCalledWith(mockRecipient.contactId, 'Investor');
  });

  it('Should put contact info', () => {
    spyOn(mockApiService, 'putContactInfo').and.callThrough();
    mockRecipientService.putContactInfo(mockRecipient);
    expect(mockApiService.putContactInfo).toHaveBeenCalledWith(mockRecipient);
  });

});
