import { Injectable } from '@angular/core';
import { ApiService, PermissionDto } from 'src/common';
import { Observable, BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PermissionService {

  constructor(private apiService: ApiService) { }

  private permission = new BehaviorSubject<PermissionDto[]>(null);

  public get permission$(): Observable<PermissionDto[]> {
    return this.permission.asObservable();
  }

  getPermissions() {
    this.apiService.getContactPermissions().subscribe((permissionLists: PermissionDto[]) =>
      this.permission.next(permissionLists)
    );
  }
}
