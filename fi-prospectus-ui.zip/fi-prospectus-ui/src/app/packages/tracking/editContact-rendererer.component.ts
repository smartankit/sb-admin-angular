import { Component, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { AgRendererComponent } from 'ag-grid-angular';
import { PermissionService } from '../permission.service';
import { PermissionType, ContactType } from 'src/common/enum';
import { FiAuthService, FiUser } from 'src/common';
import { PackageService } from '../package.service';

@Component({
  template: `
  <div #divEdit *ngIf="params.data.statusCode !== 'sent'"
  class="c-btn c-btn-secondary c-btn-xs c-btn-box c-pull-right div-hover c-m-top-xs" (click)="edit()">
  <i class="fa fa-pencil" aria-hidden="true"></i></div>
  <div> {{params.value}}
  </div>
` ,
  styles: [
    `
    .div-hover {
      opacity: 0;
      float: right;
      cursor: pointer;
    }`
  ]
})

export class EditcontactRendererComponent implements AgRendererComponent, AfterViewInit {
  params: any;
  public isEditableContact = false;
  componentParent: any;
  public user: FiUser;
  @ViewChild('divEdit') divEdit: ElementRef
  constructor(private permissionService: PermissionService) { }


  agInit(params: any): void {
    this.params = params;
    this.componentParent = this.params.context.componentParent;
  }

  ngAfterViewInit() {


    this.permissionService.permission$.subscribe((items) => {
      if (!items) {
        return;
      }

      const isEditContact = items.find(x => x.key === PermissionType.EditContact);
      if (this.componentParent.user.isSalesUser) {
        if (this.params.data.role === ContactType.Investor) {
          this.isEditableContact = isEditContact ? true : false;
        }
      } else {
        this.isEditableContact = isEditContact ? true : false;
      }

      if (this.divEdit !== undefined) {
        if (this.isEditableContact === false) {
          this.divEdit.nativeElement.style.display = 'none';
        }
      }
    });
  }

  edit() {
    this.params.context.componentParent.openRecipientsPopup(this.params);
  }

  refresh(params: any): boolean {
    return false;
  }

}
