import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { TrackingComponent } from './tracking.component';
import { ActivatedRoute } from '@angular/router';
import { PackageService } from '../package.service';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { PackageDto, AppContext, FiAuthService, FiUser, SearchPipe } from '../../../common';
import { of, Observable } from 'rxjs';
import { DatePipe, TitleCasePipe } from '@angular/common';
import {
  CupcakeGlobalsService, CupcakeModalService, CupcakeNotifyService,
  CupcakeDomService, CupcakePopoverService
} from '@ipreo/cupcake-components';
import { NotificationService } from '../../../common/notification/notification.service';
import { GridApi } from 'ag-grid';
import { DocumentService } from '../../documents/document.service';
import { PermissionService } from '../permission.service';
import { HttpClientModule } from '@angular/common/http';
import { HelperService } from 'src/app/shared/helper.service';

describe('TrackingComponent', () => {
  let component: TrackingComponent;
  let fixture: ComponentFixture<TrackingComponent>;
  let mockDocumentService: DocumentService;
  let mockPackageService: PackageService;
  let titleCasePipe: TitleCasePipe;
  let datePipe: DatePipe;
  let mockNotificationService: NotificationService;
  const mockPackageId = '1';
  const mockPackage = {
    firmId: 123,
    dealId: '456',
    trancheId: '789',
    name: 'test package',
    emailTemplateId: '39e85ff0-6c36-6793-5c41-d87cd00bc7ac',
    emailBody: '<p>blah blah 2</p>',
    expirationDate: '2018-09-22T12:00:00',
    expirationTimezone: 'America/New_York',
    subject: '3rd Deal',
    consentLanguageId: '39e85ff1-1aea-e7f7-726e-7630c8315c3b'
  } as PackageDto;

  const mockNewDocument: any = {
    'id': 1,
    'name': null,
    'fileSize': null,
    'sourceId': 1,
    'fileName': 'Prospectus.pdf',
    'documentType': null,
    'disclaimer': null,
    'isDealWide': true,
    'firmId': null,
    'dealId': null,
    'trancheId': null,
    'editable': true,
  };
  const mockRecipients: any[] = [
    {
      'isDealWide': false,
      'isProspectusContact': false,
      'location': null,
      'prospectusTrackingId': 1850824175,
      'contactId': 'e1dc0bca-baf4-4812-9c0c-185bd1a034a1',
      'company': 'investor3',
      'role': 'Investor',
      'firstName': 'Murali',
      'lastName': 'Manchikatla',
      'email': 'murali.manchikatla@ipreo.com',
      'sentDate': '2018-09-20T13:33:01.163Z',
      'statusCode': 'sent',
      'status': null
    },
    {
      'isDealWide': false,
      'isProspectusContact': false,
      'location': null,
      'prospectusTrackingId': 1850824175,
      'contactId': 'e1dc0bca-baf4-4812-9c0c-185bd1a034a1',
      'company': 'investor3',
      'role': 'Investor',
      'firstName': 'Mock',
      'lastName': 'Test',
      'email': 'mock.test@xyz.com',
      'sentDate': '2018-09-20T13:33:01.163Z',
      'statusCode': 'notYetSent',
      'status': null
    }
  ];

  const mockRouteParams = {
    id: '1',
    status: 'sent'
  };

  const mockParams = {
    api: {
      getSelectedRows: function () {
        return mockRecipients;
      },
      sizeColumnsToFit: function () {
      }
    } as GridApi,
    data: {
      statusCode: 'notYetSent',
      status: 'failed'
    },
    columnApi: {
      setColumnVisible: function () {
      },
    }
  };
  const gridOptions: any = {
    api: {
      forEachNode: function (x: any) {
      },
      hideOverlay: function () {
      },
    },
  };

  const mockFiUser = new FiUser('Test', 'Test', 'test@something.com', ['Syndicate']);

  const authServiceStub = {
    get user(): FiUser {
      return mockFiUser;
    },
    get authenticated$(): Observable<FiUser> {
      return of(mockFiUser);
    }
  };

  const mockPackages = [
    {
      id: '1',
      firmId: 123,
      dealId: '456',
      name: 'test package',
      emailTemplateId: '39e85ff0-6c36-6793-5c41-d87cd00bc7ac',
      emailBody: '<p>blah blah 2</p>',
      expirationDate: '2018-09-22T12:00:00',
      expirationTimezone: 'America/New_York',
      subject: '3rd Deal',
      consentLanguageId: '39e85ff1-1aea-e7f7-726e-7630c8315c3b',
      tranches: [],
      documents: [
        {
          fileName: 'Document.pdf'
        },
        {
          fileName: 'Document.xlsx'
        }
      ],
      autoSend: []
    },
    {
      id: '2',
      firmId: 123,
      dealId: '456',
      name: 'test package',
      emailTemplateId: '39e85ff0-6c36-6793-5c41-d87cd00bc7ac',
      emailBody: '<p>blah blah 2</p>',
      expirationDate: '2018-09-22T12:00:00',
      expirationTimezone: 'America/New_York',
      subject: '3rd Deal',
      consentLanguageId: '39e85ff1-1aea-e7f7-726e-7630c8315c3b',
      tranches: [],
      documents: [
        {
          fileName: 'Document.pdf'
        },
        {
          fileName: 'Document.xlsx'
        }
      ],
      autoSend: []
    }
  ] as PackageDto[];

  const documentServiceStub = {
    downloadDocument: function () {
    }
  }

  const permissionServiceStub = {
    getPermissions: function () {
    }
  }

  beforeAll(function () {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 999999;
  });

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule],
      declarations: [TrackingComponent, SearchPipe],
      providers: [
        {
          provide: PackageService, useValue: {
            getPackagesByDeal: jasmine.createSpy('getPackagesByDeal').and.returnValue(of(mockPackages)),
            getPackageRecipients: jasmine.createSpy('getPackageRecipients').and.returnValue(of(mockRecipients)),
            send: jasmine.createSpy('send').and.returnValue(of({}))
          }
        },
        {
          provide: ActivatedRoute, useValue: {
            queryParams: of(mockRouteParams)
          }
        },
        {
          provide: DocumentService, useValue: documentServiceStub
        },
        {
          provide: FiAuthService, useValue: authServiceStub
        },
        {
          provide: PermissionService, useValue: permissionServiceStub
        },
        DatePipe,
        TitleCasePipe,
        CupcakeModalService,
        CupcakeGlobalsService,
        NotificationService,
        CupcakeNotifyService,
        CupcakeDomService,
        AppContext,
        HelperService,
        CupcakePopoverService
      ],
      schemas: [
        NO_ERRORS_SCHEMA,
        CUSTOM_ELEMENTS_SCHEMA
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrackingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.gridOptions = gridOptions;
    component.sentGridApi = mockParams.api;
    component.notYetSentGridApi = mockParams.api;
    component.packages = mockPackages;
    mockDocumentService = TestBed.get(DocumentService);
    mockPackageService = TestBed.get(PackageService);
    mockNotificationService = TestBed.get(NotificationService);
    titleCasePipe = TestBed.get(TitleCasePipe);
    datePipe = TestBed.get(DatePipe);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should get the packages', () => {
    expect(mockPackageService.getPackagesByDeal).toHaveBeenCalled();
    expect(component.packages).toEqual(mockPackages);
    expect(mockPackageService.getPackageRecipients).toHaveBeenCalled();
  });

  // it('should load the notYetSent data', () => {
  //   const mockNotYetSent = mockRecipients.filter(recipient => {
  //     return recipient.statusCode === 'notYetSent';
  //   });

  //   expect(component.notYetSentRowData).toEqual(mockNotYetSent);
  // });

  // it('should load the sent data', () => {
  //   const mockSent = mockRecipients.filter(recipient => {
  //     return recipient.statusCode !== 'notYetSent';
  //   });

  //   expect(component.sentRowData).toEqual(mockSent);
  // });

  it('Should handle ag-grid onSentGridReady event', () => {
    spyOn(mockParams.columnApi, 'setColumnVisible');
    spyOn(mockParams.api, 'sizeColumnsToFit');
    component.onSentGridReady(mockParams);
    expect(mockParams.columnApi.setColumnVisible).toHaveBeenCalled();
    expect(mockParams.api.sizeColumnsToFit).toHaveBeenCalled();
  });

  it('Should handle ag-grid onNotYetSentGridReady event', () => {
    spyOn(mockParams.columnApi, 'setColumnVisible');
    spyOn(mockParams.api, 'sizeColumnsToFit');
    component.onNotYetSentGridReady(mockParams);
    expect(mockParams.columnApi.setColumnVisible).toHaveBeenCalled();
    expect(mockParams.api.sizeColumnsToFit).toHaveBeenCalled();
  });

  // it('Should disable add button', () => {
  //   component.selectedPackage.isDisabled = false;
  //   expect(component.isSendButtonDisabled()).toEqual(false);
  // });

  // it('Should enable add button', () => {
  //   component.selectedPackage.isDisabled = true;
  //   expect(component.isSendButtonDisabled()).toEqual(true);
  // });

  it('Should get notYetSent data', () => {
    component.recipientStatus(mockParams);
    expect(component.recipientStatus(mockParams)).toEqual('-');
  });

  it('Should get sent data', () => {
    mockParams.data.statusCode = 'sent';
    component.recipientStatus(mockParams);
    expect(component.recipientStatus(mockParams)).toEqual('Sent');
  });

  it('Should get failed data', () => {
    mockParams.data.statusCode = 'failed';
    component.recipientStatus(mockParams);
    expect(component.recipientStatus(mockParams)).toEqual(mockParams.data.status);
  });

  it('Should send email to the notYetSent recipients', () => {
    spyOn(mockNotificationService, 'success');

    component.sendPackage();
    expect(component.selectedRows).toEqual(mockParams.api.getSelectedRows());
    expect(mockNotificationService.success).toHaveBeenCalled();
  });

  it('Should download document on cell click', () => {
    spyOn(mockDocumentService, 'downloadDocument');
    component.onDocumentClicked(mockNewDocument);
    expect(mockDocumentService.downloadDocument).toHaveBeenCalledWith(mockNewDocument);
  });

  it('Should dispaly the package header', () => {
    let packageNameSpan, documentNameSpan, autoSendSpan, expirationDateSpan, dealTrancheSpan;
    packageNameSpan = fixture.debugElement.query(By.css('.packageInfo')).children[0].children[1].nativeElement;
    documentNameSpan = fixture.debugElement.query(By.css('.packageInfo')).children[1].children[1].nativeElement;
    autoSendSpan = fixture.debugElement.query(By.css('.packageInfo')).children[2].children[1].nativeElement;
    expirationDateSpan = fixture.debugElement.query(By.css('.packageInfo')).children[3].children[1].nativeElement;
    dealTrancheSpan = fixture.debugElement.query(By.css('.packageInfo')).children[4].children[1].nativeElement;
    expect(packageNameSpan.textContent.trim()).toBe(mockPackages[0].name);
    expect(documentNameSpan.textContent.trim()).toBe(mockPackages[0].documents[0].fileName);
    expect(expirationDateSpan.textContent.trim()).toBe(datePipe.transform(mockPackages[0].expirationDate, 'dd.MMM.yyyy, hh:mm a')
      + ' ' + mockPackages[0].expirationTimezone);
  });

});
