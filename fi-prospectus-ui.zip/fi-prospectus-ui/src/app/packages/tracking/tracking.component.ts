import { Component, OnInit, ViewChild, ElementRef, ViewEncapsulation, OnDestroy } from '@angular/core';
import { ColDef, GridOptions, GridApi } from 'ag-grid';
import { PackageService } from '../package.service';
import {
  PackageDto, DealDto, PackageRecipientDto, PackageRecipientPagedDto,
  DocumentDto, AppContext, FiAuthService, FiUser
} from '../../../common';
import { EditcontactRendererComponent } from './editContact-rendererer.component';
import { RecipientStatus } from '../../../common/enum';
import { DatePipe, TitleCasePipe } from '@angular/common';
import { CupcakeModalOptions, CupcakeModalService } from '@ipreo/cupcake-components';
import { ContactComponent } from '../contact/contact.component';
import { ActivatedRoute } from '@angular/router';
import { NotificationService } from '../../../common/notification/notification.service';
import { DocumentService } from '../../documents/document.service';
import { DealType } from '../../../common/enum';
import { PermissionService } from '../permission.service';
import { HelperService } from 'src/app/shared/helper.service';
import { ISubscription } from 'rxjs/Subscription';

const totalAllowedTime = (15 * 1000);
const intervalForSummaryCall = 3000;
const pollingCallsAllowed = (totalAllowedTime / intervalForSummaryCall);
let toltalLoadedRecipient = 0;
let pageNumberSize = 1;
const contactOptions: CupcakeModalOptions = {
  mode: 'component',
  type: 'default',
  view: ContactComponent,
  contentWidth: '65%',
  rootCssClass: 'contact'
};

@Component({
  selector: 'app-tracking',
  templateUrl: './tracking.component.html',
  styleUrls: ['./tracking.component.scss'],
  encapsulation: ViewEncapsulation.Emulated
})
export class TrackingComponent implements OnInit, OnDestroy {
  investorAccountId: string;
  public columnDefs: ColDef[];
  public gridOptions: GridOptions;
  public overlayNoRowsTemplate;
  public sentGridApi: GridApi;
  public notYetSentGridApi: GridApi;
  public packages: PackageDto[] = [];
  public selectedPackage: PackageDto;
  public dealTranche: string;
  public sentRowData: PackageRecipientDto[] = [];
  public notYetSentRowData: PackageRecipientDto[] = [];
  public selectedRows: any;
  public title: string;
  public displayStatus: string;
  public _NOTYETSENT = 'Not Yet Sent';
  recipientStatusType: typeof RecipientStatus = RecipientStatus;
  selectedStatus: string[] = [RecipientStatus.Sent, RecipientStatus.Failed, RecipientStatus.NotYetSent]
  public selectedPackageId: string;
  public expirationDate: string;
  public deal: DealDto;
  public sentSelectedRecipients: PackageRecipientDto[] = [];
  public showSpinner = false;
  public counter = 0;
  public user: FiUser;
  public sentFilterApply = true;
  public failedFilterApply = true;
  public notyetSentFilterApply = true;
  public trackingPageNumber = 1; public trackingPageSize = 250;
  dealType: typeof DealType = DealType;
  subscriptionPackages: ISubscription;
  @ViewChild('statusElement') statusElement: ElementRef
  @ViewChild('packageElement') packageElement: ElementRef
  constructor(private packageService: PackageService, private documentService: DocumentService, private datePipe: DatePipe,
    private ccModalService: CupcakeModalService, private route: ActivatedRoute, private titleCasePipe: TitleCasePipe,
    private notificationService: NotificationService, private permissionService: PermissionService,
    private appContext: AppContext, private authService: FiAuthService, private helperService: HelperService) {

    this.columnDefs = [
      {
        field: 'select',
        headerName: '',
        width: 40,
        headerCheckboxSelection: true,
        checkboxSelection: true,
        suppressSorting: true
      },
      {
        colId: 'statusIcon',
        headerName: '',
        width: 30,
        suppressSorting: true,
        cellRenderer: (params) => {
          const div = document.createElement('div');
          if (params.data.statusCode === RecipientStatus.Failed) {
            div.className = 'fa fa-exclamation-circle c-text-danger-9';
          }
          return div;
        },
        cellStyle: { textAlign: 'center', paddingLeft: '0', paddingRight: '0' }
      },
      {
        headerName: 'Package Name',
        field: 'packageName',
        unSortIcon: true
      },
      {
        headerName: 'Company',
        field: 'company',
        unSortIcon: true
      },
      {
        headerName: 'Role',
        valueGetter: (params) => {
          return this.titleCasePipe.transform(params.data.role);
        },
        unSortIcon: true
      },
      {
        headerName: 'Contact Name',
        valueGetter: (params) => {
          return params.data.firstName + ' ' + params.data.lastName;
        },
        unSortIcon: true
      },
      {
        headerName: 'Contact Email',
        field: 'email',
        cellRendererFramework: EditcontactRendererComponent,
        unSortIcon: true
      },
      {
        headerName: 'Sent On',
        valueGetter: (params) => {
          const sentDate = params.data.statusCode !== RecipientStatus.NotYetSent
            ? this.datePipe.transform(params.data.sentDate, 'dd.MMM.yyyy, hh:mm a') : '-';
          return sentDate;
        },
        unSortIcon: true
      },
      {
        headerName: 'Status',
        valueGetter: this.recipientStatus,
        cellRenderer: (params) => {
          const div = document.createElement('div');
          div.innerText = params.value;
          if (params.data.statusCode === RecipientStatus.Failed) {
            div.className = 'c-text-danger-9';
          } else if (params.data.statusCode === RecipientStatus.Sent) {
            div.className = 'c-text-success-9';
          }
          return div;
        },
        unSortIcon: true,
        suppressSorting: true,
      }
    ];

    this.gridOptions = {
      columnDefs: this.columnDefs,
      suppressDragLeaveHidesColumns: true,
      context: {
        componentParent: this
      },
      icons: {
        checkboxChecked: '<i class="fa fa-check-square c-text-primary selectAll-icon"></i>',
      },
      rowSelection: 'multiple'
    };
  }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.packageService.getPackagesByDeal().subscribe((packages: PackageDto[]) => {
        if (params.status) {
          this.selectedStatus = new Array();
          this.sentFilterApply = params.status === RecipientStatus.Sent;
          this.failedFilterApply = params.status === RecipientStatus.Failed;
          this.notyetSentFilterApply = params.status === RecipientStatus.NotYetSent;
          this.selectedPackageId = params.id;
          this.selectedStatus.push(params.status);
        }
        this.statusDropDownToolTip();
        this.packages = packages;
        if (params.id) {
          this.selectedPackage = this.packages.filter(item => item.id === params.id)[0];
        } else {
          this.selectedPackage = this.packages[0];
        }
        this.loadPackageData();
      });
      this.permissionService.getPermissions();
    });
    this.investorAccountId = this.appContext.investorAccountId;
    this.subcribeUser();
  }

  selectDropdownFilter(sentChecked: boolean, failedChecked: boolean, notyetsentChecked: boolean, status: string) {

    this.sentFilterApply = sentChecked;
    this.failedFilterApply = failedChecked;
    this.notyetSentFilterApply = notyetsentChecked;
    this.packageRecipientsStatus(status);
    this.loadPackageData();
    this.statusDropDownToolTip();
  }

  private statusDropDownToolTip() {
    const notYetSent = this._NOTYETSENT;
    const convertedStatus = this.selectedStatus.map(function (word) {
      if (word === RecipientStatus.NotYetSent) {
        return notYetSent;
      } else {
        return word.charAt(0).toUpperCase() + word.slice(1);
      }
    })

    this.helperService.hideTooltip(this.statusElement.nativeElement);
    this.helperService.hideTooltip(this.packageElement.nativeElement);
    this.displayStatus = convertedStatus.join(',  ')
    this.helperService.showAnyTooltip(this.statusElement.nativeElement, 'top', 'defaultPopover', this.displayStatus, 'hover');
    if (this.selectedPackage) {
      this.helperService.showAnyTooltip(this.packageElement.nativeElement, 'top', 'defaultPopover', this.selectedPackage.name, 'hover');
    }
  }

  packageRecipientsStatus(status: string) {
    if (this.selectedStatus.indexOf(status) > -1) {
      this.selectedStatus = this.selectedStatus.filter((item) => item !== status)
    } else {
      this.selectedStatus.push(status);
    }
  }

  subcribeUser() {

    this.authService.authenticated$.subscribe(user => {
      if (!user) {
        return;
      }
      this.user = user;
    })
  }

  onDocumentClicked(document: DocumentDto): void {
    this.documentService.downloadDocument(document);
  }

  onSentGridReady(params) {
    this.sentGridApi = params.api;
    this.sentGridApi.sizeColumnsToFit();
    this.gridOptions.api.hideOverlay();

    params.columnApi.setColumnVisible('select', false);
  }

  onNotYetSentGridReady(params) {
    this.notYetSentGridApi = params.api;
    this.notYetSentGridApi.sizeColumnsToFit();

    params.columnApi.setColumnVisible('statusIcon', false);
  }

  selectionChanged(event) {
    if (event.target.value === '') {
      this.selectedPackage = null;
    } else {
      this.selectedPackage = this.packages.filter(item => item.id === event.target.value)[0];
    }
    this.statusDropDownToolTip();
    this.loadPackageData();
  }

  private loadPackageData(byPassSpinner?: boolean, intervalID?: any, polling?: number) {

    this.notYetSentRowData = [];
    this.sentRowData = [];
    pageNumberSize = 1;
    toltalLoadedRecipient = 0;
    this.getTrackingRecipients(pageNumberSize, intervalID, polling, byPassSpinner)
  }

  private getTrackingRecipients(pageNumber, intervalID, polling, byPassSpinner) {

    let packageId = '';
    if (this.selectedPackage) {
      packageId = this.selectedPackage.id;
    }

    this.subscriptionPackages = this.packageService.getPackageRecipients(packageId, this.selectedStatus,
      pageNumber, this.trackingPageSize, byPassSpinner).subscribe((packageRecipientPagedInfo: PackageRecipientPagedDto) => {
        let recipients;
        recipients = packageRecipientPagedInfo.items;
        if (!recipients) {
          return;
        }
        if (this.gridOptions.api) {
          this.gridOptions.api.hideOverlay();
        }
        const sent = recipients.filter(recipient => {
          return recipient.statusCode !== RecipientStatus.NotYetSent;
        });

        const notYetSent = recipients.filter(recipient => {
          return recipient.statusCode === RecipientStatus.NotYetSent;
        });


        const notYetSentItem = this.notYetSentRowData.concat(notYetSent);
        const sentItem = this.sentRowData.concat(sent);
        this.notYetSentRowData = notYetSentItem;
        this.sentRowData = sentItem;
        toltalLoadedRecipient = notYetSentItem.length + sentItem.length;

        if (!isNaN(intervalID)) {
          this.selectedRows.forEach(selectedRecipient => {
            this.sentSelectedRecipients = sentItem.filter(recipient => {
              return selectedRecipient.contactId === recipient.contactId;
            })
          })
          if (this.sentSelectedRecipients.length > 0 || polling > pollingCallsAllowed) {
            clearInterval(intervalID);
            this.showSpinner = false;

          }
        }

        if (isNaN(intervalID) && intervalID !== undefined) {
          this.showSpinner = false;
          clearInterval(intervalID);
        }

        if (toltalLoadedRecipient < packageRecipientPagedInfo.total) {
          pageNumberSize = pageNumberSize + 1
          byPassSpinner = true;
          this.getTrackingRecipients(pageNumberSize, intervalID, polling, byPassSpinner)
        }
      });

  }
  recipientStatus(params) {
    if (params.data.statusCode === RecipientStatus.NotYetSent) {
      return '-';
    } else if (params.data.statusCode === RecipientStatus.Failed) {
      return params.data.status;
    } else {
      return 'Sent';
    }
  }

  sendPackage() {
    let intervalID;
    let stopPolling = 0;
    if (!this.notYetSentGridApi || this.notYetSentGridApi.getSelectedRows().length === 0) {
      if (this.sentRowData.length === 0) {
        return;
      }
      this.loadPackageData(true, 'hideSpinner');
    } else {
      this.selectedRows = this.notYetSentGridApi.getSelectedRows();
      this.packageService.send(this.selectedPackage, this.selectedRows).subscribe(response => {
        this.notificationService.success(`Package has successfully
        been sent to ${this.selectedRows.length} recipient(s)`);
        this.showSpinner = true;

        intervalID = setInterval(() => {
          // polling will after stop polling is greater than 20 which is equal to a minute
          stopPolling = stopPolling + 1;
          this.loadPackageData(true, intervalID, stopPolling);
        }, 5000);
      }, error => {
        this.notificationService.error('Package cant be sent');
      });

    }
  }

  openRecipientsPopup(params) {
    if (!params.data.role) {
      this.notificationService.error(`Could not load ${params.data.firstName} ${params.data.lastName} details as Role is not available`);
      return;
    }

    contactOptions.title = 'Edit Contact';
    contactOptions.context = params.data;
    const modalResponse$ = this.ccModalService.open(contactOptions);
    modalResponse$.subscribe(response => {
      if (response.action !== 'cancel') {
        this.loadPackageData();
      }
      modalResponse$.complete();
    });
  }

  ngOnDestroy() {
    if (this.subscriptionPackages) {
      this.subscriptionPackages.unsubscribe();
    }
  }
}
