import { Component, OnInit } from '@angular/core';
import { TitleCasePipe } from '@angular/common';
import { Subject, Observable, of } from 'rxjs';
import { PackageDto } from '../../../common/models/dto/packageDto';
import { PackageService } from '../package.service';
import { tap, map, mergeMap } from 'rxjs/operators';
import { p } from '@angular/core/src/render3';

@Component({
  selector: 'app-preview-package',
  templateUrl: './preview.component.html',
  styleUrls: ['./preview.component.scss']
})
export class PreviewComponent implements OnInit {
  public notYetSentCount: number;
  public sendBtnTxt: string;
  response: Subject<any>;
  context: Observable<string>;
  packageForIB: PackageDto;

  constructor(private titleCasePipe: TitleCasePipe, private packageService: PackageService) {}


  ngOnInit(): void {
    this.context.pipe(
      map(packageForIB => JSON.parse(packageForIB)),
      tap(packageForIB => {
        this.packageForIB = packageForIB;
        // TODO: refactor the below logic to assign the button label
        this.sendBtnTxt = this.packageForIB.subject ? 'Send' : 'Apply & Send';
      }),
      mergeMap((previewPackage: PackageDto) => {
        if (previewPackage.autoSend && previewPackage.autoSend.length) {
          return this.packageService.getPackageAutoSendRecipientSummary(previewPackage.id, previewPackage.autoSend).pipe(
            map(s => s.indicationCount + s.allocationCount + s.syndicateCount)
          )
        } else {
          return of(this.packageForIB._summary.notYetSent)
        }
      },
    )).subscribe(notYetSent => {
      this.notYetSentCount = notYetSent
    });
  }

  cancelPopup(): void {
    this.response.next({ action: 'cancel' });
  }

  sendPackage(): void {
    this.response.next({ action: 'add' });
  }

}
