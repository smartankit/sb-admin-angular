import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { of, Subject, Observable } from 'rxjs';
import { TitleCasePipe } from '@angular/common';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { PreviewComponent } from './preview.component';
import { PackageService } from '../package.service';
import { ApiService, AppContext } from 'src/common';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { MapperService } from 'src/common/api/mapper.service';
import { NotificationService } from 'src/common/notification/notification.service';
import { CupcakeNotifyService, CupcakeGlobalsService, CupcakeDomService } from '@ipreo/cupcake-components';

describe('PreviewComponent', () => {
  let component: PreviewComponent;
  let fixture: ComponentFixture<PreviewComponent>;
  const mockPackage = {
    id: '1234',
    firmId: 1,
    dealId: '1',
    trancheId: '1',
    name: 'test package',
    emailTemplateId: '39e85ff0-6c36-6793-5c41-d87cd00bc7ac',
    emailBody: '<p>blah blah 2</p>',
    expirationDate: '2018-09-22T12:00:00',
    expirationTimezone: 'America/New_York',
    subject: '3rd Deal',
    consentLanguageId: '39e85ff1-1aea-e7f7-726e-7630c8315c3b',
    documents: [],
    autoSend: 'none',
    _summaryLoading: true,
    _summary: {
      sent: 5,
      failed: 2,
      notYetSent: 1,
      lastSentDate: '2018-09-22T12:00:00',
      pollingCallsMade: 0
    }
  };

  beforeAll(function () {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 999999;
  });

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PreviewComponent],
      schemas: [
        NO_ERRORS_SCHEMA,
        CUSTOM_ELEMENTS_SCHEMA
      ],
      providers: [
        TitleCasePipe,
        PackageService,
        ApiService,
        AppContext,
        MapperService,
        HttpClient,
        HttpHandler,
        NotificationService,
        CupcakeNotifyService,
        CupcakeGlobalsService,
        CupcakeDomService
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PreviewComponent);
    component = fixture.componentInstance;
    component.context = of(JSON.stringify(mockPackage));
    component['response'] = new Subject<any>();
  });

  it('Should cancel popup', () => {
    spyOn(component['response'], 'next');
    component.cancelPopup();
    expect(component['response'].next).toHaveBeenCalledWith({ action: 'cancel' });
  });

  it('Should send package', () => {
    spyOn(component['response'], 'next');
    component.sendPackage();
    expect(component['response'].next).toHaveBeenCalledWith({ action: 'add' });
  });

});
