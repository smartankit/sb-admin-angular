import { Component, OnInit, ViewChild, ElementRef, HostListener } from '@angular/core';
import { PackageService } from '../package.service';
import { DealDto, PackageDto, DocumentDto, AppContext, TrancheDto } from '../../../common';
import * as DateRangePicker from 'daterangepicker';
import { Subject } from 'rxjs/Subject';
import { ConsentLanguageDto } from '../../../common/models/dto/consentLanguageDto';
import { NotificationService } from '../../../common/notification/notification.service';
import { DatePipe } from '@angular/common';
import { Observable, BehaviorSubject } from 'rxjs';
import { AttachmentsComponent } from '../../documents/attachments/attachments.component';
import { HelperService } from '../../shared/helper.service';
import { DealType } from '../../../common/enum';

const savePackageErrorMessage = 'An error occurred while saving the package, please contact your administrator.';

@Component({
  selector: 'app-create-package',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.scss']
})
export class CreatePackageComponent implements OnInit {
  @ViewChild('expirationDateContainer', { read: ElementRef }) expirationDateEle: ElementRef;
  @ViewChild(AttachmentsComponent)
  private attachmentsComponent: AttachmentsComponent;

  response: Subject<any>; dealTracheTypes: TrancheDto[] = []; moreCount = 0; selectedDealTrancheTypes: TrancheDto[] = [];
  dealTrancheTypesObservable = new BehaviorSubject<TrancheDto[]>(null);
  private expirationDateFormat = 'DD.MMM.YYYY';
  public packageId: string;
  public deal: DealDto;
  // Context is being set from View packages component
  public context: Observable<string>;
  public show = false;
  public selectedDocuments: DocumentDto[] = [];
  public consentLanguages: ConsentLanguageDto[] = [];
  public package: PackageDto;
  public disclaimerBody = '';
  public expirationDate; // It will be in moment format
  public expirationTime = '12:00:00';
  public expirationTimeAmPm = 'AM';
  public isSaveButtonDisabled = false;
  public toggle;

  constructor(private packageService: PackageService,
    private notificationService: NotificationService,
    private appContext: AppContext,
    public datepipe: DatePipe,
    private helperService: HelperService) {
    this.packageService.getConsentLanguages();
    this.packageService.deal$.subscribe((deal) => {
      if (!deal) {
        deal = new DealDto();
      }
      this.deal = deal;
      this.initDealTrancheTypes();
    });
  }

  initDealTrancheTypes(): void {
    let i;
    this.dealTracheTypes = [];
    this.dealTracheTypes.push({ 'id': null, 'name': DealType.DealWide, 'sourceId': null, '_isDisabled': false });
    for (i = 0; i < this.deal.tranches.length; i++) {
      this.dealTracheTypes.push({
        'id': this.deal.tranches[i].id,
        'name': this.deal.tranches[i].name,
        'sourceId': this.deal.tranches[i].sourceId,
        '_isDisabled': false
      });
    }
    this.dealTrancheTypesObservable.next(this.dealTracheTypes);
  }

  public get dealTracheTypesObservableSource() {
    return this.dealTrancheTypesObservable.asObservable();
  }

  ngOnInit() {
    const that = this;
    let i, assignedTrancheIds;
    this.initializeDateRangePicker();
    that.adjustLabels();
    window.onresize = function (event) {
      that.adjustLabels();
    };

    this.context.subscribe(packageId => {
      if (!packageId) {
        return;
      }

      this.packageService.getPackageDetail(packageId);
    });

    this.packageService.package$.subscribe(packageDetail => {

      if (!packageDetail) {
        this.package = {
          firmId: this.appContext.firmId,
          dealId: this.appContext.dealId,
          tranches: []
        } as PackageDto;
      } else {
        this.package = packageDetail;
        assignedTrancheIds = this.package.tranches.map(tranche => tranche.id);
        this.selectedDealTrancheTypes = [];
        if (this.package.tranches.length === 0) {
          this.selectedDealTrancheTypes.push(this.dealTracheTypes[0]);
        } else {
          for (i = 0; i < this.dealTracheTypes.length; i++) {
            if (assignedTrancheIds.indexOf(this.dealTracheTypes[i].id) !== -1) {
              this.selectedDealTrancheTypes.push(this.dealTracheTypes[i]);
            }
          }
        }
        this.disableUnassignedDealTranches();
        this.package.emailBody = this.package.emailBody.replace(/\n\r?/g, '<br />')
        if (packageDetail.expirationDate) {
          const dateTime = packageDetail.expirationDate.split('T')[1];
          const dateTimeAmPm = this.helperService.convertTime24ToAmPM(dateTime.substr(0, 8));
          this.expirationTime = dateTimeAmPm.split(' ')[0];
          this.expirationTimeAmPm = dateTimeAmPm.split(' ')[1];
        }
      }

      /*
      this.packageService.getConsentLanguages().subscribe((items: ConsentLanguageDto[]) => {
        this.consentLanguages = items;

        if (!this.package.id || !this.package.consentLanguageId) {
          return;
        }

        const selectedConsentLanguage = items.find(item => item.id === this.package.consentLanguageId);

        if (selectedConsentLanguage) {
          this.disclaimerBody = selectedConsentLanguage.disclaimerBody;
        }
      });
      */
    });
  }

  disableUnassignedDealTranches() {
    let i, startIndex, disableListLength;
    if (this.selectedDealTrancheTypes.length > 0) {
      this.moreCount = (this.selectedDealTrancheTypes.length - 1);
      if (this.selectedDealTrancheTypes[0].name === DealType.DealWide) {
        disableListLength = this.dealTracheTypes.length;
        startIndex = 1;
      } else {
        disableListLength = 1;
        startIndex = 0;
      }
      for (i = startIndex; i < disableListLength; i++) {
        this.dealTracheTypes[i]._isDisabled = true;
      }
    }
  }

  selectDealTrancheTypes(packageTraches: TrancheDto[]): void {
    this.package.tranches = [];
    if ((packageTraches.length !== 0) && (packageTraches[0].name !== DealType.DealWide)) {
      this.package.tranches = this.package.tranches.concat(packageTraches);
    }
    this.moreCount = (packageTraches.length - 1);
    if (packageTraches.length === 0) {
      this.enableSuggesterListItems();
    } else {
      if (packageTraches[0].name === DealType.DealWide) {
        this.disableSuggesterListItems(DealType.DealWide);
      } else {
        this.disableSuggesterListItems(DealType.TrancheSpecific);
      }
    }
  }

  enableSuggesterListItems(): void {
    let i, dealTracheSuggester, lengthSuggesterList;
    dealTracheSuggester = document.getElementById('dealTracheSuggester');
    lengthSuggesterList = dealTracheSuggester.getElementsByClassName('c-suggester-item').length;
    for (i = 0; i < lengthSuggesterList; i++) {
      this.dealTracheTypes[i]._isDisabled = false;
    }
    this.dealTrancheTypesObservable.next(this.dealTracheTypes);
  }

  disableSuggesterListItems(type: string): void {
    let i, dealTracheSuggester, disableListLength, startIndex;
    dealTracheSuggester = document.getElementById('dealTracheSuggester');
    if (type === DealType.DealWide) {
      disableListLength = dealTracheSuggester.getElementsByClassName('c-suggester-item').length;
      startIndex = 1;
    } else {
      disableListLength = 1;
      startIndex = 0;
    }
    for (i = startIndex; i < disableListLength; i++) {
      this.dealTracheTypes[i]._isDisabled = true;
    }
    this.dealTrancheTypesObservable.next(this.dealTracheTypes);
  }

  adjustLabels() {
    let classLabel, width;
    width = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);

    classLabel = 'resizableLabel ' + (width < 1400 ? 'c-col-md-2' : 'c-col-md-1');

    for (let i = 0; i < document.getElementsByClassName('resizableLabel').length; i++) {
      document.getElementsByClassName('resizableLabel')[i].className = classLabel;
    }
  }

  public textEditorContentChanged(template) {

    this.package.emailTemplateId = template.id;
    this.package.emailBody = template.value;
  }

  private initializeDateRangePicker() {
    const settings = {
      singleDatePicker: true,
      showDropdowns: true,
      alwaysShowCalendars: true,
      minDate: new Date(),
      locale: {
        format: this.expirationDateFormat
      }
    } as DateRangePicker.Options;
    const dateRangePicker = new DateRangePicker(this.expirationDateEle.nativeElement, settings, this.dateRangePickerCallback.bind(this));
  }

  dateRangePickerCallback(from, to) {
    this.package.expirationDate = from.format('YYYY-MM-DDTHH:00:00');
    this.expirationDate = from;
  }

  showDatePicker() {
    this.expirationDateEle.nativeElement.setAttribute('style', 'display: block;');
  }

  onRemoveItem(id) {
    this.package.documents = this.package.documents.filter(item => item.id !== id);
    if (this.show) {
      this.selectedDocuments = this.package.documents;
      this.attachmentsComponent.ngOnInit();
    }
  }

  displayDocumentsGrid() {
    this.show = true;
    if (this.package.documents) {
      this.selectedDocuments = this.package.documents;
    }
  }

  getSelectedDocuments(documents: DocumentDto[]) {
    this.package.documents = documents;
  }

  private validateInput(): boolean {
    let isValid = false;

    if (!this.package.name) {
      this.notificationService.error('Package name is required.');
    } else if (!this.package.subject) {
      this.notificationService.error('Package subject is required.');
    } else if (!this.package.expirationDate) {
      this.notificationService.error('Package expiration date is required.');
    } else {
      isValid = true;
    }

    return isValid;
  }

  showSuggesterOptions(): void {
    let dealTracheSuggester;
    dealTracheSuggester = document.getElementById('dealTracheSuggester');
    dealTracheSuggester.getElementsByTagName('input')[0].focus();
  }

  save(): void {
    if (!this.validateInput()) {
      return;
    }
    this.isSaveButtonDisabled = true;
    let formattedDateWithOutTimeZone = null;

    if (this.package.expirationDate) {
      const formattedExpirationTime = `${this.expirationTime} ${this.expirationTimeAmPm}`;
      const convertExpirationDate = this.helperService.convertTime12to24(formattedExpirationTime);
      const formattedExpirationDate = this.package.expirationDate.split('T')[0];
      formattedDateWithOutTimeZone = `${formattedExpirationDate}T${convertExpirationDate}`;
    }

    this.package.name = this.package.name.trim();
    this.package.expirationDate = formattedDateWithOutTimeZone;
    let packageSaveFn;
    if (this.package.id) {
      packageSaveFn = this.packageService.update(this.package);
    } else {
      packageSaveFn = this.packageService.save(this.package);
    }

    packageSaveFn.subscribe(() => {
      this.notificationService.success('Package Saved Successfully.');
      this.response.next({ action: 'complete' });
    }, err => {
      this.notificationService.error(err.error.message);
      this.isSaveButtonDisabled = false;
    });
  }

  cancel(): void {
    this.response.next({ action: 'cancel' });
  }

  public onConsentLanguageChange(consentLanguageId): void {
    if (consentLanguageId) {
      const selectedConsentLanguage = this.consentLanguages.find(item => item.id === consentLanguageId);
      this.disclaimerBody = selectedConsentLanguage.disclaimerBody;
    } else {
      this.disclaimerBody = '';
    }
  }
}
