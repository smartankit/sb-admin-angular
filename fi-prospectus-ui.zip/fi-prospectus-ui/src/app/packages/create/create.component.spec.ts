import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';
import { AgGridModule } from 'ag-grid-angular';
import { PackageService } from '../package.service';
import { ProspectusCommonModule, DealDto, TrancheDto, PackageDto, DocumentDto, ConsentLanguageDto, AppContext } from '../../../common';
import { CreatePackageComponent } from './create.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CupcakeModalModule, CupcakeNotifyService, CupcakePopoverService } from '@ipreo/cupcake-components';
import { of } from 'rxjs';
import * as moment from 'moment';
import { NotificationService } from '../../../common/notification/notification.service';
import { DatePipe } from '@angular/common';
import { HelperService } from '../../shared/helper.service';
import { DealType } from '../../../common/enum';

describe('CreatePackageComponent  : ', () => {
  let component: CreatePackageComponent;
  let fixture: ComponentFixture<CreatePackageComponent>;
  let mockPackageService: PackageService;
  let modalResponse;
  const emptyFunction = function () { };
  const mockPackageId = '1';
  const mockFirmId = 11111;
  const mockDealId = '328830';
  const mockTrancheId = '354609';
  const mockDeal: DealDto = {
    id: mockDealId,
    name: 'sales-credits-ui-test-deal',
    size: 20000000,
    currency: 'USD',
    tranches: [
      {
        id: mockTrancheId,
        name: 'tranche 1',
        sourceId: '123',
        _isDisabled: true
      },
      {
        id: 354610,
        name: 'tranche 2',
        sourceId: '1234',
        _isDisabled: true
      }
    ] as TrancheDto[],
    issuerName: '1155 Island Avenue LLC',
    isPreferred: false
  };
  const mockPackage = {
    tranches: [],
    firmId: mockFirmId,
    dealId: mockDealId,
    trancheId: mockTrancheId,
    name: 'test package',
    emailTemplateId: '39e85ff0-6c36-6793-5c41-d87cd00bc7ac',
    emailBody: '<p>blah blah 2</p>',
    expirationDate: '2018-09-22T12:00:00',
    expirationTimezone: 'America/New_York',
    subject: '3rd Deal',
    consentLanguageId: '39e85ff1-1aea-e7f7-726e-7630c8315c3b'
  } as PackageDto;

  const updatemockPackage = {
    tranches: [],
    id: '39e8b6e9-17a5-a1ee-4a21-ca413f2444ac',
    sourceId: 1848178899,
    firmId: mockFirmId,
    dealId: mockDealId,
    trancheId: mockTrancheId,
    name: 'test package',
    emailTemplateId: '39e85ff0-6c36-6793-5c41-d87cd00bc7ac',
    emailBody: '<p>blah blah 2</p>',
    expirationDate: '2018-09-22T12:00:00',
    expirationTimezone: 'America/New_York',
    subject: '3rd Deal',
    consentLanguageId: '39e85ff1-1aea-e7f7-726e-7630c8315c3b'
  } as PackageDto;

  const mockDocuments = [{
    id: '1',
    name: 'doc1',
    fileSize: '234kb'
  },
  {
    id: '2',
    name: 'doc2',
    fileSize: '343kb'
  }] as DocumentDto[];

  const mockConsentLanguages = [{
    id: '39e85ff1-1aea-e7f7-726e-7630c8315c3b',
    name: 'standard',
    disclaimerBody: 'test'
  }] as ConsentLanguageDto[];

  beforeAll(function () {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 899999;
  });

  beforeEach(async(() => {
    modalResponse = of({
      action: 'save',
      context: mockDocuments
    });
    modalResponse['complete'] = jasmine.createSpy('complete');

    TestBed.configureTestingModule({
      imports: [
        HttpClientModule,
        CupcakeModalModule,
        AgGridModule.withComponents([]),
        ProspectusCommonModule.forRoot()
      ],
      declarations: [CreatePackageComponent],
      providers: [
        {
          provide: PackageService, useValue: {
            deal$: of(mockDeal),
            getPackageDetail: jasmine.createSpy('getPackageDetail'),
            save: jasmine.createSpy('save').and.returnValue({ subscribe: () => { } }),
            update: jasmine.createSpy('save').and.returnValue({ subscribe: () => { } }),
            package$: of(mockPackage),
            save$: of(mockPackage),
            update$: of(updatemockPackage),
            getConsentLanguages: jasmine.createSpy('getConsentLanguages').and.returnValue(of(mockConsentLanguages))
          }
        },
        {
          provide: AppContext, useValue: {
            firmId: mockFirmId,
            dealId: mockDealId,
            trancheId: mockTrancheId
          }
        },
        NotificationService,
        CupcakeNotifyService,
        CupcakePopoverService,
        DatePipe,
        HelperService],
      schemas: [
        NO_ERRORS_SCHEMA,
        CUSTOM_ELEMENTS_SCHEMA
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatePackageComponent);
    component = fixture.componentInstance;
    component.context = of(mockPackageId);
    fixture.detectChanges();

    mockPackageService = TestBed.get(PackageService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should save the package', () => {
    component['getSelectedEmailTemplateId'] = jasmine.createSpy().and.returnValue(mockPackage.emailTemplateId);
    component.expirationDate = moment(mockPackage.expirationDate);
    component.save();
    expect(mockPackageService.save).toHaveBeenCalledWith(mockPackage);
  });

  it('should update the package', () => {
    component['getSelectedEmailTemplateId'] = jasmine.createSpy().and.returnValue(updatemockPackage.emailTemplateId);
    component.expirationDate = moment(updatemockPackage.expirationDate);
    component.package.id = '39e8b6e9-17a5-a1ee-4a21-ca413f2444ac';
    component.package.sourceId = 1848178899;
    component.save();
    expect(mockPackageService.update).toHaveBeenCalledWith(updatemockPackage);
  });

  it('should get the deal info', () => {
    expect(component.deal).toEqual(mockDeal);
  });

  it('should get the values based on packageId', () => {
    expect(mockPackageService.getPackageDetail).toHaveBeenCalledWith(mockPackageId);
  });

  it('should set the emailBody when text editor is updated', () => {

    const emailTemplate = {
      id: '123',
      value: 'sample test'
    };
    component.textEditorContentChanged(emailTemplate);
    expect(component.package.emailBody).toEqual(emailTemplate.value);
  });

  it('should set the expiration date in specified format', () => {
    component.dateRangePickerCallback(moment(), moment());
    expect(component.package.expirationDate).toEqual(mockPackage.expirationDate);
  });

  it('should show date picker dropdown', () => {
    spyOn(component.expirationDateEle.nativeElement, 'setAttribute');
    component.showDatePicker();
    expect(component.expirationDateEle.nativeElement.setAttribute).toHaveBeenCalledWith('style', 'display: block;');
  });

  it('should display documents', () => {
    mockPackage.documents = mockDocuments;
    component.displayDocumentsGrid();
    expect(mockPackage.documents).toEqual(mockDocuments);
  });

  it('should set the documents', () => {
    component.getSelectedDocuments(mockDocuments);
    expect(mockPackage.documents).toEqual(mockDocuments);
  });

  it('should initialize deal tranche types', () => {
    let i;
    const dealTracheTypes: TrancheDto[] = [];
    dealTracheTypes.push({ 'id': null, 'name': DealType.DealWide, 'sourceId': null, '_isDisabled': false });
    for (i = 0; i < component.deal.tranches.length; i++) {
      dealTracheTypes.push({
        'id': component.deal.tranches[i].id, 'name': component.deal.tranches[i].name,
        'sourceId': component.deal.tranches[i].sourceId, '_isDisabled': true
      });
    }
    expect(component.dealTracheTypes).toEqual(dealTracheTypes);
  });

  it('should select deal tranche types', () => {
    let mockTranches, spyEnableSuggeter, spyDisableSuggeter;
    mockTranches = JSON.parse(JSON.stringify(mockDeal.tranches));
    spyEnableSuggeter = spyOn(component, 'enableSuggesterListItems').and.callFake(emptyFunction);
    spyDisableSuggeter = spyOn(component, 'disableSuggesterListItems').and.callFake(emptyFunction);
    component.selectDealTrancheTypes(mockTranches);
    expect(component.moreCount).toEqual(1);
    component.selectDealTrancheTypes(mockTranches);
    expect(component.package.tranches).toEqual(mockTranches);
    mockTranches[0].name = DealType.DealWide;
    component.selectDealTrancheTypes(mockTranches);
    expect(component.package.tranches).toEqual([]);
    mockTranches = [];
    component.selectDealTrancheTypes(mockTranches);
    expect(component.enableSuggesterListItems).toHaveBeenCalled();
    expect(component.enableSuggesterListItems).toHaveBeenCalled();
    mockTranches = JSON.parse(JSON.stringify(mockDeal.tranches));
    mockTranches.pop();
    mockTranches[0].name = DealType.DealWide;
    spyEnableSuggeter.calls.reset();
    spyDisableSuggeter.calls.reset();
    component.selectDealTrancheTypes(mockTranches);
    expect(component.disableSuggesterListItems).toHaveBeenCalledWith(DealType.DealWide);
    mockTranches[0].name = DealType.TrancheSpecific;
    spyEnableSuggeter.calls.reset();
    spyDisableSuggeter.calls.reset();
    component.selectDealTrancheTypes(mockTranches);
    expect(component.disableSuggesterListItems).toHaveBeenCalledWith(DealType.TrancheSpecific);
  });

  it('should enable suggester list items', () => {
    let i, dealTracheSuggester, lengthSuggesterList;
    dealTracheSuggester = document.createElement('div');
    dealTracheSuggester.setAttribute('id', 'dealTracheSuggester');
    dealTracheSuggester.innerHTML = '<li class="c-suggester-item item-disabled"><input type="checkbox"></li>' +
      '<li class="c-suggester-item item-disabled"><input type="checkbox"></li>';
    spyOn(document, 'getElementById').and.returnValue(dealTracheSuggester);
    lengthSuggesterList = dealTracheSuggester.getElementsByClassName('c-suggester-item').length;
    for (i = 0; i < lengthSuggesterList; i++) {
      component.dealTracheTypes[i]._isDisabled = true;
    }
    component.enableSuggesterListItems();
    for (i = 0; i < lengthSuggesterList; i++) {
      expect(component.dealTracheTypes[i]._isDisabled).toBe(false);
    }
  });

  it('should disable suggester list items', () => {
    let i, type, dealTracheSuggester, lengthSuggesterList;
    const resetInnerHTML = function () {
      dealTracheSuggester.innerHTML = '<li class="c-suggester-item"><input type="checkbox"></li>' +
        '<li class="c-suggester-item"><input type="checkbox"></li>' +
        '<li class="c-suggester-item"><input type="checkbox"></li>';
      lengthSuggesterList = dealTracheSuggester.getElementsByClassName('c-suggester-item').length;
    }
    dealTracheSuggester = document.createElement('div');
    dealTracheSuggester.setAttribute('id', 'dealTracheSuggester');
    resetInnerHTML();
    spyOn(document, 'getElementById').and.returnValue(dealTracheSuggester);
    type = DealType.DealWide;
    for (i = 0; i < lengthSuggesterList; i++) {
      component.dealTracheTypes[i]._isDisabled = false;
    }
    component.disableSuggesterListItems(type);
    for (i = 0; i < lengthSuggesterList; i++) {
      if (i === 0) {
        expect(component.dealTracheTypes[i]._isDisabled).toBe(false);
      } else {
        expect(component.dealTracheTypes[i]._isDisabled).toBe(true);
      }
    }
    type = DealType.TrancheSpecific;
    for (i = 0; i < lengthSuggesterList; i++) {
      component.dealTracheTypes[i]._isDisabled = false;
    }
    component.disableSuggesterListItems(type);
    for (i = 0; i < lengthSuggesterList; i++) {
      if (i === 0) {
        expect(component.dealTracheTypes[i]._isDisabled).toBe(true);
      } else {
        expect(component.dealTracheTypes[i]._isDisabled).toBe(false);
      }
    }
  });

});
