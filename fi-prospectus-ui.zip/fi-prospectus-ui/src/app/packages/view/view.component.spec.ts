import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { PackageService } from '../package.service';
import { PackagesViewComponent } from './view.component';
import { ProspectusCommonModule, PackageDto, TrancheDto, DealDto, PackageRecipientDto, FiAuthService, FiUser } from '../../../common';
import {
  CupcakeModalService, CupcakeModalOptions, CupcakeModalModule,
  CupcakeNotifyService, CupcakeDropdownsModule
} from '@ipreo/cupcake-components';
import { NotificationService } from '../../../common/notification/notification.service';
import { HelperService } from '../../shared/helper.service';
import { DatePipe } from '@angular/common';
import { RouterTestingModule } from '@angular/router/testing';
import { of, Observable, BehaviorSubject } from 'rxjs';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';

describe('PackagesViewComponent', () => {
  let component: PackagesViewComponent;
  let fixture: ComponentFixture<PackagesViewComponent>;
  let mockPackageService: PackageService;
  let notificationService: NotificationService;
  let mockCupcakeModalService: CupcakeModalService;

  const dealBehaviorSubject = new BehaviorSubject<DealDto>(null);
  const MESSAGE_PACKAGE_DISABLE_OK = '{{name}} disabled successfully';
  const MESSAGE_PACKAGE_ENABLE_OK = '{{name}} enabled successfully';
  const MESSAGE_PACKAGE_DISABLE_FAILED = '{{name}} could not be disabled';
  const MESSAGE_PACKAGE_ENABLE_FAILED = '{{name}} could not be enabled';
  const emptyArray = [];
  const mockIntervalID = 100;
  const mockFirmId = 11111;
  const mockDealId = '328830';
  const mockTrancheId = '354609';
  const mockPackageIndex = 1;
  const mockDeal = {
    id: mockDealId,
    name: 'sales-credits-ui-test-deal',
    size: 20000000,
    currency: 'USD',
    tranches: [
      {
        id: mockTrancheId,
        name: 'tranche 1'
      },
      {
        id: 354610,
        name: 'tranche 2'
      }
    ] as TrancheDto[],
    issuerName: '1155 Island Avenue LLC',
    isPreferred: false
  } as DealDto;
  const mockTranche = {
    id: mockTrancheId,
    name: '5 Yr Tranche',
    status: 'Live'
  };
  const mockPackages = [
    {
      id: '1234',
      firmId: mockFirmId,
      dealId: mockDealId,
      tranches: [],
      name: 'test package',
      emailTemplateId: '39e85ff0-6c36-6793-5c41-d87cd00bc7ac',
      emailBody: '<p>blah blah 2</p>',
      expirationDate: '2018-09-22T12:00:00',
      expirationTimezone: 'America/New_York',
      subject: '3rd Deal',
      consentLanguageId: '39e85ff1-1aea-e7f7-726e-7630c8315c3b',
      documents: [],
      _summaryLoading: true,
      _summary: {
        sent: 5,
        failed: 2,
        notYetSent: 1,
        pollingCallsMade: 0,
        lastSentDate: '2018-09-22T12:00:00'
      },
      _autoSendType: {
        syndicate: null,
        allocation: null,
        indication: null
      },
      rowVersion: 1
    },
    {
      id: '111111',
      firmId: mockFirmId,
      dealId: mockDealId,
      tranches: [],
      name: 'test package',
      emailTemplateId: '39e85ff0-6c36-6793-5c41-d87cd00bc7ac',
      emailBody: '<p>blah blah 2</p>',
      expirationDate: '2018-09-22T12:00:00',
      expirationTimezone: 'America/New_York',
      subject: '3rd Deal',
      consentLanguageId: '39e85ff1-1aea-e7f7-726e-7630c8315c3b',
      documents: [],
      _summaryLoading: true,
      _summary: {
        sent: 25,
        failed: 2,
        notYetSent: 1,
        lastSentDate: '2018-09-22T12:00:00'
      },
      rowVersion: 2
    }
  ] as PackageDto[];
  const mockSummary = {
    sent: 15,
    failed: 2,
    notYetSent: 0,
    lastSentDate: '2018-09-22T12:00:00'
  };

  const mockEvent = {
    target: {
      value: null
    }
  };

  const packageServiceStub = {
    get deal$(): Observable<any> {
      return dealBehaviorSubject.asObservable();
    },
    getPackagesByDeal: function () {
      return of(mockPackages);
    },
    refresh: function () {

    },
    getPackageRecipientsSummary: function () {
      return of(mockSummary);
    },
    send: function () {
      return of(emptyArray);
    },
    patchPackage: function () {
      return of(emptyArray);
    }
  };
  const cupcakeModalServiceStub = {
    open: function (options: CupcakeModalOptions) {
      return of({ action: 'Ok' });
    }
  };

  const mockFiUser = new FiUser('Test', 'Test', 'test@something.com', ['Syndicate']);

  const authServiceStub = {
    get user(): FiUser {
      return mockFiUser;
    },
    get authenticated$(): Observable<FiUser> {
      return of(mockFiUser);
    }
  };
  const helperServiceStub = {
    showAnyTooltip: function () {
    }
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        CupcakeModalModule,
        CupcakeDropdownsModule,
        RouterTestingModule,
        ProspectusCommonModule.forRoot()
      ],
      declarations: [PackagesViewComponent],
      providers: [
        {
          provide: PackageService, useValue: packageServiceStub
        },
        {
          provide: CupcakeModalService, useValue: cupcakeModalServiceStub
        },
        {
          provide: FiAuthService, useValue: authServiceStub
        },
        {
          provide: HelperService, useValue: helperServiceStub
        },
        NotificationService,
        CupcakeNotifyService,
        DatePipe
      ]
    })
      .compileComponents();
  }));

  beforeAll(function () {
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 899999;
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PackagesViewComponent);
    component = fixture.componentInstance;
    mockPackageService = TestBed.get(PackageService);
    mockCupcakeModalService = TestBed.get(CupcakeModalService);
    notificationService = TestBed.get(NotificationService);
    // jasmine.clock().uninstall();
    // jasmine.clock().install();
  });

  afterEach(() => {
    // jasmine.clock().uninstall();
  });

  it('Should initialize the component properly', () => {
    spyOn(component, 'subscribeDeal');
    spyOn(component, 'subscribeUser');
    spyOn(component, 'getPackagesByDeal');
    spyOn(window, 'addEventListener');
    component.ngOnInit();
    expect(component.subscribeDeal).toHaveBeenCalledWith();
    expect(component.subscribeUser).toHaveBeenCalledWith();
    expect(component.getPackagesByDeal).toHaveBeenCalled();
    expect(window.addEventListener).toHaveBeenCalledWith('scroll', jasmine.any(Function), true);
  });

  it('Should destory the component properly', () => {
    spyOn(window, 'removeEventListener');
    component.ngOnDestroy();
    expect(window.removeEventListener).toHaveBeenCalledWith('scroll', jasmine.any(Function), true);
  });

  it('Should subscribe to user', () => {
    component.subscribeUser();
    expect(component.user).toBe(mockFiUser);
  });

  it('Should subscribe to deal', () => {
    component.subscribeDeal();
    dealBehaviorSubject.next(mockDeal);
    expect(component.dealName).toBe(mockDeal.name);
  });

  // it('Should get packages by deal', () => {
  //   spyOn(mockPackageService, 'getPackagesByDeal').and.callThrough();
  //   spyOn(component, 'getPackageCards');
  //   component.getPackagesByDeal();
  //   expect(component.packages).toBe(mockPackages);
  //   expect(component.getPackageCards).toHaveBeenCalled();
  // });
  // it('Should get package cards', () => {
  //   spyOn(document, 'getElementsByClassName').and.returnValue([{ style: { height: 10 } }]);
  //   spyOn(component, 'triggerSummaryLoad');
  //   component.getPackageCards();
  //   jasmine.clock().tick(10);
  //   expect(component.packageCards.length).toBe(1);
  //   expect(component.triggerSummaryLoad).toHaveBeenCalled();
  // });
  it('Should trigger summary load', () => {
    spyOn(window, 'dispatchEvent');
    component.triggerSummaryLoad();
    expect(window.dispatchEvent).toHaveBeenCalled();
  });

  it('Should handle scroll event', () => {
    spyOn(component, 'checkCardsVisibility');
    component.handleScroll();
    expect(component.checkCardsVisibility).toHaveBeenCalled();
  });

  // it('Should check card visibility', () => {
  //   let spyRecipientSummary;
  //   spyRecipientSummary = spyOn(component, 'getPackageRecipientsSummary');
  //   spyOn(document, 'getElementsByClassName').and.returnValue([{ style: { height: 10 } }]);
  //   component.packages = mockPackages;
  //   component.getPackageCards();
  //   jasmine.clock().tick(10);
  //   spyOn(component, 'isHTMLElementVisible').and.returnValues(true, false, true, true);
  //   component.packages[0]._summaryLoading = false;
  //   component.packages[0]._summary.sent = null;
  //   component.checkCardsVisibility();
  //   expect(component.getPackageRecipientsSummary).toHaveBeenCalledWith(component.packages[0], false);
  //   spyRecipientSummary.calls.reset();
  //   component.packages[0]._summaryLoading = false;
  //   component.packages[0]._summary.sent = null;
  //   component.checkCardsVisibility();
  //   expect(component.getPackageRecipientsSummary).not.toHaveBeenCalled();
  //   spyRecipientSummary.calls.reset();
  //   component.packages[0]._summaryLoading = true;
  //   component.packages[0]._summary.sent = null;
  //   component.checkCardsVisibility();
  //   expect(component.getPackageRecipientsSummary).not.toHaveBeenCalled();
  //   spyRecipientSummary.calls.reset();
  //   component.packages[0]._summaryLoading = false;
  //   component.packages[0]._summary.sent = 5;
  //   component.checkCardsVisibility();
  //   expect(component.getPackageRecipientsSummary).not.toHaveBeenCalled();
  // });
  // it('Should get package recipient summary (polling)', () => {
  //   let packageForIB, spySummary;
  //   packageForIB = JSON.parse(JSON.stringify(mockPackages[0]));
  //   spySummary = spyOn(mockPackageService, 'getPackageRecipientsSummary').and.callThrough();
  //   packageForIB._summaryLoading = false;
  //   mockSummary.notYetSent = 10;
  //   component.getPackageRecipientsSummary(packageForIB, true);
  //   expect(packageForIB._summaryLoading).toBe(true);
  //   expect(mockPackageService.getPackageRecipientsSummary).toHaveBeenCalledWith(packageForIB.id, true);
  //   expect(packageForIB._summary).toBe(mockSummary);
  //   expect(packageForIB._summary.lastSentDate).toBe('22.SEP.2018,  12:00 PM');
  //   spySummary.calls.reset();
  // });
  // it('Should get package recipient summary (polling)', () => {
  //   let packageForIB2;
  //   packageForIB2 = JSON.parse(JSON.stringify(mockPackages[1]));
  //   spyOn(mockPackageService, 'getPackageRecipientsSummary').and.callThrough();
  //   spyOn(window, 'clearInterval').and.callFake(function() {});
  //   packageForIB2._summaryLoading = false;
  //   mockSummary.notYetSent = 0;
  //   component.getPackageRecipientsSummary( packageForIB2, true, 1234);
  //   expect(packageForIB2._summaryLoading).toBeUndefined();
  //   expect(mockPackageService.getPackageRecipientsSummary).toHaveBeenCalledWith(packageForIB2.id, true);
  //   expect(packageForIB2._summary).toBe(mockSummary);
  //   expect(packageForIB2._summary.lastSentDate).toBe('22.SEP.2018,  12:00 PM');
  // });
  it('Should disable a package success', () => {
    let isDisabled: boolean, messageTmpl, message;
    spyOn(mockPackageService, 'patchPackage').and.callThrough();
    spyOn(notificationService, 'success');
    isDisabled = true;
    messageTmpl = isDisabled ? MESSAGE_PACKAGE_DISABLE_OK : MESSAGE_PACKAGE_ENABLE_OK
    message = messageTmpl.replace('{{name}}', mockPackages[0].name);
    component.disablePackage(mockPackages[0], isDisabled);
    expect(mockPackages[0].isDisabled).toBe(isDisabled);
    expect(mockPackageService.patchPackage).toHaveBeenCalledWith(mockPackages[0].id, '/isDisabled', isDisabled);
    expect(notificationService.success).toHaveBeenCalledWith(message);
    isDisabled = false;
    messageTmpl = isDisabled ? MESSAGE_PACKAGE_DISABLE_OK : MESSAGE_PACKAGE_ENABLE_OK
    message = messageTmpl.replace('{{name}}', mockPackages[0].name);
    component.disablePackage(mockPackages[0], isDisabled);
    expect(mockPackages[0].isDisabled).toBe(isDisabled);
    expect(mockPackageService.patchPackage).toHaveBeenCalledWith(mockPackages[0].id, '/isDisabled', isDisabled);
    expect(notificationService.success).toHaveBeenCalledWith(message);
  });

  it('Should handle disable package error', () => {
    let isDisabled: boolean, messageTmpl, message;
    spyOn(mockPackageService, 'patchPackage').and.returnValue(ErrorObservable.create({ message: 'some-error' }));
    spyOn(notificationService, 'error');
    isDisabled = true;
    messageTmpl = isDisabled ? MESSAGE_PACKAGE_DISABLE_FAILED : MESSAGE_PACKAGE_ENABLE_FAILED;
    message = messageTmpl.replace('{{name}}', mockPackages[0].name);
    component.disablePackage(mockPackages[0], isDisabled);
    expect(mockPackages[0].isDisabled).toBe(!isDisabled);
    expect(mockPackageService.patchPackage).toHaveBeenCalledWith(mockPackages[0].id, '/isDisabled', isDisabled);
    expect(notificationService.error).toHaveBeenCalledWith(message);
    isDisabled = false;
    messageTmpl = isDisabled ? MESSAGE_PACKAGE_DISABLE_FAILED : MESSAGE_PACKAGE_ENABLE_FAILED;
    message = messageTmpl.replace('{{name}}', mockPackages[0].name);
    component.disablePackage(mockPackages[0], isDisabled);
    expect(mockPackages[0].isDisabled).toBe(!isDisabled);
    expect(mockPackageService.patchPackage).toHaveBeenCalledWith(mockPackages[0].id, '/isDisabled', isDisabled);
    expect(notificationService.error).toHaveBeenCalledWith(message);
  });

  it('Should disable the Indicatios', () => {
    component.changeEvent(false, true, true, mockPackages[0]);
    expect(mockPackages[0]._autoSendType.allocation).toEqual(true);
    expect(mockPackages[0]._autoSendType.indication).toEqual(false);
    expect(mockPackages[0]._autoSendType.syndicate).toEqual(true);
  });

  it('Should disable the Allocations', () => {
    component.changeEvent(true, false, true, mockPackages[0]);
    expect(mockPackages[0]._autoSendType.allocation).toEqual(false);
    expect(mockPackages[0]._autoSendType.indication).toEqual(true);
    expect(mockPackages[0]._autoSendType.syndicate).toEqual(true);
  });

  // it('Should handle send package success', () => {
  //   let packageForIB;
  //   packageForIB = mockPackages[0];
  //   spyOn(component, 'getPackageRecipientsSummary');
  //   spyOn(mockPackageService, 'send').and.callThrough();
  //   spyOn(notificationService, 'success');
  //   component.sendPackage(packageForIB);
  //   jasmine.clock().tick(5000);
  //   expect(packageForIB.beingSent).toBe(false);
  //   expect(packageForIB._summaryLoading).toBe(true);
  //   expect(component.getPackageRecipientsSummary).toHaveBeenCalled();
  //   expect(notificationService.success).toHaveBeenCalledWith('Package ' + packageForIB.name + ' has been sent');
  // });
  // it('Should handle send package failure', () => {
  //   let packageForIB;
  //   packageForIB = mockPackages[0];
  //   spyOn(component, 'getPackageRecipientsSummary');
  //   spyOn(mockPackageService, 'send').and.returnValue(ErrorObservable.create({ message: 'some-error' }));
  //   spyOn(notificationService, 'error');
  //   component.sendPackage(packageForIB);
  //   expect(packageForIB.beingSent).toBe(false);
  //   expect(packageForIB._summaryLoading).toBe(true);
  //   expect(component.getPackageRecipientsSummary).not.toHaveBeenCalled();
  //   expect(notificationService.error).toHaveBeenCalledWith('Package ' + packageForIB.name + ' sending failed');
  // });
  // it('Should show add recipients modal', () => {
  //   let packageForIB, addRecipientOptions: CupcakeModalOptions;
  //   component.subscribeDeal();
  //   dealBehaviorSubject.next(mockDeal);
  //   packageForIB = mockPackages[0];
  //   addRecipientOptions = {
  //     mode: 'component',
  //     title: `${component.deal.name} - Add Recipients`,
  //     type: 'default',
  //     view: RecipientsComponent,
  //     contentWidth: '92%',
  //     contentHeight: 440,
  //     context: packageForIB.id
  //   };
  //   spyOn(mockCupcakeModalService, 'open').and.callThrough();
  //   spyOn(component, 'getPackageRecipientsSummary');
  //   component.addRecipients(packageForIB);
  //   expect(mockCupcakeModalService.open).toHaveBeenCalledWith(addRecipientOptions);
  //   expect(component.getPackageRecipientsSummary).toHaveBeenCalledWith(packageForIB, false);
  // });
  // it('Should show create package modal', () => {
  //   let packageForIB, createPackagetOptions: CupcakeModalOptions;
  //   component.subscribeDeal();
  //   dealBehaviorSubject.next(mockDeal);
  //   packageForIB = mockPackages[0];
  //   createPackagetOptions = {
  //     mode: 'component',
  //     title: 'Create Package for ' + component.deal.name,
  //     type: 'default',
  //     view: CreatePackageComponent,
  //     contentWidth: '70%',
  //     rootCssClass: 'packageview',
  //     context: packageForIB.id
  //   };
  //   spyOn(mockCupcakeModalService, 'open').and.callThrough();
  //   spyOn(mockPackageService, 'getPackagesByDeal');
  //   component.showCreatePackageModalPopup(packageForIB.id);
  //   expect(mockCupcakeModalService.open).toHaveBeenCalledWith(createPackagetOptions);
  //   expect(mockPackageService.getPackagesByDeal).toHaveBeenCalled();
  // });
});
