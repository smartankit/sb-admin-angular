import { Component, OnInit, OnDestroy, ViewChildren, QueryList } from '@angular/core';
import { DatePipe } from '@angular/common';
import { GridApi, ColumnApi, GridOptions, ColDef } from 'ag-grid';
import { PackageDto } from '../../../common/models/dto/packageDto';
import { PackageService } from '../package.service';
import { FiUser, FiAuthService } from '../../../common';
import { CreatePackageComponent } from '../create/create.component';
import { CupcakeModalOptions, CupcakeModalService, CupcakeDropdownTriggerDirective } from '@ipreo/cupcake-components';
import { PreviewComponent } from '../preview/preview.component';
import { RecipientsComponent } from '../recipients/recipients.component';
import { BehaviorSubject } from '../../../../node_modules/rxjs';
import { NotificationService } from '../../../common/notification/notification.service';
import { HelperService } from '../../shared/helper.service';
import { DealType, AutoSendType, RecipientStatus } from '../../../common/enum';

const MESSAGE_PACKAGE_DISABLE_OK = '{{name}} disabled successfully'
const MESSAGE_PACKAGE_ENABLE_OK = '{{name}} enabled successfully'
const MESSAGE_PACKAGE_DISABLE_FAILED = '{{name}} could not be disabled'
const MESSAGE_PACKAGE_ENABLE_FAILED = '{{name}} could not be enabled'
const totalAllowedTime = (15 * 1000);
const intervalForSummaryCall = 3000;
const pollingCallsAllowed = (totalAllowedTime / intervalForSummaryCall);

@Component({
  selector: 'app-packages-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.scss']
})

export class PackagesViewComponent implements OnInit, OnDestroy {
  @ViewChildren('manualDropdown', { read: CupcakeDropdownTriggerDirective })
  manualDropdown: QueryList<CupcakeDropdownTriggerDirective>;
  packageCards: any = []; toggle = {};
  public gridApi: GridApi;
  public gridColumnApi: ColumnApi;
  public gridOptions = <GridOptions>{};
  public columnDefs: ColDef[];
  public packages: PackageDto[] = [];
  public overlayNoRowsTemplate;
  public dealName = '';
  public package: PackageDto;
  public user: FiUser;
  public focussedPackageIndex = -1;
  RecipientStatusType: typeof RecipientStatus = RecipientStatus;

  constructor(
    private packageService: PackageService,
    private ccModalService: CupcakeModalService,
    public datePipe: DatePipe,
    private notificationService: NotificationService,
    private authService: FiAuthService,
    private helperService: HelperService,
  ) {
  }

  ngOnInit(): void {
    this.subscribeUser();
    this.subscribeDeal();
    this.getPackagesByDeal();
    window.addEventListener('scroll', this.handleScroll, true);
    window.addEventListener('resize', this.triggerSummaryLoad, true);
  }

  subscribeUser(): void {
    this.authService.authenticated$.subscribe(user => {
      this.user = user
    })
  }

  ngOnDestroy(): void {
    window.removeEventListener('scroll', this.handleScroll, true);
  }

  subscribeDeal(): void {
    this.packageService.deal$.subscribe(deal => {
      if (!deal) {
        return;
      }

      this.dealName = deal.name;
    });
  }

  setFocussedPackage(i: number) {
    this.focussedPackageIndex = i;
  }

  getPackagesByDeal(): void {
    let i, j;
    this.packageService.getPackagesByDeal().subscribe((packages) => {
      this.packages = packages;
      for (i = 0; i < this.packages.length; i++) {
        if (this.packages[i].tranches.length > 0) {
          this.packages[i]._dealTrancheInfo = '';
          for (j = 0; j < this.packages[i].tranches.length; j++) {
            this.packages[i]._dealTrancheInfo += this.packages[i].tranches[j].name + ', ';
          }
          this.packages[i]._dealTrancheInfo = this.packages[i]._dealTrancheInfo.substr(0, this.packages[i]._dealTrancheInfo.length - 2);
        } else {
          this.packages[i]._dealTrancheInfo = DealType.DealWide;
        }
      }
      this.getPackageCards();
    });
  }

  getPackageCards(): void {
    let spinnerCurtain;
    setTimeout(() => {
      this.packageCards = document.getElementsByClassName('packageCard');
      spinnerCurtain = <HTMLElement>document.getElementsByClassName('spinner-curtain')[0];
      spinnerCurtain.style.height = (document.body.scrollHeight + 100) + 'px';
      this.triggerSummaryLoad();
    }, 10);
  }

  triggerSummaryLoad(): void {
    let event;
    event = document.createEvent('Event');
    event.initEvent('scroll', true, true);
    window.dispatchEvent(event);
  }

  handleScroll = (): void => {
    this.checkCardsVisibility();
  }

  checkCardsVisibility(): void {
    let dealTrancheInfo;
    for (let i = 0; i < this.packageCards.length; i++) {
      if ((this.isHTMLElementVisible(this.packageCards[i])) && (!this.packages[i]._summaryLoading)
        && (this.packages[i]._summary.sent === null)) {
        dealTrancheInfo = this.packageCards[i].getElementsByClassName('dealTrancheInfo')[0];
        this.helperService.showAnyTooltip(dealTrancheInfo, 'top', 'defaultPopover', this.packages[i]._dealTrancheInfo, 'hover');
        this.getPackageRecipientsSummary(this.packages[i], false);
      }
    }
  }

  isHTMLElementVisible(element: HTMLElement): boolean {
    let rect, viewHeight;
    rect = element.getBoundingClientRect();
    viewHeight = Math.max(document.documentElement.clientHeight, window.innerHeight);
    return !(rect.bottom < 0 || rect.top - viewHeight >= 0);
  }

  getPackageRecipientsSummary(packageForIB: PackageDto, isPolling: boolean): void {
    let pollingCallsMade;
    packageForIB._summaryLoading = true;
    this.packageService.getPackageRecipientsSummary(packageForIB.id, true).subscribe((summary) => {
      if (summary.lastSentDate) {
        summary.lastSentDate = this.datePipe.transform(summary.lastSentDate, 'dd.MMM.yyyy,  h:mm a');
      }
      pollingCallsMade = packageForIB._summary.pollingCallsMade;
      packageForIB._summary = summary;
      packageForIB._summary.pollingCallsMade = pollingCallsMade;
      if (isPolling) {
        if (packageForIB._summary.notYetSent === 0) {
          delete packageForIB._summaryLoading;
        } else {
          if (packageForIB._summary.pollingCallsMade < pollingCallsAllowed) {
            setTimeout(() => {
              packageForIB._summary.pollingCallsMade++;
              this.getPackageRecipientsSummary(packageForIB, true);
            }, intervalForSummaryCall);
          } else {
            delete packageForIB._summaryLoading;
          }
        }
      } else {
        delete packageForIB._summaryLoading;
      }
    });
  }

  createPackage(): void {
    this.showCreatePackageModalPopup();
  }

  editPackage(packageId: string): void {
    this.showCreatePackageModalPopup(packageId);
  }

  disablePackage(packageForIB: PackageDto, isDisabled: boolean): void {
    packageForIB.isDisabled = isDisabled;
    this.packageService.patchPackage(packageForIB.id, '/isDisabled', isDisabled).subscribe(dto => {
      const messageTmpl = isDisabled ? MESSAGE_PACKAGE_DISABLE_OK : MESSAGE_PACKAGE_ENABLE_OK
      const message = messageTmpl.replace('{{name}}', packageForIB.name);
      this.notificationService.success(message);
    }, err => {
      packageForIB.isDisabled = !isDisabled
      const messageTmpl = isDisabled ? MESSAGE_PACKAGE_DISABLE_FAILED : MESSAGE_PACKAGE_ENABLE_FAILED;
      const message = messageTmpl.replace('{{name}}', packageForIB.name);
      this.notificationService.error(message);
    })
  }

  previewPackage(packageForIB: PackageDto, applyButton: boolean, syndicate: boolean,
    allocation: boolean, indication: boolean, packageIndex: number): void {
    this.autoSendDropdown(packageIndex, true);
    const context: any = {};
    context.clientName = packageForIB.clientName;
    context.expirationDate = packageForIB.expirationDate;
    context._summary = packageForIB._summary;
    context.autoSend = this.prepareAutoSendArray(syndicate, allocation, indication);
    context.emailBody = packageForIB.emailBody;
    context.id = packageForIB.id

    const options: CupcakeModalOptions = {
      mode: 'component',
      title: `${this.dealName}` + ' - ' + packageForIB.name,
      type: 'default',
      view: PreviewComponent,
      contentWidth: '52%',
      contentHeight: 640,
      context: applyButton ? JSON.stringify(context) : JSON.stringify(packageForIB)
    };
    const modalResponse$ = this.ccModalService.open(options);
    modalResponse$.subscribe(response => {
      if (response.action !== 'cancel') {
        if (applyButton) {
          packageForIB.autoSend = context.autoSend;

          this.packageService.autoSend(packageForIB.id, packageForIB.autoSend).subscribe(() => {
            modalResponse$.complete();

            // refresh package summary
            this.getPackageRecipientsSummary(packageForIB, true);

            // update auto send (dropdown)
            packageForIB.autoSend.length === 0 ? this.notificationService.error('AutoSend removed from ' + packageForIB.name)
              : this.notificationService.success('AutoSend saved on ' + packageForIB.name);

          }, err => {
            this.notificationService.error(err.error.message);
          });
        } else {
          this.sendPackage(packageForIB);
          modalResponse$.complete();
        }
      } else {
        packageForIB._autoSendType.syndicate = false;
        packageForIB._autoSendType.allocation = false;
        packageForIB._autoSendType.indication = false;
        modalResponse$.complete();
      }
    });
  }

  sendPackage(packageForIB: PackageDto): void {
    packageForIB.beingSent = true;
    packageForIB._summary.pollingCallsMade = 0;
    this.packageService.send(packageForIB, [], true).subscribe(() => {
      packageForIB.beingSent = false;
      packageForIB._summaryLoading = true;
      setTimeout(() => {
        packageForIB._summary.pollingCallsMade++;
        this.getPackageRecipientsSummary(packageForIB, true);
      }, intervalForSummaryCall);
      this.notificationService.success('Package ' + packageForIB.name + ' has been sent');
    }, (err) => {
      packageForIB.beingSent = false;
      this.notificationService.error('Package ' + packageForIB.name + ' sending failed');
    });
  }

  addRecipients(packageForIB: any): void {
    const context: any = {};
    context.id = packageForIB.id;
    context.packageName = packageForIB.name;
    context.dealName = this.dealName;
    const options: CupcakeModalOptions = {
      mode: 'component',
      title: 'Add Recipients',
      type: 'default',
      view: RecipientsComponent,
      contentWidth: '92%',
      contentHeight: 800,
      context: context
    };
    const modalResponse$ = this.ccModalService.open(options);
    modalResponse$.subscribe(response => {
      if (response.action !== 'cancel') {
        this.getPackageRecipientsSummary(packageForIB, false);
        this.notificationService.success(response.succesMessage);
      }
      modalResponse$.complete();
    });
  }

  showCreatePackageModalPopup(packageId?: string): void {
    this.packageService['package'] = new BehaviorSubject<PackageDto>(null);
    const options: CupcakeModalOptions = {
      mode: 'component',
      title: 'Create Package for ' + this.dealName,
      type: 'default',
      view: CreatePackageComponent,
      contentWidth: '70%',
      rootCssClass: 'packageview',
      context: packageId
    };
    const modalResponse$ = this.ccModalService.open(options);
    modalResponse$.subscribe(response => {
      if (response.action !== 'cancel') {
        this.getPackagesByDeal();
      }
      modalResponse$.complete();
    });
  }

  triggerDropdown(packageForIB: PackageDto, packageIndex: number) {
    const autoSend = packageForIB.autoSend;
    packageForIB._autoSendType.syndicate = false;
    packageForIB._autoSendType.allocation = false;
    packageForIB._autoSendType.indication = false;
    if (autoSend.length > 0) {
      autoSend.forEach(autoSentTo => {
        if (autoSentTo === AutoSendType.Syndicates) {
          packageForIB._autoSendType.syndicate = true;
        }

        if (autoSentTo === AutoSendType.Indications) {
          packageForIB._autoSendType.indication = true;
        }

        if (autoSentTo === AutoSendType.Allocations) {
          packageForIB._autoSendType.allocation = true;
        }
      });
    }
    this.autoSendDropdown(packageIndex, true);
  }

  changeEvent(chkIndication: boolean, chkAllocation: boolean, chkSyndicate: boolean, packageForIB: PackageDto) {
    packageForIB._autoSendType.syndicate = chkSyndicate ? true : false;
    packageForIB._autoSendType.allocation = chkAllocation ? true : false;
    packageForIB._autoSendType.indication = chkIndication ? true : false;
  }

  autoSendDropdownCollapse(packageIndex: number) {
    this.autoSendDropdown(packageIndex, false);
  }

  private autoSendDropdown(packageIndex: number, collapse: boolean) {
    const autoSendDropdown = this.manualDropdown['_results'][0];
    (!autoSendDropdown.isExpanded() && collapse) ? autoSendDropdown.expand() : autoSendDropdown.collapse();
  }

  prepareAutoSendArray(syndicate: boolean, allocation: boolean, indication: boolean) {
    const autoSend: string[] = new Array();
    if (syndicate) {
      autoSend.push(AutoSendType.Syndicates);
    }

    if (allocation) {
      autoSend.push(AutoSendType.Allocations);
    }

    if (indication) {
      autoSend.push(AutoSendType.Indications);
    }
    return autoSend;
  }
}
