import { TestBed } from '@angular/core/testing';
import { DealDto, TrancheDto, PackageDto, AddDeleteRecipientInfoDto, ApiService, AppContext } from '../../common';
import { of } from 'rxjs';
import { PackageService } from './package.service';
import { PatchPackageDto } from 'src/common/models/dto/patchPackageDto';
import { RecipientStatus } from 'src/common/enum';
import { NotificationService } from 'src/common/notification/notification.service';

describe('Service: Package Service', () => {

  let packageService: PackageService;
  let mockApiService: ApiService;
  const selectedStatus: string[] = [RecipientStatus.Sent, RecipientStatus.Failed, RecipientStatus.NotYetSent]
  const mockStatus = 'sent,failed,notYetSent';
  const appContextStub = {
    apiUrl: 'propectus-api.com',
    dealId: '1',
    trancheId: '2',
    dealSourceId: '11',
    trancheSourceId: '22'
  };
  const notificationServiceStub = {
    error: (msg) => { }
  };
  const mockDeal: DealDto = {
    id: '1',
    name: 'sales-credits-ui-test-deal',
    size: 20000000,
    currency: 'USD',
    tranches: [
      {
        id: '2',
        name: 'tranche 1'
      },
      {
        id: '354610',
        name: 'tranche 2'
      }
    ] as TrancheDto[],
    issuerName: '1155 Island Avenue LLC',
    isPreferred: false
  };
  const mockPackages = [
    {
      id: '1234',
      firmId: 1,
      dealId: '1',
      name: 'test package',
      emailTemplateId: '39e85ff0-6c36-6793-5c41-d87cd00bc7ac',
      emailBody: '<p>blah blah 2</p>',
      expirationDate: '2018-09-22T12:00:00',
      expirationTimezone: 'America/New_York',
      subject: '3rd Deal',
      consentLanguageId: '39e85ff1-1aea-e7f7-726e-7630c8315c3b',
      documents: [],
      _summaryLoading: true,
      rowVersion: 1
    }
  ] as PackageDto[];
  const mockRecipients: any[] = [
    {
      'isDealWide': false,
      'isProspectusContact': false,
      'location': null,
      'prospectusTrackingId': 1850824175,
      'contactId': 'e1dc0bca-baf4-4812-9c0c-185bd1a034a1',
      'company': 'investor3',
      'role': 'Investor',
      'firstName': 'Murali',
      'lastName': 'Manchikatla',
      'email': 'murali.manchikatla@ipreo.com',
      'sentDate': '2018-09-20T13:33:01.163Z',
      'statusCode': 'sent',
      'status': null,
      'rowVersion': 1
    }
  ];
  const mockAddDeleteRecipientInfo: AddDeleteRecipientInfoDto = {
    'deSelectAll': false,
    'added': mockRecipients,
    'deleted': mockRecipients
  };

  const mockPatchPackage = [
    {
      'op': 'replace',
      'path': '/autoSend',
      'value': 'none'
    }
  ] as PatchPackageDto[];
  const apiServiceStub = {
    getPackagesByDeal: function () {
      return of(mockPackages);
    },
    savePackage: function () {
      return of([]);
    },
    getDeal: function () {
      return of(mockDeal);
    },
    addRecipientsToPackage: function () {
      return of([]);
    },
    getEmployerRoles: function () {
      return of([]);
    },
    getConsentLanguages: function () {
      return of([]);
    },
    sendPackage: function () {
      return of([]);
    },
    getPackageRecipients: function () {
      return of([]);
    },
    getPackageRecipientsSummary: function () {
      return of([]);
    },
    getPackageById: function () {
      return of(mockPackages[0]);
    },
    updatePackage: function () {
      return of(mockPackages[0]);
    },
    patchPackage: function () {
      return of([]);
    }
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        PackageService,
        {
          provide: ApiService, useValue: apiServiceStub
        },
        {
          provide: AppContext, useValue: appContextStub
        },
        {
          provide: NotificationService, useValue: notificationServiceStub
        }
      ]
    });
    packageService = TestBed.get(PackageService);
    mockApiService = TestBed.get(ApiService);
  });

  it('should subscribe to deal', () => {
    packageService.deal$.subscribe((deal) => {
      if (deal) {
        expect(deal).toBe(mockDeal);
      }
    });
    packageService['deal'].next(mockDeal);
  });

  it('should subscribe to package', () => {
    packageService.package$.subscribe((packageForIB) => {
      if (packageForIB) {
        expect(packageForIB).toBe(mockPackages[0]);
      }
    });
    packageService['package'].next(mockPackages[0]);
  });

  it('Should refresh deal', () => {
    spyOn(mockApiService, 'getDeal').and.callThrough();
    packageService.deal$.subscribe((deal) => {
      if (deal) {
        expect(deal).toBe(mockDeal);
      }
    });
    packageService.refresh();
    expect(mockApiService.getDeal).toHaveBeenCalled();
  });

  it('Should get packages by deal', () => {
    spyOn(mockApiService, 'getPackagesByDeal').and.callThrough();
    packageService.getPackagesByDeal();
    packageService.getPackagesByDeal().subscribe((mockPackagesResponse) => {
      expect(mockPackagesResponse).toEqual(mockPackages);
    });
    expect(mockApiService.getPackagesByDeal).toHaveBeenCalled();
  });

  it('Should get package detail', () => {
    spyOn(mockApiService, 'getPackageById').and.callThrough();
    packageService.package$.subscribe((packageForIB) => {
      if (packageForIB) {
        expect(packageForIB).toBe(mockPackages[0]);
      }
    });
    packageService.getPackageDetail(mockPackages[0].id);
    expect(mockApiService.getPackageById).toHaveBeenCalledWith(mockPackages[0].id);
  });

  it('Should save package', () => {
    spyOn(mockApiService, 'savePackage');
    packageService.save(mockPackages[0]);
    expect(mockApiService.savePackage).toHaveBeenCalledWith(mockPackages[0]);
  });

  it('Should update package', () => {
    spyOn(mockApiService, 'updatePackage');
    packageService.update(mockPackages[0]);
    expect(mockApiService.updatePackage).toHaveBeenCalledWith(mockPackages[0]);
  });

  it('Should add recipients to  package', () => {
    spyOn(mockApiService, 'addRecipientsToPackage');
    packageService.addRecipientsToPackage('1', mockAddDeleteRecipientInfo);
    expect(mockApiService.addRecipientsToPackage).toHaveBeenCalledWith('1', mockAddDeleteRecipientInfo);
  });

  it('Should get employer roles', () => {
    spyOn(mockApiService, 'getEmployerRoles');
    packageService.getEmployerRoles();
    expect(mockApiService.getEmployerRoles).toHaveBeenCalled();
  });

  it('Should get consent languages', () => {
    spyOn(mockApiService, 'getConsentLanguages');
    packageService.getConsentLanguages();
    expect(mockApiService.getConsentLanguages).toHaveBeenCalledWith();
  });

  it('Should save autoSend details for the package', () => {
    spyOn(mockApiService, 'getPackageById').and.callThrough();
    spyOn(mockApiService, 'patchPackage');
    packageService.patchPackage(mockPackages[0].id, '/autoSend', 'none');
    expect(mockApiService.patchPackage).toHaveBeenCalled();
  });

  it('Should send package', () => {
    spyOn(mockApiService, 'sendPackage');
    packageService.send(mockPackages[0], mockRecipients, true);
    expect(mockApiService.sendPackage).toHaveBeenCalledWith(mockPackages[0].id, mockRecipients, true);
  });

  it('Should get package recipients', () => {
    spyOn(mockApiService, 'getPackageRecipients');
    packageService.getPackageRecipients(mockPackages[0].id, selectedStatus, 1, 100, true);
    expect(mockApiService.getPackageRecipients).toHaveBeenCalledWith(mockPackages[0].id, mockStatus, 1, 100, true);
  });

  it('Should get package recipent summary', () => {
    spyOn(mockApiService, 'getPackageRecipientsSummary');
    packageService.getPackageRecipientsSummary(mockPackages[0].id, true);
    expect(mockApiService.getPackageRecipientsSummary).toHaveBeenCalledWith(mockPackages[0].id, true);
  });

});
