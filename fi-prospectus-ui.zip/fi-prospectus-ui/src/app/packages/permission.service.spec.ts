import { TestBed } from '@angular/core/testing';
import { ApiService, PermissionDto, AppContext } from '../../common';
import { PermissionService } from './permission.service';
import { HttpClientModule } from '@angular/common/http';
import { MapperService } from 'src/common/api/mapper.service';
import { of } from 'rxjs';

describe('Service: Permission Service', () => {

    let permissionService: PermissionService;
    let mockApiService: ApiService;
    const mockPermissions = [
        {
            'key': 'Contact.Edit',
            'metadata': []
        }
    ] as PermissionDto[];
    const apiServiceStub = {
        getContactPermissions: function () {
            return of([]);
        }
    }

    const permissionServiceStub = {
        getPermissions: function () {
            return of(mockPermissions);
        }
    }

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                HttpClientModule,
            ],
            providers: [
                { provide: ApiService, useValue: apiServiceStub },
                {
                    provide: PermissionService, useValue: permissionServiceStub
                },
                AppContext,
                PermissionService,
                MapperService
            ]
        });
        permissionService = TestBed.get(PermissionService);
        mockApiService = TestBed.get(ApiService);
    });

    it('should subscribe to Permission', () => {
        permissionService.permission$.subscribe((items) => {
            if (items) {
                expect(items).toBe(mockPermissions);
            }
        });
        permissionService['permission'].next(mockPermissions);
    });

    it('Should get permission lists', () => {
        spyOn(mockApiService, 'getContactPermissions').and.callThrough();
        permissionService.getPermissions();
        expect(mockApiService.getContactPermissions).toHaveBeenCalled();
    });
});
