import { FiAuthConfig } from '../common/auth';
import { Injectable } from '@angular/core';
import { AppContext } from 'src/common';

@Injectable()
export class ProspectusAuthConfig extends FiAuthConfig {

  constructor() {
    super()

    this.clientId = 'prospectus.client'
    this.scope = `openid profile email
      ns-orders
      deals-read
      permissions-read
      users-read
      source-app-info
      accesscontrol-read
      investor-accounts-read
      investor-account-contacts-read
      investor-account-contacts-write
      coverage-contacts-read
      coverage-contacts-write
      indications-read
      allocations-read
      fi-prospectus`.replace(/\s+/g, ' ')
  }

  setIssuer(issuer: string) {
    this.issuer = issuer
  }
}
