import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { PackageService } from './packages/package.service';
import { ProspectusCommonModule, AppContext, DealDto, TrancheDto } from '../common';
import { NotificationService } from '../common/notification/notification.service';
import { CupcakeModalModule, CupcakeNotifyService } from '@ipreo/cupcake-components';
import { FiAuthService } from '../common/auth';
import { of } from 'rxjs';

const mockDeal: DealDto = {
  id: '1',
  name: 'sales-credits-ui-test-deal',
  size: 20000000,
  currency: 'USD',
  tranches: [
    {
      id: '12',
      name: 'tranche 1',
      sourceId: '123',
      _isDisabled: true
    },
    {
      id: 354610,
      name: 'tranche 2',
      sourceId: '1234',
      _isDisabled: true
    }
  ] as TrancheDto[],
  issuerName: '1155 Island Avenue LLC',
  isPreferred: false
};

const authServiceMock = {
  isAuthenticated: true,
  authenticate: () => { },
  authenticated$: { subscribe: () => { } },
  user: {}
}

const PackageServiceMock = {
  refresh: () => { },
  deal$: () => {
    return of(mockDeal);
  }
};

describe('AppComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpClientModule,
        CupcakeModalModule,
        ProspectusCommonModule.forRoot()
      ],
      declarations: [
        AppComponent
      ],
      providers: [
        NotificationService,
        CupcakeNotifyService,
        AppContext,
        { provide: PackageService, useValue: PackageServiceMock },
        { provide: FiAuthService, useValue: authServiceMock }
      ]
    }).compileComponents();
  }));
  it('should create the app', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  }));
});
