import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';

import { OAuthModule, OAuthStorage } from 'angular-oauth2-oidc';

import { AgGridModule } from 'ag-grid-angular';
import { CupcakeSuggesterModule } from '@ipreo/cupcake-suggester';
import { CupcakeModalModule, CupcakePopoverModule, CupcakeNotifyService, CupcakeDropdownsModule } from '@ipreo/cupcake-components';
import { DatePipe, TitleCasePipe } from '@angular/common';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SharedModule } from './shared/shared.module';
import { ContactComponent } from './packages/contact/contact.component';
import { CreatePackageComponent } from './packages/create/create.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { PackagesViewComponent } from './packages/view/view.component';
import { HelperService } from './shared/helper.service';
import { PackageService } from './packages/package.service';
import { RecipientService } from './packages/recipients/recipient.service';
import { ApiService, ApiHttpInterceptor } from '../common';
import { HttpClientModule } from '@angular/common/http';
import { ProspectusCommonModule } from '../common/common.module';
import { DocumentsComponent } from './documents/documents.component';
import { FormsModule } from '@angular/forms';
import { RouterLinkRendererComponent } from './shared/component/router-link-rendererer.component';
import { TrackingComponent } from './packages/tracking/tracking.component';
import { EditcontactRendererComponent } from './packages/tracking/editContact-rendererer.component';
import { PreviewComponent } from './packages/preview/preview.component';
import { RecipientsComponent } from './packages/recipients/recipients.component';
import { SpinnerRendererComponent } from './packages/recipients/spinner-renderer.component';
import { GridCheckMarkRendererComponent } from './packages/recipients/gridcheckMark-renderer.component';
import { DocumentNameRendererComponent } from './documents/column-renderers/document-name-renderer.component';
import { DocumentTypeRendererComponent } from './documents/column-renderers/document-type-renderer.component';
import { DocumentDealTypeRendererComponent } from './documents/column-renderers/document-deal-type-renderer.component';
import { DocumentFileNameRendererComponent } from './documents/column-renderers/document-file-name-renderer.component';
import { ActionsRendererComponent } from './documents/column-renderers/actions-renderer.component';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { NotificationService } from '../common/notification/notification.service';
import { DocumentService } from './documents/document.service';
import { AttachmentsComponent } from './documents/attachments/attachments.component';
import { LoginComponent } from './login/login.component';
import { JwtHelperService } from '@auth0/angular-jwt';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { FiOAuthStorage } from 'src/common/auth';
import { PermissionService } from './packages/permission.service';
import { ClickOutsideModule } from 'ng-click-outside';


export const httpInterceptorProviders = [{
  provide: HTTP_INTERCEPTORS,
  useClass: ApiHttpInterceptor,
  multi: true
}];

@NgModule({
  declarations: [
    AppComponent,
    ContactComponent,
    CreatePackageComponent,
    PageNotFoundComponent,
    PackagesViewComponent,
    LoginComponent,
    DocumentsComponent,
    RouterLinkRendererComponent,
    TrackingComponent,
    EditcontactRendererComponent,
    PreviewComponent, SpinnerRendererComponent, GridCheckMarkRendererComponent,
    RecipientsComponent,
    DocumentNameRendererComponent, DocumentTypeRendererComponent,
    DocumentDealTypeRendererComponent, DocumentFileNameRendererComponent, ActionsRendererComponent,
    AttachmentsComponent

  ],
  imports: [
    FormsModule,
    BrowserModule,
    AppRoutingModule,
    AgGridModule.withComponents([RouterLinkRendererComponent, EditcontactRendererComponent]),
    CupcakeModalModule,
    CupcakeSuggesterModule,
    CupcakePopoverModule,
    CupcakeDropdownsModule,
    SharedModule,
    ClickOutsideModule,
    ProspectusCommonModule.forRoot(),
    HttpClientModule,
    OAuthModule.forRoot()
  ],
  entryComponents: [
    SpinnerRendererComponent, GridCheckMarkRendererComponent,
    DocumentNameRendererComponent, DocumentTypeRendererComponent,
    DocumentDealTypeRendererComponent, DocumentFileNameRendererComponent, ActionsRendererComponent,
    AttachmentsComponent,
    ContactComponent,
    PreviewComponent,
    RecipientsComponent,
    LoginComponent
  ],
  providers: [
    PackageService,
    RecipientService,
    DocumentService,
    ApiService,
    PermissionService,
    HelperService,
    httpInterceptorProviders,
    NotificationService,
    CupcakeNotifyService,
    DatePipe,
    TitleCasePipe,
    { provide: OAuthStorage, useFactory: () => new FiOAuthStorage('fi-prospectus') },
    { provide: JwtHelperService, useFactory: () => new JwtHelperService() },
    { provide: LocationStrategy, useClass: HashLocationStrategy }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
