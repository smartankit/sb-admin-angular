import {
  CupcakeNotifyService,
  CupcakeDomService,
  CupcakeNotifyOptions
} from '@ipreo/cupcake-components';

import {
  Injectable
} from '@angular/core';

@Injectable()
export class NotificationService {
  private errorConfig: CupcakeNotifyOptions;
  private warningConfig: CupcakeNotifyOptions;
  private successConfig: CupcakeNotifyOptions;

  constructor(
    private cupcakeNotifyService: CupcakeNotifyService,
    private cupcakeDomService: CupcakeDomService
  ) {
    this.errorConfig = {
      type: 'danger',
      maxLogItems: 7,
      closeOnClick: false,
      delay: 10000,
      position: 'top right',
      // template: this.getTemplate('error'),
      onclose: undefined
    };

    this.warningConfig = {
      type: 'warning',
      maxLogItems: 7,
      closeOnClick: false,
      delay: 5000,
      position: 'top right',
      // template: this.getTemplate('warning'),
      onclose: undefined
    };

    this.successConfig = {
      type: 'success',
      maxLogItems: 7,
      closeOnClick: true,
      delay: 5000,
      position: 'top right',
      // template: this.getTempalte('success'),
      onclose: undefined
    };
  }

  public error(message: string = 'Operation failed', errors: Array<any> = []) {
    setTimeout(() => {
      this.cupcakeNotifyService.log(message, this.errorConfig);
    });
  }

  public warn(message: string = '') {
    setTimeout(() => {
      this.cupcakeNotifyService.log(message, this.warningConfig);
    });
  }

  public success(message: string = 'Operation was successfull') {
    setTimeout(() => {
      this.cupcakeNotifyService.log(message, this.successConfig);
    });
  }

  public log(type: string, message: string) {
    switch (type) {
      case 'error': {
        this.error(message);
        break;
      }
      case 'warning': {
        this.warn(message);
        break;
      }
      case 'success': {
        this.success(message);
        break;
      }
      default: { }
    }
  }

  private getTemplate(type: string) {
    let iClass = '';
    if (type === 'error') {
      iClass = 'fa fa-exclamation-circle c-m-right-sm';
    } else if (type === 'warning') {
      iClass = 'fa fa-check-circle c-m-right-sm';
    } else if (type === 'success') {
      iClass = 'fa fa-check-circle c-m-right-sm';
    }

    return (message: string, element: any, options: CupcakeNotifyOptions, closeFn: any) => {
      this.cupcakeDomService.addClass(element, `cout-alert-${type}`);
      this.cupcakeDomService.addClass(element.parentElement, 'cout-notification');

      element.innerHTML = `
        <i class="${iClass}"></i> ${message}
        <a class="cout-alert-close"><i class="fa fa-times"></i></a>
      `;

      // attach click event to close button
      this.cupcakeDomService.event(element.querySelector('.cout-alert-close'), 'click', closeFn);
    };
  }
}
