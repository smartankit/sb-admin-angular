import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModuleWithProviders } from '@angular/compiler/src/core';
import { ApiService } from './api/api.service';
import { SpinnerService, CoutSpinnerComponent } from './spinner';
import { AppContext } from './services/app-context.service';
import { MapperService } from './api/mapper.service';
import { FiAuthService, FiAuthGuard, FiOAuthStorage, FiNoAccessGuard } from './auth';
import { SearchPipe } from './pipes/search.pipe';

@NgModule({
  imports: [CommonModule],
  declarations: [CoutSpinnerComponent, SearchPipe],
  exports: [CoutSpinnerComponent, SearchPipe]
})
export class ProspectusCommonModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: ProspectusCommonModule,
      providers: [
        ApiService,
        SpinnerService,
        AppContext,
        MapperService,
        FiAuthService,
        FiAuthGuard,
        FiNoAccessGuard
      ]
    };
  }
}
