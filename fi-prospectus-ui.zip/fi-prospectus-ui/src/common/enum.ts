export enum TabType {
  None = 0,
  Document = 1,
  Package = 2,
  Contact = 3,
  Tracking = 4
}

export enum RecipientStatus {
  Sent = 'sent',
  Failed = 'failed',
  NotYetSent = 'notYetSent'
}

export enum DealType {
  DealWide = 'Deal-wide',
  TrancheSpecific = 'Tranche-specific'
}

export enum ContactType {
  Investor = 'investor'
}

export enum AutoSendType {
  None = 'none',
  Indications = 'indications',
  Allocations = 'allocations',
  Syndicates = 'syndicates'
}

export enum PermissionType {
  EditContact = 'Contact.Edit'
}

export enum CheckboxEventType {
  DeselectAll = 'DeselectAll',
  SelectAll = 'SelectAll',
  Individual = 'Individual',
  None = 'None'
}

export enum GridUpdateType {
  NewRecipients = 'NEW RECIPIENTS',
  ExistingRecipients = 'EXISTING RECIPIENTS'
}
