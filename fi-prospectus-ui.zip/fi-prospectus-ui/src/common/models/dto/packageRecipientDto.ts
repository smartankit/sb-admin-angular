export class PackageRecipientDto {
  prospectusTrackingId: number;
  investorAccountId: string;
  contactId: string;
  company: string;
  role: string;
  firstName: string;
  lastName: string;
  email: string;
  sentDate: Date;
  statusCode: string;
  status: string;
  packageName?: string;
  selected?: boolean

  constructor() { }
}
