export class ConsentLanguageDto {
  id: string;
  name: string;
  disclaimerBody: string;
  rowVersion: number;
}
