export class AutoSendDto {
  syndicate: boolean;
  allocation: boolean;
  indication: boolean;
}
