
export class ContactRolesDto {
  name: string;
  value: string;

  constructor() { }

}
