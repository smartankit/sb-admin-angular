
import { RecipientDto, PackageRecipientDto } from '../..';

export class AddDeleteRecipientInfoDto {
    deSelectAll: boolean;
    added: PackageRecipientDto[];
    deleted: PackageRecipientDto[];

    constructor() {
    }

}
