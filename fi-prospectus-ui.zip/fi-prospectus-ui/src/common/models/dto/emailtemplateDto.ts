export class EmailTemplateDto {
  id: string;
  name: string;
  templateBody: string;
  rowVersion: number;

  constructor() { }
}
