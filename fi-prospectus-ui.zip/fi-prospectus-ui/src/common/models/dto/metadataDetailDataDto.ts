export class MetadataDetailDataDto {
  key: string;
  dataValues: string[];
}

