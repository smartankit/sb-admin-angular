
import { PackageRecipientDto } from '../..';

export class PackageRecipientPagedDto  {
  items: PackageRecipientDto[];
  page: number;
  pageSize: number;
  total: number;

  constructor() { }
}
