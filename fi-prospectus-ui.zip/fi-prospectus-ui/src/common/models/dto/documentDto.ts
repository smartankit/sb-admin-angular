export class DocumentDto {
  id: string;
  name: string;
  fileSize: string;
  fileName: string;
  documentType: string;
  isDocumentTypeUrl: boolean;
  disclaimer: string;
  isDealWide: boolean;
  firmId: number;
  dealId: number;
  trancheId?: number;
  sourceId?: number;
  fileToUpload?: any;
  isUsed: boolean;
  isPackageSent: boolean;
  rowVersion?: number;
  constructor() { }

}
