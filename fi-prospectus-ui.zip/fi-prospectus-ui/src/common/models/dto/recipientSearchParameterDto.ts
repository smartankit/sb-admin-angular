
export class RecipientSearchParameterDto {
  packageId: string;
  role: string;
  companyName: string;
  contactName: string;
  email: string;

  constructor() {
    this.resetThis();
  }

  resetThis(): void {
    this.role = 'Select Role';
    this.companyName = '';
    this.contactName = '';
    this.email = '';
  }

}
