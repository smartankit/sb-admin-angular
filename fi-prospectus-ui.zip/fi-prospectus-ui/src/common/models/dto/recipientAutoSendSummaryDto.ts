
export class RecipientAutoSendSummaryDto {
  allocationCount: number;
  indicationCount: number;
  syndicateCount: number;
  constructor() {
  }
}
