
import { MetadataDetailDataDto } from '../..';

export class PermissionDto {
  key: string;
  metadata: MetadataDetailDataDto[];

  constructor() {
    this.metadata = [];
  }
}

