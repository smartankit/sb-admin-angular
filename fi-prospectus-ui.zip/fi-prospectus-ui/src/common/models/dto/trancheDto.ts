export class TrancheDto {
  id: string;
  name: string;
  sourceId: string;
  _isDisabled: boolean;

  constructor() {
  }
}
