import { DocumentDto } from './documentDto';
import { PackageRecipientDto, TrancheDto, RecipientStatusSummaryDto } from '../..';
import { AutoSendDto } from './autoSendDto';

// TODO: need to remove unncessary properties for expiration date
export class PackageDto {
  id?: string;
  name: string;
  subject: string;
  documents?: DocumentDto[];
  emailBody?: string;
  sent?: Date;
  recipients?: PackageRecipientDto[];
  sourceId?: number;
  emailTemplateId?: string;
  expirationDate?: string;
  expirationTimezone?: string;
  generateSeparateEmailPassword?: boolean;
  consentLanguageId?: string;
  totalViews?: number;
  tracking?: boolean;
  published?: string;
  sentBy?: string;
  isDealWide?: boolean;
  firmId: number;
  dealId: string;
  tranches?: TrancheDto[];
  isDisabled?: boolean;
  autoSend?: string[];
  beingSent?: boolean;
  _dealTrancheInfo?: string;
  _summaryLoading?: boolean;
  _summary?: RecipientStatusSummaryDto;
  _autoSendType?: AutoSendDto;
  rowVersion?: number;
  clientName?: string;

  constructor() {
    this.documents = [];
    this.recipients = [];
  }
}

