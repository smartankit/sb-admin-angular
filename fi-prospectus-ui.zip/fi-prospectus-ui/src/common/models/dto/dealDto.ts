import { TrancheDto } from './trancheDto';

export class DealDto {
  id: string;
  name: string;
  size: number;
  currency: string;
  issuerName: string;
  // TODO: Need to verify again after Get Deals API is updated with this property
  isPreferred: boolean;
  tranches: TrancheDto[];

  constructor() {
    this.tranches = [];
  }
}
