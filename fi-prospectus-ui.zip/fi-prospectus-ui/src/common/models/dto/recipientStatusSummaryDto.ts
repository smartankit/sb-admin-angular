
export class RecipientStatusSummaryDto {
  sent: number;
  failed: number;
  notYetSent: number;
  lastSentDate: string;
  pollingCallsMade: number;
  constructor() {
  }
}
