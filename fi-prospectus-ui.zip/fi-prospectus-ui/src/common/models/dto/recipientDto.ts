export class RecipientDto {

  id: number;
  role: string;
  company: string;
  employerType: string;
  title?: string;
  firstName: string;
  middleName?: string;
  lastName: string;
  email: string;
  emailAddress2?: string;
  phoneNumber?: string;
  mobilePhone?: string;
  fax?: string;
  jobDescription?: string;
  internalID?: string;
  externalID1?: string;
  externalID2?: string;
  externalID3?: string;
  employerAddress?: string;
  contactSpecificAddresses?: string;
  notes?: string;
  location?: string;
  billedBy?: string;
  sender?: string;
  sent?: string;
  status?: string;
  isProspectusContact: boolean;
  rowVersion?: number;
  selected?: boolean;
  contactId: string;

  constructor() { }

}
