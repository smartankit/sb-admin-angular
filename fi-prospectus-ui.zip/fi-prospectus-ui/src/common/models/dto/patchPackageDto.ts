export class PatchPackageDto {
  op: string;
  path: string;
  value: any;

  constructor() {
    this.op = 'replace';
  }
}
