import { PackageRecipientDto, RecipientDto } from '../..';

export class RecipientPagedDto  {
  items: RecipientDto[];
  page: number;
  pageSize: number;
  total: number;

  constructor() { }
}
