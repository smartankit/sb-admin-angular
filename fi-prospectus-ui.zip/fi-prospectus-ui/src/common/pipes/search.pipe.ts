import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'search'
})
export class SearchPipe implements PipeTransform {

  transform(items: any, searchItem?: any): any {
    if (searchItem && searchItem.name != null) {
      return items.filter(item => item.name === searchItem.name);
    } else {
      return items;
    }

  }

}
