import { TestBed } from '@angular/core/testing';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { DealDto, TrancheDto, PackageDto, DocumentDto, AddDeleteRecipientInfoDto } from '../../common';
import { of } from 'rxjs';
import { ApiService } from './api.service';
import { AppContext } from '../services/app-context.service';
import { MapperService } from './mapper.service';

describe('Service: API Service', () => {

  let apiURL;
  let apiService: ApiService;
  let mockHttp: HttpClient;
  let mockAppContext: AppContext;
  let mockMapperService: MapperService;
  const httpStub = {
    get: function () {
    },
    post: function () {
    },
    put: function () {
    },
    delete: function () {
    }
  };
  const appContextStub = {
    apiUrl: 'propectus-api.com',
    dealId: '1',
    trancheId: '2',
    dealSourceId: '11',
    trancheSourceId: '22'
  };
  const mapperSummary = {
    sent: null,
    failed: null,
    notYetSent: null,
    pollingCallsMade: 0,
    lastSentDate: null
  };
  const mapperServiceStub = {
    mapToPackageDto: function (packageForIB) {
      packageForIB._summary = mapperSummary;
      return packageForIB;
    },
    mapToDocumentDto: function (documentForIB) {
      documentForIB.documentType = documentForIB.isDocumentTypeUrl === true ? 'URL' : 'File';
      return documentForIB;
    },
    mapDocumentToPostData: function (documentForIB) {
      documentForIB.documentType = documentForIB.isDocumentTypeUrl === true ? 'URL' : 'File';
      return documentForIB;
    }
  };
  const mockDeal: DealDto = {
    id: '1',
    name: 'sales-credits-ui-test-deal',
    size: 20000000,
    currency: 'USD',
    tranches: [
      {
        id: '2',
        name: 'tranche 1'
      },
      {
        id: '354610',
        name: 'tranche 2'
      }
    ] as TrancheDto[],
    issuerName: '1155 Island Avenue LLC',
    isPreferred: false
  };
  const mockTranche: TrancheDto = {
    id: '2',
    name: '5 Yr Tranche',
    sourceId: '1234',
    _isDisabled: true
  };
  const mockDocuments: DocumentDto[] = [
    {
      'name': 'Prospecus Document',
      'fileSize': '234kb',
      'documentType': null,
      'isDocumentTypeUrl': false,
      'fileName': '',
      'disclaimer': 'Standard',
      'isDealWide': true,
      'sourceId': 1,
      'firmId': 1,
      'dealId': 1,
      'trancheId': 1,
      'id': '1',
      'fileToUpload': null,
      'isUsed': false,
      'isPackageSent': false
    },
    {
      'name': 'Prospecus Document2',
      'isDocumentTypeUrl': false,
      'fileSize': '958kb',
      'documentType': null,
      'fileName': '',
      'disclaimer': 'Standard',
      'isDealWide': false,
      'sourceId': 3,
      'firmId': 1,
      'dealId': 1,
      'trancheId': 1,
      'id': '3',
      'fileToUpload': null,
      'isUsed': false,
      'isPackageSent': false
    }
  ];
  const mockPackages = [
    {
      id: '1234',
      firmId: 1,
      dealId: '1',
      name: 'test package',
      emailTemplateId: '39e85ff0-6c36-6793-5c41-d87cd00bc7ac',
      emailBody: '<p>blah blah 2</p>',
      expirationDate: '2018-09-22T12:00:00',
      expirationTimezone: 'America/New_York',
      subject: '3rd Deal',
      consentLanguageId: '39e85ff1-1aea-e7f7-726e-7630c8315c3b',
      documents: [],
      _summaryLoading: true
    },
    {
      id: '111111',
      firmId: 1,
      dealId: '1',
      name: 'test package',
      emailTemplateId: '39e85ff0-6c36-6793-5c41-d87cd00bc7ac',
      emailBody: '<p>blah blah 2</p>',
      expirationDate: '2018-09-22T12:00:00',
      expirationTimezone: 'America/New_York',
      subject: '3rd Deal',
      consentLanguageId: '39e85ff1-1aea-e7f7-726e-7630c8315c3b',
      documents: [],
      _summaryLoading: true
    }
  ] as PackageDto[];
  const mockRecipients: any[] = [
    {
      'isDealWide': false,
      'isProspectusContact': false,
      'location': null,
      'prospectusTrackingId': 1850824175,
      'contactId': 'e1dc0bca-baf4-4812-9c0c-185bd1a034a1',
      'company': 'investor3',
      'role': 'Investor',
      'firstName': 'Murali',
      'lastName': 'Manchikatla',
      'email': 'murali.manchikatla@ipreo.com',
      'sentDate': '2018-09-20T13:33:01.163Z',
      'statusCode': 'sent',
      'status': null
    },
    {
      'isDealWide': false,
      'isProspectusContact': false,
      'location': null,
      'prospectusTrackingId': 1850824175,
      'contactId': 'e1dc0bca-baf4-4812-9c0c-185bd1a034a1',
      'company': 'investor3',
      'role': 'Investor',
      'firstName': 'Ravi',
      'lastName': 'T',
      'email': 'ravi.t@ipreo.com',
      'sentDate': '2018-09-20T13:33:01.163Z',
      'statusCode': 'sent',
      'status': null
    }
  ];
  const mockAddDeleteRecipientInfo: AddDeleteRecipientInfoDto = {
    'deSelectAll': false,
    'added': mockRecipients,
    'deleted': mockRecipients
  };

  const paginationResponse: any = {
    items: mockRecipients,
    total: 2
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        ApiService,
        {
          provide: HttpClient, useValue: httpStub
        },
        {
          provide: AppContext, useValue: appContextStub
        },
        {
          provide: MapperService, useValue: mapperServiceStub
        }
      ]
    });
    mockHttp = TestBed.get(HttpClient);
    mockAppContext = TestBed.get(AppContext);
    mockMapperService = TestBed.get(MapperService);
    apiService = TestBed.get(ApiService);
    apiService.baseUrl = 'baseUrl.prospectus.com';
  });

  it('Should get deal by deal ID', () => {
    apiURL = mockAppContext.apiUrl + '/v1/deals/' + mockAppContext.dealSourceId;
    spyOn(mockHttp, 'get').and.returnValue(of(mockDeal));
    apiService.getDeal().subscribe((deal) => {
      expect(deal).toBe(mockDeal);
    });
    expect(mockHttp.get).toHaveBeenCalledWith(apiURL);
  });

  it('Should get tranche by deal ID and tranche ID', () => {
    apiURL = mockAppContext.apiUrl + '/v1/deals/' + mockAppContext.dealSourceId + '/tranches/' + mockAppContext.trancheSourceId;
    spyOn(mockHttp, 'get').and.returnValue(of(mockTranche));
    apiService.getTranche().subscribe((tranche) => {
      expect(tranche).toBe(mockTranche);
    });
    expect(mockHttp.get).toHaveBeenCalledWith(apiURL);
  });

  it('Should get packages by deal ID and tranche ID', () => {
    apiURL = mockAppContext.apiUrl
      + '/v1/packages?dealId=' + mockAppContext.dealId + '&trancheId=' + mockAppContext.trancheId;
    spyOn(mockHttp, 'get').and.returnValue(of(JSON.parse(JSON.stringify(mockPackages))));
    apiService.getPackagesByDeal().subscribe((packagesForIB) => {
      mockPackages.map(function (mockPackage) {
        mockPackage._summary = mapperSummary;
      });
      expect(packagesForIB).toEqual(mockPackages);
    });
    expect(mockHttp.get).toHaveBeenCalledWith(apiURL);
  });

  it('Should get package by package ID', () => {
    apiURL = mockAppContext.apiUrl + '/v1/packages/' + mockPackages[0].id;
    spyOn(mockHttp, 'get').and.returnValue(of(mockPackages[0]));
    apiService.getPackageById(mockPackages[0].id).subscribe((packageForIB) => {
      expect(packageForIB).toBe(mockPackages[0]);
    });
    expect(mockHttp.get).toHaveBeenCalledWith(apiURL);
  });

  it('Should update package by package ID', () => {
    apiURL = mockAppContext.apiUrl + `/v1/packages/`;
    spyOn(mockHttp, 'put').and.returnValue(of(mockPackages[0]));
    apiService.updatePackage(mockPackages[0]).subscribe((packageForIB) => {
      expect(packageForIB).toBe(mockPackages[0]);
    });
    expect(mockHttp.put).toHaveBeenCalledWith(apiURL, mockPackages[0]);
  });

  it('Should get all documents by tranche ID and package ID', () => {
    apiURL = mockAppContext.apiUrl + '/v1/documents?dealId=' + mockAppContext.dealId;
    spyOn(mockHttp, 'get').and.returnValue(of(JSON.parse(JSON.stringify(mockDocuments))));
    apiService.getDocuments(true).subscribe((documentsForIB) => {
      mockDocuments.map(function (d) {
        d.documentType = d.isDocumentTypeUrl === true ? 'URL' : 'File';
      });
      expect(documentsForIB).toEqual(mockDocuments);
    });
    expect(mockHttp.get).toHaveBeenCalledWith(apiURL);
  });


  // it('Should get recipient roles', () => {
  //   const recipientsRoles: ContactRolesDropdownDto[] = ['Investor', 'External Syndicates', 'Internal Contacts'];
  //   apiService.getRecipientsRoles().subscribe((roles) => {
  //     expect(roles).toEqual(recipientsRoles);

  //   });
  // });

  it('Should save package', () => {
    apiURL = mockAppContext.apiUrl + `/v1/packages`;
    spyOn(mockHttp, 'post').and.returnValue(of(mockPackages[0]));
    apiService.savePackage(mockPackages[0]);
    expect(mockHttp.post).toHaveBeenCalledWith(apiURL, mockPackages[0]);
  });

  it('Should save document metadata', () => {
    let mappedDocument;
    apiURL = mockAppContext.apiUrl + '/v1/documents';
    spyOn(mockMapperService, 'mapDocumentToPostData').and.callThrough();
    spyOn(mockHttp, 'post').and.returnValue(of(mockDocuments[0]));
    mockDocuments[0].documentType = null;
    mappedDocument = JSON.parse(JSON.stringify(mockDocuments[0]));
    mappedDocument = mockMapperService.mapDocumentToPostData(mappedDocument);
    apiService.saveDocumentMetadata(mockDocuments[0]).subscribe((documentForIB) => {
      expect(documentForIB).toEqual(mockDocuments[0]);
    });
    expect(mockMapperService.mapDocumentToPostData).toHaveBeenCalledWith(mockDocuments[0]);
    expect(mockHttp.post).toHaveBeenCalledWith(apiURL, mappedDocument);
  });

  it('Should update document metadata', () => {
    let mappedDocument;
    apiURL = mockAppContext.apiUrl + '/v1/documents';
    spyOn(mockMapperService, 'mapDocumentToPostData').and.callThrough();
    spyOn(mockHttp, 'put').and.returnValue(of(mockDocuments[0]));
    mockDocuments[0].documentType = null;
    mappedDocument = JSON.parse(JSON.stringify(mockDocuments[0]));
    mappedDocument = mockMapperService.mapDocumentToPostData(mappedDocument);
    apiService.updateDocumentMetadata(mockDocuments[0]).subscribe((documentForIB) => {
      expect(documentForIB).toEqual(mockDocuments[0]);
    });
    expect(mockMapperService.mapDocumentToPostData).toHaveBeenCalledWith(mockDocuments[0]);
    expect(mockHttp.put).toHaveBeenCalledWith(apiURL, mappedDocument);
  });

  it('Should post file', () => {
    let sourceId, formData: FormData;
    sourceId = 1;
    formData = null;
    apiURL = mockAppContext.apiUrl + '/v1/documents/' + sourceId + '/file';
    spyOn(mockHttp, 'post');
    apiService.postFile(formData, 1);
    expect(mockHttp.post).toHaveBeenCalledWith(apiURL, formData);
  });

  it('Should add recipients to package', () => {
    let packageId;
    packageId = 1;
    apiURL = mockAppContext.apiUrl + '/v1/packages/' + packageId + '/recipients';
    spyOn(mockHttp, 'post');
    apiService.addRecipientsToPackage(packageId, mockAddDeleteRecipientInfo);
    expect(mockHttp.post).toHaveBeenCalledWith(apiURL, mockAddDeleteRecipientInfo);
  });

  it('Should get recipient info', () => {
    let recipientId;
    recipientId = 1;
    apiURL = mockAppContext.apiUrl + '/v1/recipients/' + recipientId + '?type=Investor';
    spyOn(mockHttp, 'get').and.returnValue(of(mockRecipients[0]));
    apiService.getContactInfo(recipientId, 'Investor').subscribe((contactForIB) => {
      expect(contactForIB).toEqual(mockRecipients[0]);
    });
    expect(mockHttp.get).toHaveBeenCalledWith(apiURL);
  });

  it('Should put recipient info', () => {
    let recipientId;
    recipientId = 1;
    apiURL = mockAppContext.apiUrl + '/v1/recipients';
    spyOn(mockHttp, 'put').and.returnValue(of(mockRecipients[0]));
    apiService.putContactInfo(mockRecipients[0]).subscribe((contactForIB) => {
      expect(contactForIB).toEqual(mockRecipients[0]);
    });
    expect(mockHttp.put).toHaveBeenCalledWith(apiURL, mockRecipients[0]);
  });

  it('Should get employer roles', () => {
    const mockRoles = ['Investor', 'Bank', 'Sales Agent'];
    apiURL = apiService.baseUrl + `assets/mocks/roles.json`;
    spyOn(mockHttp, 'get').and.returnValue(of(mockRoles));
    apiService.getEmployerRoles().subscribe((roles) => {
      expect(roles).toEqual(mockRoles);
    });
    expect(mockHttp.get).toHaveBeenCalledWith(apiURL);
  });

  it('Should get consent languages', () => {
    const mockConsentLanguages: any = ['English', 'Hindi'];
    apiURL = mockAppContext.apiUrl + '/v1/consent-languages';
    spyOn(mockHttp, 'get').and.returnValue(of(mockConsentLanguages));
    apiService.getConsentLanguages().subscribe((consentLanguages) => {
      expect(consentLanguages).toEqual(mockConsentLanguages);
    });
    expect(mockHttp.get).toHaveBeenCalledWith(apiURL);
  });

  it('Should get email templates', () => {
    const mockEmailTemplates: any = ['Hello User', 'Hi User'];
    apiURL = mockAppContext.apiUrl + '/v1/email-templates';
    spyOn(mockHttp, 'get').and.returnValue(of(mockEmailTemplates));
    apiService.getEmailTemplates().subscribe((emailTemplates) => {
      expect(emailTemplates).toEqual(mockEmailTemplates);
    });
    expect(mockHttp.get).toHaveBeenCalledWith(apiURL);
  });

  it('Should delete documents', () => {
    let documentId;
    documentId = 1;
    apiURL = mockAppContext.apiUrl + '/v1/documents/' + documentId;
    spyOn(mockHttp, 'delete');
    apiService.deleteDocuments(documentId);
    expect(mockHttp.delete).toHaveBeenCalledWith(apiURL);
  });

  it('Should download documents', () => {
    let sourceId;
    sourceId = 1;
    apiURL = mockAppContext.apiUrl + '/v1/documents/' + sourceId + '/file/download';
    spyOn(mockHttp, 'get');
    apiService.downloadDocument(sourceId);
    expect(mockHttp.get).toHaveBeenCalledWith(apiURL, { responseType: 'blob' });
  });

  it('Should get document name types', () => {
    const documentNameTypes = ['Internal Research', 'External Research', 'Prospectus', 'Issuer Web Page', 'News', 'Roadshow'];
    apiService.getDocumentNameTypes().subscribe((dnt) => {
      expect(dnt).toEqual(documentNameTypes);
    });
  });

  // it('Should send package', () => {
  //   let packageId, spyHttpSendPackage;
  //   const httpOptions = {
  //     headers: new HttpHeaders({
  //       'byPassSpinner': 'yes'
  //     })
  //   };
  //   packageId = 1;
  //   apiURL = mockAppContext.apiUrl + '/v1/packages/send?PackageId=1&InvestorAccountId=1&DealId=1&audience=new';
  //   spyHttpSendPackage = spyOn(mockHttp, 'post');
  //   apiService.sendPackage(packageId, mockRecipients, true);
  //   expect(mockHttp.post).toHaveBeenCalledWith(apiURL, mockRecipients, jasmine.any(Object));
  //   expect(JSON.stringify(spyHttpSendPackage.calls.mostRecent().args[2])).toEqual(JSON.stringify(httpOptions));
  //   spyHttpSendPackage.calls.reset();
  //   apiService.sendPackage(packageId, mockRecipients, false);
  //   expect(mockHttp.post).toHaveBeenCalledWith(apiURL, mockRecipients, undefined);
  // });

  // it('Should get package recipients', () => {
  //   let packageId, spyHttpGet;
  //   const httpOptions = {
  //     headers: new HttpHeaders({
  //       'byPassSpinner': 'yes'
  //     })
  //   };
  //   packageId = 1;
  //   apiURL = mockAppContext.apiUrl + '/v1/packages/' + packageId + '/recipients';
  //   spyHttpGet = spyOn(mockHttp, 'get').and.returnValue(of(mockRecipients));
  //   apiService.getPackageRecipients(packageId, true).subscribe((recipients) => {
  //     expect(recipients).toEqual(mockRecipients);
  //   });
  //   apiService.getPackageRecipients(packageId, true);
  //   expect(mockHttp.get).toHaveBeenCalledWith(apiURL, jasmine.any(Object));
  //   expect(JSON.stringify(spyHttpGet.calls.mostRecent().args[1])).toEqual(JSON.stringify(httpOptions));
  //   spyHttpGet.calls.reset();
  //   apiService.getPackageRecipients(packageId, false);
  //   expect(mockHttp.get).toHaveBeenCalledWith(apiURL, undefined);
  // });

  it('Should get package recipients sumamry', () => {
    let packageId, spyHttpGet;
    const httpOptions = {
      headers: new HttpHeaders({
        'byPassSpinner': 'yes'
      })
    };
    packageId = 1;
    apiURL = mockAppContext.apiUrl + '/v1/packages/' + packageId + '/recipients/status/summary';
    spyHttpGet = spyOn(mockHttp, 'get').and.returnValue(of(paginationResponse));
    apiService.getPackageRecipientsSummary(packageId, true).subscribe((response) => {
      expect(response).toEqual(paginationResponse);
    });
    expect(mockHttp.get).toHaveBeenCalledWith(apiURL, jasmine.any(Object));
    expect(JSON.stringify(spyHttpGet.calls.mostRecent().args[1])).toEqual(JSON.stringify(httpOptions));
    spyHttpGet.calls.reset();
    apiService.getPackageRecipientsSummary(packageId, false);
    expect(mockHttp.get).toHaveBeenCalledWith(apiURL, undefined);
  });

});
