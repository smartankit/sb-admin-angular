import { Injectable } from '@angular/core';
import { DocumentDto } from '../models/dto/documentDto';
import { PackageDto } from '../models/dto/packageDto';

@Injectable()
export class MapperService {

  mapToDocumentDto(data: any): DocumentDto {
    const dto = new DocumentDto();

    dto.dealId = data.dealId;
    dto.disclaimer = data.disclaimer;
    dto.documentType = data.isDocumentTypeUrl === true ? 'URL' : 'File';
    dto.isDocumentTypeUrl = dto.documentType === 'URL' ? true : false;
    dto.fileName = data.fileName;
    dto.fileSize = data.fileSize;
    dto.firmId = data.firmId;
    dto.id = data.id;
    dto.isDealWide = data.isDealWide;
    dto.isUsed = data.isUsed;
    dto.isPackageSent = data.isPackageSent;
    dto.name = data.name;
    dto.sourceId = data.sourceId;
    dto.trancheId = data.trancheId;
    dto.rowVersion = data.rowVersion;

    return dto;
  }

  mapDocumentToPostData(data: DocumentDto): any {
    const dto = {
      dealId: data.dealId,
      disclaimer: data.disclaimer,
      isDocumentTypeUrl: data.documentType === 'URL' ? true : false,
      fileName: data.fileName,
      fileSize: data.fileSize,
      firmId: data.firmId,
      id: data.id,
      isDealWide: data.isDealWide,
      name: data.name,
      sourceId: data.sourceId,
      trancheId: data.trancheId,
      rowVersion: data.rowVersion
    };

    return dto;
  }

  mapToPackageDto(packageAPI: any): PackageDto {
    let packageUI = new PackageDto();
    packageUI = packageAPI;
    // packageUI._summary = new RecipientStatusSummaryDto();
    packageUI._summary = {
      sent: null,
      failed: null,
      notYetSent: null,
      pollingCallsMade: null,
      lastSentDate: null
    };
    packageUI._autoSendType = {
      syndicate: false,
      allocation: false,
      indication: false
    };
    packageUI.beingSent = false;
    packageUI._summaryLoading = null;
    return packageUI;
  }

}
