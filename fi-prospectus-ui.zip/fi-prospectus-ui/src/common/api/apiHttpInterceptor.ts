import { Injectable } from '@angular/core';
import {
  HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpResponse
} from '@angular/common/http';
import { SpinnerService } from '../spinner';
import { Observable } from 'rxjs/Observable';
import { tap, catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';
import { FiAuthService } from '../auth';

@Injectable()
export class ApiHttpInterceptor implements HttpInterceptor {
  private pendingRequestCounter = 0;
  constructor(private spinnerService: SpinnerService, private authService: FiAuthService) {
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const byPassSpinner = req.headers.get('byPassSpinner') === 'yes';
    const clonedRequest: HttpRequest<any> = req.clone({
      setHeaders: {
        'Authorization': 'Bearer ' + this.authService.accessToken
      },
      headers: req.headers.set('Cache-Control', 'no-cache')
        .set('Pragma', 'no-cache')
    });
    if (!byPassSpinner) {
      this.pendingRequestCounter++;
      this.spinnerService.show();
      return next.handle(clonedRequest).pipe(
        tap(res => {
          if (res instanceof HttpResponse) {
            this.decreaseCounter()
          }
        }),
        catchError((err, caught) => {
          this.decreaseCounter();
          return throwError(err);
        })
      );
    } else {
      return next.handle(clonedRequest).pipe(
        catchError((err, caught) => {
          return throwError(err);
        })
      );
    }
  }

  private decreaseCounter() {
    this.pendingRequestCounter--;
    if (this.pendingRequestCounter === 0) {
      this.spinnerService.hide();
    }
  }
}
