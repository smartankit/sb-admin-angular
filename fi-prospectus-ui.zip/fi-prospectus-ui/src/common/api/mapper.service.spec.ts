import { TestBed } from '@angular/core/testing';
import { PackageDto, DocumentDto } from '../../common';
import { MapperService } from './mapper.service';

describe('Service: Mapper Service', () => {

  let mapperService: MapperService;
  const mockDocuments: DocumentDto[] = [
    {
      'name': 'Prospecus Document',
      'fileSize': '234kb',
      'documentType': null,
      'isDocumentTypeUrl': false,
      'fileName': '',
      'disclaimer': 'Standard',
      'isDealWide': true,
      'sourceId': 1,
      'firmId': 1,
      'dealId': 1,
      'trancheId': 1,
      'id': '1',
      'fileToUpload': null,
      'isUsed': false,
      'isPackageSent': false
    }
  ];
  const mockPackages = [
    {
      id: '1234',
      firmId: 1,
      dealId: '1',
      name: 'test package',
      emailTemplateId: '39e85ff0-6c36-6793-5c41-d87cd00bc7ac',
      emailBody: '<p>blah blah 2</p>',
      expirationDate: '2018-09-22T12:00:00',
      expirationTimezone: 'America/New_York',
      subject: '3rd Deal',
      consentLanguageId: '39e85ff1-1aea-e7f7-726e-7630c8315c3b',
      documents: [],
      _summaryLoading: true
    }
  ] as PackageDto[];

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        MapperService
      ]
    });
    mapperService = TestBed.get(MapperService);
  });

  it('Should map to document DTO', () => {
    let documentDTO;
    mockDocuments[0].isDocumentTypeUrl = true;
    documentDTO = mapperService.mapToDocumentDto(mockDocuments[0]);
    expect(documentDTO.documentType).toEqual('URL');
    mockDocuments[0].isDocumentTypeUrl = false;
    documentDTO = mapperService.mapToDocumentDto(mockDocuments[0]);
    expect(documentDTO.documentType).toEqual('File');
  });

  it('Should map document to post data', () => {
    let documentDTO;
    mockDocuments[0].documentType = 'URL';
    documentDTO = mapperService.mapDocumentToPostData(mockDocuments[0]);
    expect(documentDTO.isDocumentTypeUrl).toEqual(true);
    mockDocuments[0].documentType = 'FILE';
    documentDTO = mapperService.mapDocumentToPostData(mockDocuments[0]);
    expect(documentDTO.isDocumentTypeUrl).toEqual(false);
  });

  it('Should map to package DTO', () => {
    let packageUI, summary;
    summary = {
      sent: null,
      failed: null,
      notYetSent: null,
      pollingCallsMade: null,
      lastSentDate: null
    };
    packageUI = mapperService.mapToPackageDto(mockPackages[0]);
    expect(packageUI._summary).toEqual(summary);
    expect(packageUI.beingSent).toBe(false);
    expect(packageUI._summaryLoading).toBe(null);
  });

});
