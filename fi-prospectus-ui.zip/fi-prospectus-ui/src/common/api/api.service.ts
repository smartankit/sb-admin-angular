import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { PackageDto } from '../models/dto/packageDto';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import 'rxjs/add/operator/delay';
import { DealDto } from '../models/dto/dealDto';
import { environment } from '../../environments/environment';
import { AppContext } from '../services/app-context.service';
import { MapperService } from './mapper.service';
import { RecipientSearchParameterDto, ContactRolesDto, AddDeleteRecipientInfoDto } from '../../common';
import {
  DocumentDto, EmailTemplateDto, ConsentLanguageDto, TrancheDto, PackageRecipientDto, PackageRecipientPagedDto,
  RecipientDto, RecipientPagedDto, RecipientStatusSummaryDto
} from '../../common';
import { PatchPackageDto } from '../models/dto/patchPackageDto';
import { PermissionDto } from '../models/dto/permissionDto';
import { RecipientAutoSendSummaryDto } from '../models/dto/recipientAutoSendSummaryDto';

@Injectable()
export class ApiService {
  baseUrl = environment.baseUrl;
  // localhostMockUrl = 'http://localhost:4200/assets/mocks/';

  constructor(private http: HttpClient, private appContext: AppContext, private mapperService: MapperService) {
  }

  getDeal(): Observable<DealDto> {

    const url = `${this.appContext.apiUrl}/v1/deals/${this.appContext.dealSourceId}`;
    // const url = this.baseUrl + `assets/mocks/deal-api.json`;

    return this.http.get(url).pipe(
      map((dealDto: DealDto) => {
        return dealDto;
        // TODO: dto => model
      }),
      catchError((err) => {
        return [];
      })
    );
  }

  getTranche(): Observable<TrancheDto> {
    if (!this.appContext.trancheSourceId) {
      return of(null);
    }

    const url = `${this.appContext.apiUrl}/v1/deals/${this.appContext.dealSourceId}/tranches/${this.appContext.trancheSourceId}`;
    // const url = this.baseUrl + `assets/mocks/deal-api.json`;

    return this.http.get(url).pipe(
      map((data: TrancheDto) => {
        return data;
        // TODO: dto => model
      }),
      catchError((err) => {
        return [];
      })
    );
  }

  getPackagesByDeal(): Observable<PackageDto[]> {
    let url = this.appContext.apiUrl + '/v1/packages?dealId=' + this.appContext.dealId

    if (this.appContext.trancheId) {
      url += '&trancheId=' + this.appContext.trancheId
    }

    return this.http.get(url).pipe(
      map((packages: PackageDto[]) => {
        return packages.map(packagesForIB => this.mapperService.mapToPackageDto(packagesForIB));
      }),
      catchError((err) => {
        return [];
      })
    );
  }

  getPackageById(packageId: string): Observable<PackageDto> {

    // const url = `${this.proxy}/prospectus/v1/packages`;
    const url = this.appContext.apiUrl + `/v1/packages/${packageId}`;

    return this.http.get(url).pipe(
      map((data: PackageDto) => {
        return data;
      })
    );
  }

  getContactInfo(contactId: string, type: string): Observable<any> {
    const url = this.appContext.apiUrl + `/v1/recipients/${contactId}?type=${type}`;
    return this.http.get(url).pipe(
      map((data: any) => {
        return data;
      })
    );
  }

  putContactInfo(contact: any): Observable<RecipientDto> {
    const url = this.appContext.apiUrl + `/v1/recipients`;
    return this.http.put(url, contact).pipe(
      map((dto: RecipientDto) => {
        return dto
      })
    )
  }

  updatePackage(packageDto: PackageDto): Observable<PackageDto> {
    const url = this.appContext.apiUrl + `/v1/packages/`;
    return this.http.put(url, packageDto).pipe(
      map((dto: PackageDto) => {
        return dto
      })
    )
  }

  patchPackage(patchPackageDto: PatchPackageDto[], packageId: string): Observable<PatchPackageDto> {
    const url = this.appContext.apiUrl + `/v1/packages/${packageId}`;
    return this.http.patch(url, patchPackageDto).pipe(
      map((dto: PatchPackageDto) => {
        return dto
      })
    )
  }

  getDocuments(ignoreTranche: boolean): Observable<DocumentDto[]> {
    let url = this.appContext.apiUrl + `/v1/documents?dealId=${this.appContext.dealId}`

    if (this.appContext.trancheId && !ignoreTranche) {
      url += '&trancheId=' + this.appContext.trancheId
    }

    return this.http.get(url).pipe(
      map((data: DocumentDto[]) => {
        const result = data.map(r => this.mapperService.mapToDocumentDto(r));
        return result;
      },
        catchError((err) => {
          return [];
        })
      ));
  }

  getFilteredRecipients(recipientSearchObj: RecipientSearchParameterDto,
    pageNumber: any, pageSize: number, byPassSpinner: boolean): Observable<RecipientPagedDto> {
    // const url = this.localhostMockUrl + 'contacts.json';
    const url = `${this.appContext.apiUrl}/v1/recipients?PackageId=${recipientSearchObj.packageId}&DealId=${this.appContext.dealId}`
      + `&Type=${recipientSearchObj.role}&Company=${recipientSearchObj.companyName}&Name=${recipientSearchObj.contactName}`
      + `&Email=${recipientSearchObj.email}&Page=${pageNumber}&PageSize=${pageSize}`;
    let httpOptions;
    if (byPassSpinner) {
      httpOptions = {
        headers: new HttpHeaders({
          'byPassSpinner': 'yes'
        })
      };
    }
    return this.http.get(url, httpOptions).pipe(
      map((data: RecipientPagedDto) => {
        return data;
      }),
      catchError((err) => {
        return [];
      })
    );
  }

  getRecipientsRoles(): Observable<ContactRolesDto[]> {
    const recipientsRoles = [
      { 'name': 'Investor', 'value': 'investor' },
      { 'name': 'External Syndicates', 'value': 'syndicate' },
      { 'name': 'Internal Contacts', 'value': 'internal' },
      { 'name': 'Mandatory Document Contact', 'value': 'prospectuscontact' }
    ];
    return of(recipientsRoles);
  }

  savePackage(packages: PackageDto) {
    const url = this.appContext.apiUrl + `/v1/packages`;
    return this.http.post(url, packages);
  }

  saveDocumentMetadata(documentData: DocumentDto): Observable<DocumentDto> {
    const url = `${this.appContext.apiUrl}/v1/documents`;
    // return this.http.post(url, documentData);
    const dataToSave = this.mapperService.mapDocumentToPostData(documentData);
    return this.http.post(url, dataToSave).pipe(
      map((data: DocumentDto) => {
        return data;
      }),
      catchError((err) => {
        throw err;
      })
    );
  }

  updateDocumentMetadata(documentData: DocumentDto): Observable<DocumentDto> {
    const url = `${this.appContext.apiUrl}/v1/documents`;
    // return this.http.put(url, documentData);
    const dataToSave = this.mapperService.mapDocumentToPostData(documentData);
    return this.http.put(url, dataToSave).pipe(
      map((data: DocumentDto) => {
        return data;
      }),
      catchError((err) => {
        throw err;
      })
    );
  }

  postFile(formdata: FormData, sourceId: number) {
    const url = `${this.appContext.apiUrl}/v1/documents/${sourceId}/file`;
    return this.http.post(url, formdata);
  }

  addRecipientsToPackage(packageId: string, addDeleteRecipientInfo: AddDeleteRecipientInfoDto) {
    const url = `${this.appContext.apiUrl}/v1/packages/${packageId}/recipients`;
    return this.http.post(url, addDeleteRecipientInfo)
  }

  getEmployerRoles(): Observable<string[]> {
    const url = this.baseUrl + `assets/mocks/roles.json`;

    return this.http.get(url).pipe(
      catchError((err) => {
        return [];
      })
    );
  }

  getContactPermissions(): Observable<PermissionDto[]> {

    const url = `${this.appContext.apiUrl}/v1/grants`;
    return this.http.get(url).pipe(map((data: PermissionDto[]) => {
      return data;
    }),
      catchError((err) => {
        console.log(err);
        return []
      })
    );

  }

  getConsentLanguages(): Observable<ConsentLanguageDto[]> {
    const url = `${this.appContext.apiUrl}/v1/consent-languages`;

    return this.http.get(url).pipe(
      map((data: ConsentLanguageDto[]) => {
        return data;
      }),
      catchError((err) => {
        return [];
      })
    );
  }

  getEmailTemplates(): Observable<EmailTemplateDto[]> {
    const url = `${this.appContext.apiUrl}/v1/email-templates`;

    return this.http.get(url).pipe(
      map((data: EmailTemplateDto[]) => {
        return data;
      },
        catchError((err) => {
          return [];
        })
      ));
  }

  deleteDocuments(id: string) {
    const url = `${this.appContext.apiUrl}/v1/documents/${id}`;
    return this.http.delete(url);
  }

  downloadDocument(sourceId: number): Observable<Blob> {
    const url = `${this.appContext.apiUrl}/v1/documents/${sourceId}/file/download`;
    return this.http.get(url, { responseType: 'blob' });
  }

  getDocumentNameTypes(): Observable<string[]> {
    const documentNameTypes = ['Internal Research', 'External Research', 'Prospectus', 'Issuer Web Page', 'News', 'Roadshow'];
    return of(documentNameTypes);
  }

  sendPackage(id: string, recipients: PackageRecipientDto[], byPassSpinner?: boolean): Observable<any> {
    let httpOptions;
    if (byPassSpinner) {
      httpOptions = {
        headers: new HttpHeaders({
          'byPassSpinner': 'yes'
        })
      };
    }
    const url = `${this.appContext.apiUrl}/v1/packages/send?PackageId=${id}&InvestorAccountId=${this.appContext.investorAccountId}`
      + `&DealId=${this.appContext.dealId}&audience=new`;
    return this.http.post(url, recipients, httpOptions);
  }

  austoSendPackage(id: string, autoSend: any): Observable<any> {
    const url = `${this.appContext.apiUrl}/v1/packages/${id}/autosend`;
    return this.http.post(url, autoSend);
  }

  getPackageRecipients(id: string, filterType: string, pageNumber: number,
    pageSize: number, byPassSpinner?: boolean): Observable<PackageRecipientPagedDto> {
    let httpOptions;
    if (byPassSpinner) {
      httpOptions = {
        headers: new HttpHeaders({
          'byPassSpinner': 'yes'
        })
      };
    }

    const url = `${this.appContext.apiUrl}/v1/packages/recipients?PackageId=${id}&InvestorAccountId=${this.appContext.investorAccountId}`
      + `&DealId=${this.appContext.dealId}&Page=${pageNumber}&PageSize=${pageSize}&status=${filterType}`;
    return this.http.get(url, httpOptions).pipe(
      map((data: PackageRecipientPagedDto) => {
        return data;
      },
        catchError((err) => {
          return [];
        })
      ));
  }

  getPackageRecipientsSummary(id: string, byPassSpinner?: boolean): Observable<RecipientStatusSummaryDto> {
    let httpOptions;
    if (byPassSpinner) {
      httpOptions = {
        headers: new HttpHeaders({
          'byPassSpinner': 'yes'
        })
      };
    }
    const url = `${this.appContext.apiUrl}/v1/packages/${id}/recipients/status/summary`;
    return this.http.get(url, httpOptions).pipe(
      map((data: RecipientStatusSummaryDto) => {
        return data;
      },
        catchError((err) => {
          return [];
        })
      ));
  }

  getPackageAutoSendRecipientSummary(id: string, autoSend: any, byPassSpinner?: boolean): Observable<RecipientAutoSendSummaryDto> {
    let httpOptions;
    if (byPassSpinner) {
      httpOptions = {
        headers: new HttpHeaders({
          'byPassSpinner': 'yes'
        })
      }
    }
    const url = `${this.appContext.apiUrl}/v1/packages/${id}/recipients/autosend/summary`
      + `?syndicates=${autoSend.syndicates}`
      + `&indications=${autoSend.indications}`
      + `&allocations=${autoSend.allocations}`
    return this.http.get(url, httpOptions).pipe(
      map((data: RecipientAutoSendSummaryDto) => {
        return data;
      },
        catchError((err) => {
          return [];
        })
      ));
  }

}
