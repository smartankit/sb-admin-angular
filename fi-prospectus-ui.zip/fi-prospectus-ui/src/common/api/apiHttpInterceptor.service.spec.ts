// import { TestBed } from '@angular/core/testing';
// import {
//   HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpResponse
// } from '@angular/common/http';
// import { DealDto, TrancheDto, PackageDto, DocumentDto } from '../../common';
// import { of, Observable, BehaviorSubject } from 'rxjs';
// import { ErrorObservable } from 'rxjs/observable/ErrorObservable';
// import { ApiHttpInterceptor } from './apiHttpInterceptor';
// import { SpinnerService } from '../spinner';
// import { FiAuthService } from '../auth';

// describe('Service: Interceptor Service', () => {

//   let apiHttpInterceptor: ApiHttpInterceptor;
//   let mockSpinnerService: SpinnerService;
//   let mockFiAuthService: FiAuthService;

//   const spinnerServiceStub = {
//     show: function() {
//     },
//     hide: function() {
//     }
//   };
//   const fiAuthServiceStub = {
//     accessToken: 'WSDFRHSQHDKWJQLDWLHLWKH'
//   };

//   beforeEach( () => {
//     TestBed.configureTestingModule({
//       providers: [
//         ApiHttpInterceptor,
//         {
//           provide: SpinnerService, useValue: spinnerServiceStub
//         },
//         {
//           provide: FiAuthService, useValue: fiAuthServiceStub
//         }
//       ]
//     });
//     apiHttpInterceptor = TestBed.get(ApiHttpInterceptor);
//     mockSpinnerService = TestBed.get(SpinnerService);
//     mockFiAuthService = TestBed.get(FiAuthService);
//   });

//   it('Should add recipients to package', () => {
//     let next = new HttpHandler();
//     spyOn(mockHttp, 'post');
//     apiService.addRecipientsToPackage(packageId, mockRecipients);
//     expect(mockHttp.post).toHaveBeenCalledWith(apiURL, mockRecipients);
//   });

// });
