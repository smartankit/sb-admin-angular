export class FiUser {
  public firstName: string
  public lastName: string
  public email: string
  public role: Array<string>
  public groups: Array<string>

  // TODO: once roles and groups are availalbe provide the following "can" checks based on UI requirements
  public get canCreatePackage() {
    return this.isSyndicateOrAdminUser();
  }

  public get canEditPackage() {
    return this.isSyndicateOrAdminUser();
  }

  public get canDisablePackage() {
    return this.isSyndicateOrAdminUser();
  }

  private isSyndicateOrAdminUser(): boolean {
    if (!this.role) {
      return false;
    }

    const userRole = this.role.find(r => r === 'Syndicate' ||  r === 'Admin' );
    return userRole ? true : false;
  }

  public get isSalesUser(): boolean {
    if (!this.role) {
      return false;
    }

    const salesRole = this.role.find(r => r === 'Sales');
    return salesRole ? true : false;
  }

  constructor(firstName: string, lastName: string, email: string, role: Array<string>) {
    this.firstName = firstName;
    this.lastName = lastName;
    this.email = email;
    this.role = role;
  }
}
