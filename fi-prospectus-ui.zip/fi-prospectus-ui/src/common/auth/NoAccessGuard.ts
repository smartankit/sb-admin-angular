import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { FiAuthService } from './auth.service';
import { AuthConfig } from 'angular-oauth2-oidc';

@Injectable()
export class FiNoAccessGuard implements CanActivate {
  constructor(public auth: FiAuthService, public router: Router) {
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    if (state.url !== '/') {
      return true
    }

    return  !this.auth.isSilentRefresh()
  }
}
