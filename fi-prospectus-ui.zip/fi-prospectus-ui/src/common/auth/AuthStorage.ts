import { OAuthStorage } from 'angular-oauth2-oidc';

export class FiOAuthStorage extends OAuthStorage {
  private prefix: string;

  constructor(prefix: string = '') {
    super()
    this.prefix = prefix;
  }

  public getItem(key: string): string {
    return localStorage.getItem(this.getPrefixedKey(key))
  }
  public removeItem(key: string): void {
    localStorage.removeItem(this.getPrefixedKey(key))
  }

  public setItem(key: string, data: string): void {
    localStorage.setItem(this.getPrefixedKey(key), data)
  }

  private getPrefixedKey(key: string) {
    return `${this.prefix}-${key}`
  }
}
