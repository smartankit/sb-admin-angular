import { CanActivate, Router } from '@angular/router';
import { FiAuthService } from './auth.service';
import { Injectable } from '@angular/core';

@Injectable()
export class FiAuthGuard implements CanActivate {
  constructor(public auth: FiAuthService, public router: Router) {
  }

  canActivate() {
    if (!this.auth.isAuthenticated) {
      return false;
    }
    return true;
  }
}
