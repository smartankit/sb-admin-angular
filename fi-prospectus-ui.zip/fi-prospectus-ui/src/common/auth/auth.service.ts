import { Injectable } from '@angular/core';
import { OAuthService, JwksValidationHandler } from 'angular-oauth2-oidc';
import { Subject, BehaviorSubject } from 'rxjs';
import { FiUser } from './User';
import { FiAuthConfig } from './AuthConfig';
import { JwtHelperService } from '@auth0/angular-jwt';

@Injectable()
export class FiAuthService {
  private _user: FiUser

  public get isAuthenticated(): boolean {
    return this.oauthService.hasValidAccessToken()
  }

  public get accessToken(): string {
    return this.oauthService.getAccessToken()
  }

  public get user(): FiUser {
    return this.isAuthenticated ? this._user : null
  }

  private authenticatedSubject = new BehaviorSubject<FiUser>(null);
  public authenticated$ = this.authenticatedSubject.asObservable()

  constructor(
    private oauthService: OAuthService, private jwtHelper: JwtHelperService
  ) { }

  public authenticate(config: FiAuthConfig): void {
    this.init(config)
    if (this.oauthService.hasValidIdToken() && this.oauthService.hasValidAccessToken()) {
      this.oauthService.loadDiscoveryDocument().then(() => {
        this.oauthService.loadUserProfile()
      })
    } else {
      if (location.href.indexOf('access_token') > -1) {
        const hash = window.location.hash || window.location.href.match(/#.+/)[0]
        this.oauthService.loadDiscoveryDocumentAndTryLogin({ customHashFragment: hash })
      } else {
        this.oauthService.loadDiscoveryDocumentAndLogin()
      }
    }
  }

  public isSilentRefresh(): boolean {
    return window.parent.document.getElementsByTagName('iframe').length > 0
  }

  private init(config: FiAuthConfig) {
    const redirectUrl = config.getRedirectUrl()
    if (redirectUrl) {
      localStorage.setItem(config.ibRedirectUriParameterName, redirectUrl)
    }

    this.oauthService.configure(config)
    this.oauthService.tokenValidationHandler = new JwksValidationHandler();
    this.oauthService.setupAutomaticSilentRefresh();
    this.oauthService.events.subscribe((e: { type: string }) => {
      console.log('oauth:', e.type)
      switch (e.type) {
        case 'token_expires':
          break
        case 'silently_refreshed':
          break
        case 'token_received':
          if (!this.isSilentRefresh()) {
            this.oauthService.loadUserProfile()
          }
          break
        case 'user_profile_loaded':
          this._user = this.parseUser()
          this.authenticatedSubject.next(this._user)
          break
      }
    });
  }

  private parseUser(): FiUser {
    const claims = this.oauthService.getIdentityClaims()
    const decodedToken = this.jwtHelper.decodeToken(this.accessToken);
    return new FiUser(claims['given_name'], claims['family_name'], claims['email'], decodedToken['role'])
  }
}
