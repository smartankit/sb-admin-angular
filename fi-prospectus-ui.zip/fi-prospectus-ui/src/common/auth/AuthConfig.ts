import { AuthConfig } from 'angular-oauth2-oidc';

export class FiAuthConfig extends AuthConfig {

  public get ibRedirectUriParameterName() {
    return 'fi-ib-oauth-redirect-url'
  }

  constructor() {
    super()
    const origin = window.location.origin || window.location.host
    // URL of the SPA to redirect the user to after login
    this.redirectUri = origin + '/signInCallback.html'
    this.silentRefreshRedirectUri = origin + '/silent-renew.html'
    this.requireHttps = false
    this.clearHashAfterLogin = true
    // this.silentRefreshTimeout = 200 * 1000
    // this.timeoutFactor = 0.05
  }

  // A user gets redirected to this URL after a successful authentication
  // It should contain any required query paramters for the angular app to load
  // Override this method if needed
  public getRedirectUrl() {
    const hashIndex = window.location.href.indexOf('#')
    if (hashIndex > -1) {
      return window.location.href.substring(0, hashIndex)
    } else {
      return window.location.href
    }
  }
};
