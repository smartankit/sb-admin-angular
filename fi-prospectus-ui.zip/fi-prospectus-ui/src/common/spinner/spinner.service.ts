import { Injectable } from '@angular/core';
import { CupcakeGlobalsService } from '@ipreo/cupcake-components';

@Injectable()
export class SpinnerService {

  constructor(private globals: CupcakeGlobalsService) { }

  private setSpinnerComponentVisibility(displayStyle: string): any {
    const spinnerContainer: any = this.globals.document.querySelector('app-cout-spinner');
    if (spinnerContainer) {
      spinnerContainer.style.display = displayStyle;
    }
  }

  private setNoRecordFoundVisibility(displayStyle: string) {
    const noRecordContainer: any = this.globals.document.querySelector('#noRecords')

    if (noRecordContainer) {
      noRecordContainer.style.display = displayStyle;
    }
  }

  public show() {
    this.setSpinnerComponentVisibility('block');
  }

  public hide() {
    this.setSpinnerComponentVisibility('none');
    this.setNoRecordFoundVisibility('block');
  }
}
