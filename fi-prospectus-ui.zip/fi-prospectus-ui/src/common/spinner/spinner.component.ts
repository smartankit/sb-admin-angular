import {
  Component,
  Input
} from '@angular/core';

@Component({
  selector: 'app-cout-spinner',
  styles: [`
    .spinner-curtain {
      position: absolute;
      top: 0px;
      width: 5%;
      margin-left: 40%;
      /* height: 100%; */
      opacity: 0.40;
      filter: alpha(opacity=20);
      z-index: 2999;
      margin-top: 20%;
      transform: translate(50%, 50%);
    }
  `],
  template: `
    <div class="spinner-container">
      <div class="spinner-curtain"></div>
      <div class="c-full-page-loader spinner-curtain">
      </div>
    </div>
  `
})
export class CoutSpinnerComponent {
}
