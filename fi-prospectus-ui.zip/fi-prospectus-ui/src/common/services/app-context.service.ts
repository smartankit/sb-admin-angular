import { Injectable, ElementRef } from '@angular/core';

@Injectable()
export class AppContext {
  _dealSourceId: string;
  _trancheSourceId: string;
  _firmId: number;
  _apiUrl: string;
  _authServerUrl: string;
  _tabToSelect: string;
  _source: string;
  _investorAccountId: string;
  public dealId: string;
  public trancheId: string;
  constructor() {

  }

  public get dealSourceId(): string {
    return this._dealSourceId;
  }

  public get investorAccountId(): string {
    return this._investorAccountId;
  }

  public get trancheSourceId(): string {
    return this._trancheSourceId;
  }

  public get canShowPackageManagement() {
    return this.trancheSourceId === null ? true : false;
  }

  public get canShowTracking() {
    return this.trancheSourceId === null ? true : false;
  }

  // To Be removed
  public get firmId(): number {
    return this._firmId;
  }

  public get apiUrl(): string {
    return this._apiUrl;
  }

  public get authServerUrl(): string {
    return this._authServerUrl;
  }

  public get tabToSelect(): string {
    return this._tabToSelect;
  }

  public get source(): string {
    return this._source;
  }

  public init(appElement: ElementRef) {

    const dealSourceId = appElement.nativeElement.getAttribute('dealId');
    this._dealSourceId = dealSourceId ? dealSourceId : null

    const source = appElement.nativeElement.getAttribute('source');
    this._source = source ? source : null

    const investorAccountId = appElement.nativeElement.getAttribute('investorAccountId');
    this._investorAccountId = investorAccountId ? investorAccountId : ''

    const trancheSourceId = appElement.nativeElement.getAttribute('trancheId');
    this._trancheSourceId = trancheSourceId ? trancheSourceId : null

    this._apiUrl = appElement.nativeElement.getAttribute('apiUrl');

    this._tabToSelect = appElement.nativeElement.getAttribute('tabtoselect');

    this._authServerUrl = appElement.nativeElement.getAttribute('authServerUrl');
    this._authServerUrl = this._authServerUrl || 'https://identity-server-int.ci.ns-orders.ipreo.com'
  }
}
