import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { environment } from './environments/environment';

if (environment.production) {
  enableProdMode();
}

// Text editor was not getting loaded on QX even though script tag was added on IB java page so, we had to load it manually here
const tinyMceScript = document.createElement('script');
tinyMceScript.type = 'text/javascript';
tinyMceScript.src = '//cdn.tinymce.com/4/tinymce.min.js';
document.body.appendChild(tinyMceScript);

platformBrowserDynamic().bootstrapModule(AppModule)
  .catch(err => console.log(err));
