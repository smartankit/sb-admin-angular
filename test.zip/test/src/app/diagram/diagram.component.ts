import {
  AfterContentInit,
  Component,
  ElementRef,
  OnDestroy,
  ViewChild,
  OnInit,
} from '@angular/core';

import { HttpClient } from '@angular/common/http';


import * as BpmnJS from 'bpmn-js/dist/bpmn-modeler.production.min.js';
import { getBusinessObject } from 'bpmn-js/lib/util/ModelUtil';
import { TaskPanelPropertiesComponent } from '../task-panel-properties/task-panel-properties.component';
import { StartPanelPropertiesComponent } from '../start-panel-properties/start-panel-properties.component';

@Component({
  selector: 'app-diagram',
  templateUrl: './diagram.html',
   
  styles: [
    `
    html, body {
      margin: 0; padding : 0;
    }
    .diagram-container {
      height: 400px;
      width: 100%;
      border: 1px solid lightgray;
    }
    `
  ]
})
export class DiagramComponent implements AfterContentInit, OnDestroy,OnInit {
  bpmnJS: BpmnJS;
  eventBus: any;
  modeling: any;
  moddle: any;
  elementRegistry: any;
  elementFactory: any;

  selectedBpmnNotation: any;
  showProcessPanel: boolean = false;
  showStartPanel: boolean = false;
  showTaskPanel: boolean = false;

  processProps:any;

  startProps: any ;

  taskProps: any ;
  
  selectedElement: any = {
    id:'',
    type:'',
    name: '',
    description: '',
    status:'',
    queue:''
  }
  

  statuses = ["approve", "reject", "pending", "inProgress"];
  queues = ["approve", "reject", "pending", "inProgress"];

  @ViewChild('ref', {}) private el: ElementRef;

  constructor(private http: HttpClient) { }
ngOnInit(){

  this.selectedElement.name ='bpmn:Process';
}
  ngAfterContentInit(): void {
    this.bpmnJS = new BpmnJS({
      container: this.el.nativeElement,
    });

    this.bpmnJS.on('import.done', ({ error }) => {
      if (!error) {
        this.bpmnJS.get('canvas').zoom('fit-viewport');
      }
    });

    this.loadUrl();

    this.eventBus = this.bpmnJS.get('eventBus');
    this.modeling = this.bpmnJS.get('modeling');
    this.moddle = this.bpmnJS.get('moddle');
    this.elementRegistry = this.bpmnJS.get('elementRegistry');
    this.elementFactory = this.bpmnJS.get('elementFactory');
    this.eventBus.on('element.updated', (e) => {
      console.log('test');
    });

    this.eventBus.on('shape.create', 999999, function(event) {
      console.log('Did you just try to create something?!');
    });
    this.eventBus.on('element.click', (e) => {
       console.log(e);

      this.showProcessPanel = false;
      this.showStartPanel = false;
      this.showTaskPanel = false;
      const businessObject = e.element.businessObject
      console.log('businessObject')
      console.log(businessObject)
  
      if (e.element.type === 'bpmn:Process') {
        this.showProcessPanel = true;
        this.selectedBpmnNotation = e;
        this.selectedElement.id = businessObject.$type;
        this.selectedElement.name = businessObject.name;
        this.selectedElement.description = businessObject.$attrs.description;
        this.selectedElement.details = businessObject.extensionElements
      }
      else if (e.element.type === 'bpmn:StartEvent') {
        this.showStartPanel = true;
        this.selectedBpmnNotation = e;
        this.selectedElement.id = businessObject.$type;
        this.selectedElement.name = businessObject.name;
        this.selectedElement.description = businessObject.$attrs.description;
        this.selectedElement.details = businessObject.extensionElements
      }
      else if (e.element.type === 'bpmn:Task') {
        this.showTaskPanel = true;
        this.selectedBpmnNotation = e;
        this.selectedElement.id = businessObject.$type;
        this.selectedElement.name = businessObject.name;
        this.selectedElement.description = businessObject.$attrs.description;
        this.selectedElement.details = businessObject.extensionElements

       
        console.log(this.selectedElement);
      }
      else if (e.element.type === 'bpmn:UserTask') {
        this.showTaskPanel = true;
        this.selectedBpmnNotation = e;
        this.selectedElement.id = businessObject.$type;
        this.selectedElement.name = businessObject.name;
        this.selectedElement.description = businessObject.$attrs.description;
        this.selectedElement.details = businessObject.extensionElements
        if(this.selectedElement.details){
          let statuAndQueue = this.getExtensionElement(businessObject, 'camunda:statusAndQueue');
          this.selectedElement.status = statuAndQueue.$children[0].$body
          this.selectedElement.queue = statuAndQueue.$children[1].$body
            console.log(statuAndQueue);
        }else{

          this.selectedElement.status = '';
          this.selectedElement.queue = '';
        }
        
       
        console.log(this.selectedElement);
      }
      else{

      }
    });

  }

  ngOnDestroy(): void {
    this.bpmnJS.destroy();
  }

  importDoneCb = (s: any, e: any) => {
    console.log(s, e);
  }

  loadUrl() {
    this.bpmnJS.createDiagram(this.importDoneCb);
  }

  saveDoneCb(e, w) {
    console.log(w);
  }

  saveXml(e) {
    this.bpmnJS.saveXML({}, this.saveDoneCb);
  }

 
  getExtensionElement(element, type) {
    if (!element.extensionElements) {
      return;
    }

    return element.extensionElements.values.filter((extensionElement) => {
      return extensionElement.$instanceOf(type);
    })[0];
  }



  onUpdatedProcessProps(event) {
    var camundaNs = 'http://camunda.org/schema/1.0/bpmn';
    
    var status = this.moddle.createAny('camunda:inputParameter', camundaNs, {
      name: 'status',
      $body: event.status
    });

    var queue = this.moddle.createAny('camunda:inputParameter', camundaNs, {
      name: 'queue',
      $body: event.queue
    });
    

    var statusAndQueue = this.moddle.createAny('camunda:statusAndQueue', camundaNs, {
      $children: [
        status,
        queue
      ]
    });

    var extensionElements = this.moddle.create('bpmn:ExtensionElements', {
      values: [ statusAndQueue ]
    });
    
    this.modeling.updateProperties(this.selectedBpmnNotation.element,
      {
        extensionElements: extensionElements,
        name: event.name,
        description: event.description,
      }
    );
    this.processProps = event;
  }

  saveData(n, d,s,q) {
    var camundaNs = 'http://camunda.org/schema/1.0/bpmn';
    
    var status = this.moddle.createAny('camunda:inputParameter', camundaNs, {
      name: 'status',
      $body: s
    });

    var queue = this.moddle.createAny('camunda:inputParameter', camundaNs, {
      name: 'queue',
      $body: q
    });
    

    var statusAndQueue = this.moddle.createAny('camunda:statusAndQueue', camundaNs, {
      $children: [
        status,
        queue
      ]
    });

    var extensionElements = this.moddle.create('bpmn:ExtensionElements', {
      values: [ statusAndQueue ]
    });
    
    this.modeling.updateProperties(this.selectedBpmnNotation.element,
      {
        extensionElements: extensionElements,
        name: n,
        description: d,
      }
    );
    this.saveXml(this.modeling);
  }


  onUpdatedStartProps(event) {
    this.modeling.updateProperties(this.selectedBpmnNotation.element,
      {
        name: event.name,
        description: event.description
      }
    );
    this.startProps = event;
  }
  onUpdatedTaskProps(event) {
    this.modeling.updateProperties(this.selectedBpmnNotation.element,
      {
        name: event.name,
        description: event.description
      }
    );

   
    const businessObject = this.selectedBpmnNotation.element.businessObject
    console.log('businessObject')
    console.log(businessObject)
    this.taskProps = businessObject;

  }
}

