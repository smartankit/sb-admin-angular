import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-start-panel-properties',
  templateUrl: './start-panel-properties.component.html',
  styleUrls: ['./start-panel-properties.component.css']
})
export class StartPanelPropertiesComponent implements OnInit {
  @Input() startProps;
  @Output() updatedStartProps = new EventEmitter();
  
  start = {
    name: 'sample',
    description: 'description'
  };

  constructor() { }

  ngOnInit() {
    this.start = this.startProps;
  }

  saveData(n, d) {
    console.log(n, d);
    const obj = {
      name: n,
      description: d
    };

    this.updatedStartProps.emit(obj);
  }
}


