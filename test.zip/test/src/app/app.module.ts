import { BrowserModule } from '@angular/platform-browser';
import { DiagramComponent } from './diagram/diagram.component';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { StartPanelPropertiesComponent } from './start-panel-properties/start-panel-properties.component';
import { ProcessPanelPropertiesComponent } from './process-panel-properties/process-panel-properties.component';
import { TaskPanelPropertiesComponent } from './task-panel-properties/task-panel-properties.component';
import { FormsModule } from '@angular/forms';
@NgModule({
  declarations: [
    AppComponent,
    DiagramComponent,
    StartPanelPropertiesComponent,
    ProcessPanelPropertiesComponent,
    TaskPanelPropertiesComponent
    
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
