import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-process-panel-properties',
  templateUrl: './process-panel-properties.component.html',
  styleUrls: ['./process-panel-properties.component.css']
})
export class ProcessPanelPropertiesComponent implements OnInit {

  @Input() processProps;
  @Output() updatedProcessProps = new EventEmitter();

  process = {
    name: 'sample',
    description: 'description',
    status: 'status',
    queue: 'queue'
  };

  statuses = ["approve", "reject", "pending", "inProgress"];
  queues = ["approve", "reject", "pending", "inProgress"];


  constructor() { }

  ngOnInit() {
    this.process = this.processProps;
  }

  saveData(n, d, a, b) {
    console.log(n, d, a, b);
    const obj = {
      name: n,
      description: d,
      status: a,
      queue: b
    };

    this.updatedProcessProps.emit(obj);
  }


}
