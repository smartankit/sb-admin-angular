import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { getBusinessObject } from 'bpmn-js/lib/util/ModelUtil';

@Component({
  selector: 'app-task-panel-properties',
  templateUrl: './task-panel-properties.component.html',
  styleUrls: ['./task-panel-properties.component.css']
})
export class TaskPanelPropertiesComponent implements OnInit {

  @Input() taskProps;

  @Output() updatedTaskProps = new EventEmitter();
  
  task = {
    name: 'sample',
    description: 'description'
  };

  constructor() { }

  ngOnInit() {
    console.log(this.taskProps);
    console.log(this.taskProps.id);
    console.log('kkkkkk');

    this.task = this.taskProps;
  }

  saveData(n, d) {
    console.log(n, d);
    const obj = {
      name: n,
      description: d
    };
    this.updatedTaskProps.emit(obj);
  }


}
